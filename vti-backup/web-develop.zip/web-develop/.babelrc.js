const plugins = []

module.exports = { plugins }
