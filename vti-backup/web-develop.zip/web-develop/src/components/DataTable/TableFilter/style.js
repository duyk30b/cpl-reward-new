const style = (theme) => ({
  root: {
    marginLeft: 16,
  },
  formContainer: {
    width: 500,
    padding: theme.spacing(2.5, 2, 2),
  },
})

export default style
