import { useRef } from 'react'

import MuiCheckbox from '@mui/material/Checkbox'

import HotKeys from '../HotKeys'

const Checkbox = (props = {}) => {
  const inputRef = useRef()

  const handleKeyDown = (e) => {
    const isEnter = e?.keyCode === 13

    if (!props.disabled && isEnter) {
      e.preventDefault()
      e.stopPropagation()

      props.onChange?.({
        target: { checked: !inputRef?.current?.checked },
      })
    }
  }

  return (
    <HotKeys onKeyDown={handleKeyDown}>
      <MuiCheckbox {...props} inputRef={props.inputRef || inputRef} />
    </HotKeys>
  )
}

Checkbox.defaultProps = {}

Checkbox.propTypes = {}

export default Checkbox
