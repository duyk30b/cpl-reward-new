import { useFormikContext } from 'formik'

import { FIELD_AREA } from '~/common/constants'
import { Field } from '~/components/Formik'

const FormTextField = ({
  field,
  area,
  isUpdate,
  index,
  isNumber = false,
  name,
}) => {
  const { values, setFieldValue } = useFormikContext()
  const { attribute, attributeRule } = field
  const handleOnChange = attribute.onChange
  const getElement = () => {
    switch (area) {
      case FIELD_AREA.HEADER:
        return (
          <Field.TextField
            name={attribute.fieldName || ''}
            label={attribute.name || ''}
            placeholder={attribute.name || ''}
            disabled={
              Boolean(attributeRule.disabled) ||
              (isUpdate && !Boolean(attributeRule.canUpdate))
            }
            required={Boolean(attributeRule.isRequired)}
            {...(attribute.multiline ? { multiline: true, rows: 3 } : {})}
            {...(isNumber
              ? {
                  type: 'number',
                  numberProps: {
                    thousandSeparator: ' ',
                    decimalScale: 4,
                  },
                }
              : {
                  inputProps: {
                    maxLength: attributeRule.max || null,
                  },
                })}
            {...(typeof handleOnChange === 'function'
              ? {
                  onChange: (val) =>
                    handleOnChange({ val, setFieldValue, values }),
                }
              : {})}
          />
        )
      case FIELD_AREA.TABLE:
        return (
          <Field.TextField
            name={
              name
                ? `${name}[${index}].${attribute.fieldName}`
                : `items[${index}].${attribute.fieldName}` || ''
            }
            // formatter={attributeRule?.formatter}
            placeholder={attribute.name || ''}
            disabled={
              Boolean(attributeRule.disabled) ||
              (isUpdate && !Boolean(attributeRule.canUpdate))
            }
            required={Boolean(attributeRule.isRequired)}
            {...(isNumber
              ? {
                  type: 'number',
                  numberProps: {
                    thousandSeparator: ' ',
                    decimalSeparator: ',',
                    decimalScale: 4,
                  },
                }
              : {
                  inputProps: {
                    maxLength: attributeRule.max || null,
                  },
                })}
            {...(typeof handleOnChange === 'function'
              ? {
                  onChange: (val) =>
                    handleOnChange({
                      val,
                      index,
                      setFieldValue,
                      values,
                      attribute,
                    }),
                }
              : {})}
          />
        )
      default:
        break
    }
  }

  return getElement()
}

export default FormTextField
