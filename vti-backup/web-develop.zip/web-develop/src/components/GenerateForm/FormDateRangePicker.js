import { FIELD_AREA } from '~/common/constants'
import { Field } from '~/components/Formik'

const FormDateRangePicker = ({ field, area, isUpdate, index, name }) => {
  const { attribute, attributeRule } = field

  const getElement = () => {
    switch (area) {
      case FIELD_AREA.HEADER:
        return (
          <Field.DateRangePicker
            name={attribute.fieldName || ''}
            label={attribute.name || ''}
            placeholder={attribute.name || ''}
            disabled={
              Boolean(attributeRule.disabled) ||
              (isUpdate && !Boolean(attributeRule.canUpdate))
            }
            required={Boolean(attributeRule.isRequired)}
            minDate={attributeRule.min || null}
            maxDate={attributeRule.max || null}
          />
        )
      case FIELD_AREA.TABLE:
        return (
          <Field.DateRangePicker
            name={
              name
                ? `${name}[${index}].${attribute.fieldName}`
                : `items[${index}].${attribute.fieldName}` || ''
            }
            placeholder={attribute.name || ''}
            disabled={
              Boolean(attributeRule.disabled) ||
              (isUpdate && !Boolean(attributeRule.canUpdate))
            }
            required={Boolean(attributeRule.isRequired)}
            minDate={attributeRule.min || null}
            maxDate={attributeRule.max || null}
          />
        )
      default:
        break
    }
  }
  return getElement()
}

export default FormDateRangePicker
