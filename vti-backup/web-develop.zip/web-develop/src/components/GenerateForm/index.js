import { Box, Grid, IconButton, Typography } from '@mui/material'
import { FieldArray, Form, Formik } from 'formik'
import { isEmpty, isNumber } from 'lodash'
import { PropTypes } from 'prop-types'
import { useTranslation } from 'react-i18next'

import { DATA_TYPE, FIELD_AREA, MODAL_MODE } from '~/common/constants'
import { useApp } from '~/common/hooks/useApp'
import Tabs from '~/components/Tabs'

import ActionBar from '../ActionBar'
import Button from '../Button'
import DataTable from '../DataTable'
import Icon from '../Icon'
import LabelValue from '../LabelValue'
import Status from '../Status'
import FormAutocomplete from './FormAutocomplete'
import FormDatePicker from './FormDatePicker'
import FormDateRangePicker from './FormDateRangePicker'
import FormFileUploadButton from './FormFileUploadButton'
import FormTextField from './FormTextField'

const getFieldComponent = (field, area, mode, index = 1, params, name) => {
  const props = {
    field: field,
    area: area,
    isUpdate: mode === MODAL_MODE.UPDATE,
    index: index,
    params: params,
    name: name,
  }
  switch (field.attribute.dataType) {
    case DATA_TYPE.TEXT:
      return <FormTextField {...props} />
    case DATA_TYPE.NUMBER:
      return <FormTextField {...props} isNumber={true} />
    case DATA_TYPE.DATE:
      return <FormDatePicker {...props} />
    case DATA_TYPE.SELECTBOX_MULTIPLE:
    case DATA_TYPE.SELECTBOX_SINGLE:
      return <FormAutocomplete {...props} />
    case DATA_TYPE.DATE_RANGE_PICKER:
      return <FormDateRangePicker {...props} />
    case DATA_TYPE.FILE:
      return <FormFileUploadButton {...props} />
    default:
      break
  }
}

export const GenerateHeader = ({
  headerFields,
  statusOptions,
  mode,
  initialValues,
}) => {
  const { t } = useTranslation()

  return (
    <>
      {headerFields?.map((field) => {
        if (field.attribute.multiline) {
          return (
            <Grid item xs={12}>
              {getFieldComponent(field, FIELD_AREA.HEADER, mode)}
            </Grid>
          )
        } else if (field.attribute?.isStatus) {
          return (
            <Grid item xs={12}>
              <LabelValue
                label={
                  <Typography>
                    {field?.attribute?.label
                      ? field?.attribute?.label
                      : t('common.status')}
                  </Typography>
                }
                value={
                  <Status
                    options={statusOptions}
                    value={
                      isNumber(field.attribute.value)
                        ? field.attribute.value
                        : initialValues?.status
                    }
                  />
                }
              />
            </Grid>
          )
        } else if (field.attribute?.isInfo) {
          return (
            <Grid item lg={6} xs={12}>
              <LabelValue
                label={<Typography>{field?.attribute?.name}</Typography>}
                value={field?.attribute?.value}
              />
            </Grid>
          )
        } else {
          return (
            <Grid item lg={6} xs={12}>
              {getFieldComponent(field, FIELD_AREA.HEADER, mode)}
            </Grid>
          )
        }
      })}
    </>
  )
}

export const GenerateTable = ({
  values,
  tableFields,
  tableButton,
  tableTitle,
  mode,
  initialItem,
  name,
}) => {
  const { scrollToBottom } = useApp()
  let boundArrayHelpers
  const bindArrayHelpers = (arrayHelpers) => {
    boundArrayHelpers = arrayHelpers
  }
  // const fields = !isEmpty(tableFields) ? tableFields : tab.attributes
  const fields = tableFields
  const columnsFormat =
    fields?.map((field) => ({
      field: field?.attribute?.fieldName || '',
      headerName: field?.attribute?.name || '',
      hide: field?.attributeRule?.display === 0,
      required:
        (field?.attributeRule?.required &&
          Boolean(field?.attributeRule?.isRequired)) ||
        '',
      ...(field?.attributeRule?.width
        ? { width: field?.attributeRule?.width }
        : {}),
      renderCell: (params, index) =>
        getFieldComponent(field, FIELD_AREA.TABLE, mode, index, params, name),
    })) || []

  const columns = [
    {
      field: 'id',
      headerName: '#',
      renderCell: (_, index) => {
        return index + 1
      },
    },
    ...columnsFormat,
    {
      field: 'remove',
      headerName: '',
      width: 50,
      align: 'center',
      renderCell: (params, index) => {
        return (
          <IconButton
            onClick={() => boundArrayHelpers.remove(index)}
            disabled={
              !isEmpty(values?.[`${name}`])
                ? values?.[`${name}`]?.length === 1
                : values?.items?.length === 1
            }
            size="small"
          >
            <Icon name="remove" />
          </IconButton>
        )
      },
    },
  ]
  return (
    <FieldArray
      name={name || 'items'}
      render={(arrayHelpers) => {
        bindArrayHelpers(arrayHelpers)
        return (
          <>
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                mb: 1,
              }}
            >
              <Typography variant="h4">{tableTitle}</Typography>
              <Button
                variant="outlined"
                onClick={() => {
                  arrayHelpers.push({
                    ...initialItem,
                    id: new Date().getTime(),
                  })
                  scrollToBottom()
                }}
                icon="add"
              >
                {tableButton}
              </Button>
            </Box>
            <DataTable
              rows={
                !isEmpty(values?.[`${name}`])
                  ? values?.[`${name}`]
                  : values?.items || []
              }
              columns={columns}
              total={null}
              striped={false}
              hideSetting
              hideFooter
              // tableSettingKey={tab.code || ''}
            />
          </>
        )
      }}
    />
  )
}

export const GenerateTabs = ({ tabList, valueTabs }) => {
  const item = valueTabs?.[0]
  if (tabList?.length > 1) {
    return (
      <Tabs list={tabList?.length > 1 ? tabList : []}>
        {!isEmpty(valueTabs) &&
          valueTabs?.map((item) => (
            <>
              <Box sx={{ mt: 2 }}>
                <GenerateTable
                  values={item?.values}
                  tableFields={item?.tableFields || []}
                  tableButton={item?.tableButton}
                  tableTitle={item?.tableTitle}
                  mode={item?.mode}
                  initialItem={item?.initialItem}
                  name={item?.name}
                />
              </Box>
            </>
          ))}
      </Tabs>
    )
  } else {
    return (
      !isEmpty(item) && (
        <GenerateTable
          values={item?.values}
          tableFields={item?.tableFields}
          tableButton={item?.tableButton}
          tableTitle={item?.tableTitle}
          mode={item?.mode}
          s
          initialItem={item?.initialItem}
          name={item?.name}
        />
      )
    )
  }
}

const GenerateForm = ({
  headerFields,
  tableFields,
  tabList,
  // tabFields ,
  tableTitle,
  tableButton,
  initialValues,
  validationSchema,
  onSubmit,
  mode,
  onBack,
  initialItem,
  statusOptions,
}) => {
  const headerFieldsFilter = headerFields?.filter((field) =>
    Boolean(field?.attributeRule?.display),
  )
  const tableFieldsFilter = tableFields?.filter((field) =>
    Boolean(field?.attributeRule?.display),
  )
  const renderActionBar = (handleReset) => {
    switch (mode) {
      case MODAL_MODE.CREATE:
        return (
          <ActionBar
            onBack={onBack}
            onCancel={handleReset}
            mode={MODAL_MODE.CREATE}
          />
        )
      case MODAL_MODE.UPDATE:
        return (
          <ActionBar
            onBack={onBack}
            onCancel={handleReset}
            mode={MODAL_MODE.UPDATE}
          />
        )
      default:
        break
    }
  }
  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
      enableReinitialize
    >
      {({ handleReset, values }) => (
        <Form>
          {!isEmpty(headerFieldsFilter) && (
            <Grid container justifyContent="center">
              <Grid item xl={11} xs={12}>
                <Grid
                  container
                  rowSpacing={4 / 3}
                  columnSpacing={{ xl: 8, xs: 4 }}
                  ml={4}
                >
                  <GenerateHeader
                    headerFields={headerFieldsFilter}
                    statusOptions={statusOptions}
                    mode={mode}
                    initialValues={initialValues}
                  />
                </Grid>
              </Grid>
            </Grid>
          )}
          {!isEmpty(tableFieldsFilter) && (
            <Box sx={{ mt: 3 }}>
              <GenerateTable
                values={values}
                tableFields={tableFieldsFilter}
                tableButton={tableButton}
                tableTitle={tableTitle}
                mode={mode}
                initialItem={initialItem}
              />
            </Box>
          )}
          {!isEmpty(tabList) && (
            <Box sx={{ mt: 3 }}>
              <GenerateTabs />
            </Box>
          )}
          {renderActionBar(handleReset)}
        </Form>
      )}
    </Formik>
  )
}

GenerateForm.defaultProps = {
  headerFields: [],
  tableFields: [],
  tabList: [],
  tabFields: [],
  tableTitle: '',
  tableButton: '',
  initialValues: {},
  validationSchema: () => {},
  onSubmit: () => {},
  mode: MODAL_MODE.CREATE,
  onBack: () => {},
  initialItem: {},
  statusOptions: [],
}

GenerateForm.propTypes = {
  headerFields: PropTypes.array,
  tableFields: PropTypes.array,
  tabList: PropTypes.array,
  tabFields: PropTypes.array,
  tableTitle: PropTypes.string,
  tableButton: PropTypes.string,
  initialValues: PropTypes.object,
  validationSchema: PropTypes.func,
  onSubmit: PropTypes.func,
  mode: PropTypes.string,
  onBack: PropTypes.func,
  initialItem: PropTypes.object,
  statusOptions: PropTypes.array,
}

export default GenerateForm
