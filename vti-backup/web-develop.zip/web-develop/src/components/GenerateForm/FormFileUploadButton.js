import { FormHelperText, Typography } from '@mui/material'
import { useFormikContext } from 'formik'

import FileUploadButton from '../FileUploadButton'
import LabelValue from '../LabelValue'

const FormFileUploadButton = ({ field }) => {
  const { values, setFieldValue, setFieldError, errors } = useFormikContext()
  const fieldName = field?.attribute?.fieldName || 'files'
  const value = field?.attribute?.fieldName ? values[fieldName] : values?.files
  return (
    <LabelValue
      label={<Typography mt={1}>{field.attribute.name || ''}</Typography>}
      value={
        <>
          <FileUploadButton
            maxNumberOfFiles={
              field?.attributeRule?.maxNumberOfFiles
                ? field?.attributeRule?.maxNumberOfFiles
                : 10
            }
            onChange={(val) => {
              if (field?.attribute?.onChange) {
                return field?.attribute?.onChange(val, {
                  setFieldValue,
                  setFieldError,
                })
              }
              return setFieldValue(fieldName, val)
            }}
            value={value}
            {...(field?.attributeRule?.accept
              ? { accept: field?.attributeRule?.accept }
              : {})}
          />
          {errors && errors[fieldName] && (
            <FormHelperText error>{errors[fieldName]}</FormHelperText>
          )}
        </>
      }
    />
  )
}

export default FormFileUploadButton
