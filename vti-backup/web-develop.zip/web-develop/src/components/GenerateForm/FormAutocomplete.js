import { useFormikContext } from 'formik'
import { useTranslation } from 'react-i18next'

import { ASYNC_SEARCH_LIMIT, FIELD_AREA } from '~/common/constants'
import { Field } from '~/components/Formik'
import { api } from '~/services/api'

const FormAutocomplete = ({ field, area, isUpdate, index, params, name }) => {
  const { t } = useTranslation()
  const { attribute, attributeRule } = field

  const { values, setFieldValue } = useFormikContext()

  const handleOnChange = attribute?.onChange
  const getOptions = attribute?.getOptions

  const getListApi = (dataSource, params) => {
    const uri = `${dataSource.uri}`
    return api.get(uri, params)
  }
  const getElement = () => {
    switch (area) {
      case FIELD_AREA.HEADER:
        return (
          <Field.Autocomplete
            name={attribute.fieldName || ''}
            label={attribute.name || ''}
            placeholder={attribute.name || ''}
            {...(attributeRule?.isOptions
              ? {
                  options: attributeRule?.options
                    ? attributeRule?.options
                    : getOptions({ values }),
                  getOptionLabel: (opt) => opt?.code || t(opt?.text) || '',
                }
              : {
                  asyncRequest: (s) => {
                    if (typeof attributeRule?.table?.callApi === 'function') {
                      const callApi = attributeRule?.table?.callApi
                      return callApi({ values })
                    } else {
                      const params = {
                        keyword: s,
                        limit: ASYNC_SEARCH_LIMIT,
                        filter: attributeRule?.table?.filter,
                      }
                      return getListApi(attributeRule?.table || '', params)
                    }
                  },
                  asyncRequestHelper: (res) => res?.data?.items || res?.data,
                  asyncRequestDeps: values[attributeRule?.asyncDeps],
                  getOptionLabel: (opt) => opt?.fullName || opt?.code,
                  getOptionSubLabel: attributeRule?.noSubLabel
                    ? undefined
                    : (opt) => opt?.username || opt?.name,
                })}
            disabled={
              Boolean(attributeRule.disabled) ||
              (isUpdate && !Boolean(attributeRule.canUpdate))
            }
            required={Boolean(attributeRule.isRequired)}
            {...(typeof handleOnChange === 'function'
              ? {
                  onChange: (val) =>
                    handleOnChange({ val, setFieldValue, values, attribute }),
                }
              : {})}
            isOptionEqualToValue={(opt, val) => opt?.id === val?.id}
            {...attribute.props}
          />
        )
      case FIELD_AREA.TABLE:
        return (
          <Field.Autocomplete
            name={
              name
                ? `${name}[${index}].${attribute.fieldName}`
                : `items[${index}].${attribute.fieldName}` || ''
            }
            placeholder={attribute.name || ''}
            {...(attributeRule?.isOptions
              ? {
                  options: attributeRule?.options
                    ? attributeRule?.options
                    : getOptions({ values, index, params }),
                  getOptionLabel: (opt) =>
                    opt?.name || opt?.code || t(opt?.text) || '',
                }
              : {
                  asyncRequest: (s) => {
                    if (typeof attributeRule?.table?.callApi === 'function') {
                      const callApi = attributeRule?.table?.callApi
                      return callApi({ values, index, params })
                    } else {
                      const params = {
                        keyword: s,
                        limit: ASYNC_SEARCH_LIMIT,
                        filter: attributeRule?.table?.filter,
                      }
                      return getListApi(attributeRule?.table || '', params)
                    }
                  },
                  asyncRequestHelper: (res) => res?.data?.items || res?.data,
                  asyncRequestDeps: attributeRule?.asyncRequestDeps
                    ? values[attributeRule?.asyncRequestDeps]
                    : params.row,
                  getOptionLabel: (opt) => opt?.fullName || opt?.code,
                  getOptionSubLabel: (opt) => opt?.username || opt?.name,
                })}
            disabled={
              Boolean(attributeRule.disabled) ||
              (isUpdate && !Boolean(attributeRule.canUpdate))
            }
            required={Boolean(attributeRule.isRequired)}
            {...(typeof handleOnChange === 'function'
              ? {
                  onChange: (val) =>
                    handleOnChange({
                      val,
                      index,
                      setFieldValue,
                      values,
                      attribute,
                    }),
                }
              : {})}
            isOptionEqualToValue={(opt, val) => opt?.id === val?.id}
            {...attribute.props}
          />
        )
      default:
        break
    }
  }
  return getElement()
}

export default FormAutocomplete
