const style = () => ({
  img: {
    maxWidth: '50%',
    height: 'auto',
  },
})

export default style
