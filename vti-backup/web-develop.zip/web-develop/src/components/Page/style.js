const style = (theme) => ({
  root: {
    display: 'flex',
    flexDirection: 'column',
    padding: theme.spacing(0, 2, 0),
    boxSizing: 'border-box',
    background: theme.palette.background.main,
    height: '100%',
    overflow: 'auto',
  },
})

export default style
