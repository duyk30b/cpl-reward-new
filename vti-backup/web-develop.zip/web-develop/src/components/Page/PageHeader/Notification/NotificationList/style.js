const style = () => ({
  list: {
    minHeight: 100,
    maxHeight: 'calc(100vh - 200px)',
    overflow: 'auto',
    padding: 0,
    position: 'relative',
  },
})

export default style
