import { NOTIFICATION_ENTITY_ENUM } from '~/common/constants/notification'
import DialogApproveSaleOrder from '~/modules/database/features/sale-order/list/dialogs/approve'
import { ROUTE as DATABASE_ROUTE } from '~/modules/database/routes/config'
import DialogApproveBoq from '~/modules/mesx/features/define-boq/list/dialogs/approve'
import DialogApproveMasterPlan from '~/modules/mesx/features/define-master-plan/list/dialogs/approve'
import DialogRejectMasterPlan from '~/modules/mesx/features/define-master-plan/list/dialogs/reject'
import DialogApproveMo from '~/modules/mesx/features/mo/list/dialogs/approve'
import DialogApproveProducingStep from '~/modules/mesx/features/producing-steps/dialogs/approve'
import DialogApproveRequestBuyMaterial from '~/modules/mesx/features/request-buy-material/list/dialogs/approve'
import DialogApproveRouting from '~/modules/mesx/features/routing/list/dialogs/approve'
import DialogApproveWorkCenter from '~/modules/mesx/features/work-center/list/dialogs/approve'
import { ROUTE as MESX_ROUTE } from '~/modules/mesx/routes/config'
import { ROUTE as MMSX_ROUTE } from '~/modules/mmsx/routes/config'
// @TODO: linh.taquang waiting BE
const REDIRECT_NOTIFICATION = {
  DEVICE_REQUEST_DETAIL: 0,
  DEVICE_ASSIGN_DETAIL: 1,
  JOB_LIST: 2,
  JOB_DETAIL: 3,
  REPAIR_REQUEST_DETAIL: 4,
  WARNING_SYSTEM: 5,
}
export const config = {
  [NOTIFICATION_ENTITY_ENUM.SALE_ORDER]: {
    path: DATABASE_ROUTE.SALE_ORDER.DETAILS.PATH,
    approve: DialogApproveSaleOrder,
  },
  [NOTIFICATION_ENTITY_ENUM.PRODUCING_STEP]: {
    path: MESX_ROUTE.PRODUCING_STEP.DETAIL.PATH,
    approve: DialogApproveProducingStep,
  },
  [NOTIFICATION_ENTITY_ENUM.WORK_CENTER]: {
    path: MESX_ROUTE.WORK_CENTER.DETAIL.PATH,
    approve: DialogApproveWorkCenter,
  },
  [NOTIFICATION_ENTITY_ENUM.ROUTING]: {
    path: MESX_ROUTE.ROUTING.DETAIL.PATH,
    approve: DialogApproveRouting,
  },
  [NOTIFICATION_ENTITY_ENUM.BOQ]: {
    path: MESX_ROUTE.DEFINE_BOQ.DETAIL.PATH,
    approve: DialogApproveBoq,
  },
  [NOTIFICATION_ENTITY_ENUM.MASTER_PLAN]: {
    path: MESX_ROUTE.MASTER_PLAN.DETAIL.PATH,
    approve: DialogApproveMasterPlan,
    reject: DialogRejectMasterPlan,
  },
  [NOTIFICATION_ENTITY_ENUM.MATERIAL_REQUEST_WARNING]: {
    path: MESX_ROUTE.REQUEST_BUY_MATERIAL.DETAIL.PATH,
    approve: DialogApproveRequestBuyMaterial,
  },
  [NOTIFICATION_ENTITY_ENUM.MANUFACTURING_ORDER]: {
    path: MESX_ROUTE.MO.DETAIL.PATH,
    approve: DialogApproveMo,
  },
  [REDIRECT_NOTIFICATION.DEVICE_REQUEST_DETAIL]: {
    path: MMSX_ROUTE.REQUEST_DEVICE.DETAIL.PATH,
  },
  [REDIRECT_NOTIFICATION.DEVICE_ASSIGN_DETAIL]: {
    path: MMSX_ROUTE.DEVICE_ASSIGN.DETAIL.PATH,
  },
  [REDIRECT_NOTIFICATION.JOB_LIST]: { path: MMSX_ROUTE.JOB.LIST.PATH },
  [REDIRECT_NOTIFICATION.REPAIR_REQUEST_DETAIL]: {
    path: MMSX_ROUTE.REPAIR_REQUEST.DETAIL.PATH,
  },
  [REDIRECT_NOTIFICATION.JOB_DETAIL]: { path: MMSX_ROUTE.JOB.DETAIL.PATH },
  [REDIRECT_NOTIFICATION.WARNING_SYSTEM]: {
    path: MMSX_ROUTE.WARNING_SYSTEM.LIST.PATH,
  },
}
