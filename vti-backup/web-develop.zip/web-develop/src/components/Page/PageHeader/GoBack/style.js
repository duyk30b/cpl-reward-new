const style = {
  root: {
    display: 'flex',
    alignItems: 'center',
    marginRight: 16,
  },
}

export default style
