import { Box, Grid, Typography } from '@mui/material'
import { isEmpty } from 'lodash'
import { PropTypes } from 'prop-types'
import { useTranslation } from 'react-i18next'

import { DATA_TYPE } from '~/common/constants'
import { convertUtcDateToLocalTz } from '~/utils'

import DataTable from '../DataTable'
import FileUploadButton from '../FileUploadButton'
import LabelValue from '../LabelValue'
import NumberFormatText from '../NumberFormat'
import Status from '../Status'
import Tabs from '../Tabs'
import TextField from '../TextField'

const getFieldHeader = (field, statusOptions) => {
  const { t } = useTranslation()
  switch (field?.attribute?.dataType) {
    case DATA_TYPE.TEXT:
      if (field?.attribute?.multiline) {
        return (
          <TextField
            name={field?.attribute?.fieldName || ''}
            label={field?.attribute?.name || ''}
            multiline
            rows={3}
            value={field?.attribute?.value || ''}
            readOnly
            sx={{
              'label.MuiFormLabel-root': {
                color: (theme) => theme.palette.subText.main,
              },
            }}
          />
        )
      } else if (field?.attribute?.isStatus) {
        return (
          <LabelValue
            label={t('common.status')}
            value={
              <Status options={statusOptions} value={field?.attribute?.value} />
            }
          />
        )
      } else {
        return (
          <LabelValue
            label={field?.attribute?.name || ''}
            value={field?.attribute?.value || ''}
          />
        )
      }
    case DATA_TYPE.NUMBER:
      return (
        <LabelValue
          label={field?.attribute?.name || ''}
          value={
            <NumberFormatText value={Number(field?.attribute?.value) || null} />
          }
        />
      )
    case DATA_TYPE.SELECTBOX_SINGLE:
      return (
        <LabelValue
          label={field?.attribute?.name || ''}
          value={
            field?.attribute?.getValue ||
            field?.attribute?.value?.fullName ||
            field?.attribute?.value?.name ||
            field?.attribute?.value?.code ||
            ''
          }
        />
      )
    case DATA_TYPE.SELECTBOX_MULTIPLE:
      return (
        <LabelValue
          label={field?.attribute.name || ''}
          value={
            field?.attribute.value?.map((item) => item?.name)?.join(', ') || ''
          }
        />
      )
    case DATA_TYPE.DATE:
      return (
        <LabelValue
          label={field?.attribute.name || ''}
          value={convertUtcDateToLocalTz(field?.attribute.value) || ''}
        />
      )
    case DATA_TYPE.FILE:
      return (
        <LabelValue
          label={field?.attribute.name || ''}
          value={
            <FileUploadButton
              value={field?.attribute.value || []}
              {...(field?.attribute?.onClick
                ? { onClick: field?.attribute.onClick }
                : {})}
              readOnly
            />
          }
        />
      )
    default:
      break
  }
}

export const GenerateHeader = ({ headerFields, statusOptions }) => {
  const headerFieldsFilter = (headerFields || [])?.filter((field) =>
    Boolean(field?.attributeRule?.display),
  )
  return (
    <Grid container rowSpacing={4 / 3} columnSpacing={{ xl: 8, xs: 4 }} ml={4}>
      {headerFieldsFilter?.map((field) => {
        if (field?.attribute.multiline || field.attribute?.isStatus) {
          return (
            <Grid item xs={12}>
              {getFieldHeader(field, statusOptions)}
            </Grid>
          )
        } else {
          return (
            <Grid item lg={6} xs={12}>
              {getFieldHeader(field, statusOptions)}
            </Grid>
          )
        }
      })}
    </Grid>
  )
}

const getFieldTable = (field) => {
  switch (field?.attribute?.dataType) {
    case DATA_TYPE.TEXT:
      return field?.attribute?.value?.name || field?.attribute?.value || ''
    case DATA_TYPE.NUMBER:
      return <NumberFormatText value={field?.attribute?.value ?? null} />
    case DATA_TYPE.SELECTBOX_SINGLE:
      return (
        field?.attribute?.getValue ||
        field?.attribute?.value?.fullName ||
        field?.attribute?.value?.name ||
        field?.attribute?.value?.code ||
        ''
      )
    case DATA_TYPE.SELECTBOX_MULTIPLE:
      return (
        field?.attribute?.value?.map((item) => item?.name)?.join(', ') || ''
      )
    case DATA_TYPE.DATE:
      return convertUtcDateToLocalTz(field?.attribute?.value) || ''
    default:
      break
  }
}
export const GenerateTable = ({ tableTitle, tableFields }) => {
  const columns = (tableFields || [])?.[0]?.attributes
    ?.filter((field) => Boolean(field?.attributeRule?.display))
    ?.map((field, index) => ({
      field: field?.attribute?.fieldName || '',
      headerName: field?.attribute?.name || '',
      width: 150,
      renderCell: (params) => getFieldTable(params.row?.attributes?.[index]),
    }))

  return (
    <>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 1,
        }}
      >
        <Typography variant="h4">{tableTitle}</Typography>
      </Box>
      <DataTable
        rows={tableFields || []}
        columns={columns}
        total={null}
        striped={false}
        hideSetting
        hideFooter
      />
    </>
  )
}
export const GenerateTabs = ({ tabList, valueTabs }) => {
  const item = valueTabs?.[0]
  if (tabList?.length > 1) {
    return (
      <Tabs list={tabList?.length > 1 ? tabList : []}>
        {valueTabs?.map((item) => (
          <>
            <Box sx={{ mt: 2 }}>
              <GenerateTable
                tableFields={item?.tableFields || []}
                tableTitle={item?.tableTitle}
              />
            </Box>
          </>
        ))}
      </Tabs>
    )
  } else {
    return (
      <GenerateTable
        tableFields={item?.tableFields}
        tableTitle={item?.tableTitle}
      />
    )
  }
}
const GenerateDetail = ({
  headerFields,
  tableFields,
  tableTitle,
  statusOptions,
}) => {
  return (
    <>
      <Grid container justifyContent="center">
        <Grid item xl={11} xs={12}>
          <GenerateHeader
            headerFields={headerFields}
            statusOptions={statusOptions}
          />
        </Grid>
      </Grid>
      {!isEmpty(tableFields) && (
        <Box sx={{ mt: 3 }}>
          <GenerateTable tableTitle={tableTitle} tableFields={tableFields} />
        </Box>
      )}
    </>
  )
}

GenerateDetail.defaultProps = {
  headerFields: [],
  tableFields: [],
  tableTitle: '',
  statusOptions: [],
}

GenerateDetail.propTypes = {
  headerFields: PropTypes.array,
  tableFields: PropTypes.array,
  tableTitle: PropTypes.string,
  statusOptions: PropTypes.array,
}

export default GenerateDetail
