export const ORDER_TYPE = {
  IMPORT: 0,
  EXPORT: 1,
}

export const ORDER_TYPE_MAP = {
  [ORDER_TYPE.IMPORT]: 'orderType.import',
  [ORDER_TYPE.EXPORT]: 'orderType.export',
}

export const ORDER_TYPE_OPTIONS = [
  {
    id: 0,
    name: 'orderType.import',
  },
  {
    id: 1,
    name: 'orderType.export',
  },
]

export const ORDER_TYPE_ENUM = {
  PO: 1,
  PRO: 2,
  SO: 3,
  Transfer: 4,
}

export const ORDER_STATUS = {
  PENDING: 0,
  CONFIRMED: 1,
  IN_PROGRESS: 2,
  APPROVED: 3,
  COMPLETED: 4,
  REJECTED: 5,
}

export const ORDER_STATUS_MAP = {
  [ORDER_STATUS.PENDING]: 'orderStatus.pending',
  [ORDER_STATUS.CONFIRMED]: 'orderStatus.confirmed',
  [ORDER_STATUS.IN_PROGRESS]: 'orderStatus.inProgress',
  [ORDER_STATUS.APPROVED]: 'orderStatus.approved',
  [ORDER_STATUS.REJECTED]: 'orderStatus.rejected',
  [ORDER_STATUS.COMPLETED]: 'orderStatus.completed',
}

export const ORDER_STATUS_OPTIONS = [
  {
    id: 0,
    text: 'orderStatus.pending',
    color: 'pending',
  },
  {
    id: 1,
    text: 'orderStatus.confirmed',
    color: 'confirmed',
  },
  {
    id: 2,
    text: 'orderStatus.inProgress',
    color: 'inProgress',
  },
  {
    id: 3,
    text: 'orderStatus.approved',
    color: 'approved',
  },
  {
    id: 4,
    text: 'orderStatus.completed',
    color: 'completed',
  },
  {
    id: 5,
    text: 'orderStatus.rejected',
    color: 'rejected',
  },
]

export const DEFAULT_ITEM_TYPE_ENUM = {
  MATERIAL: {
    id: 1,
    code: '00',
    name: 'itemType.material',
  },
  PRODUCT: {
    id: 2,
    code: '01',
    name: 'itemType.product',
  },
  SEMI: {
    id: 2,
    code: '02',
    name: 'itemType.semi',
  },
}

export const DEFAULT_ITEM_TYPES = {
  code: ['00', '04', '05', '06'],
}

export const ITEM_TYPES_TO_INT = {
  code: ['04', '06', '01', '02'],
}

export const DEFAULT_UNITS = [
  {
    id: 1,
    name: 'cm',
  },
  {
    id: 2,
    name: 'dm',
  },
  {
    id: 3,
    name: 'm',
  },
]

export const DEFAULT_UNITS_MAP = {
  1: 'cm',
  2: 'dm',
  3: 'm',
}

export const WEIGHT_UNITS = [
  {
    id: 1,
    name: 'g',
  },
  {
    id: 2,
    name: 'kg',
  },
  {
    id: 3,
    name: 'tấn',
  },
]

export const WEIGHT_UNITS_MAP = {
  1: 'g',
  2: 'kg',
  3: 'tấn',
}
export const ITEM_TYPE_PRODUCT = 2
export const SALE_ORDER_STATUS = {
  PENDING: 0,
  CONFIRMED: 1,
}

export const SALE_ORDER_STATUS_MAP = {
  [SALE_ORDER_STATUS.PENDING]: 'orderStatus.pending',
  [SALE_ORDER_STATUS.CONFIRMED]: 'orderStatus.confirmed',
}

export const SALE_ORDER_STATUS_OPTIONS = [
  {
    id: 0,
    text: 'orderStatus.pending',
    color: 'pending',
  },
  {
    id: 1,
    text: 'orderStatus.confirmed',
    color: 'confirmed',
  },
]

export const PURCHASED_ORDER_STATUS = {
  PENDING: 0,
  CONFIRMED: 1,
  REJECTED: 2,
  DRAFT: 3,
  TO_DELIVERY: 4,
  DELIVERING: 5,
  COMPLETED: 6,
  CANCEL: 7,
}

export const PURCHASED_ORDER_STATUS_MAP = {
  [PURCHASED_ORDER_STATUS.DRAFT]: 'purchasedOrderStatus.draft',
  [PURCHASED_ORDER_STATUS.PENDING]: 'purchasedOrderStatus.pending',
  [PURCHASED_ORDER_STATUS.REJECTED]: 'purchasedOrderStatus.rejected',
  [PURCHASED_ORDER_STATUS.CONFIRMED]: 'purchasedOrderStatus.confirmed',
  [PURCHASED_ORDER_STATUS.TO_DELIVERY]: 'purchasedOrderStatus.toDelivery',
  [PURCHASED_ORDER_STATUS.DELIVERING]: 'purchasedOrderStatus.inProgress',
  [PURCHASED_ORDER_STATUS.COMPLETED]: 'purchasedOrderStatus.completed',
  [PURCHASED_ORDER_STATUS.CANCEL]: 'purchasedOrderStatus.cancel',
}

export const PURCHASED_ORDER_STATUS_OPTIONS = [
  {
    id: 3,
    text: 'purchasedOrderStatus.draft',
    color: 'draft',
  },
  {
    id: 0,
    text: 'purchasedOrderStatus.pending',
    color: 'pending',
  },
  {
    id: 2,
    text: 'purchasedOrderStatus.rejected',
    color: 'rejected',
  },
  {
    id: 1,
    text: 'purchasedOrderStatus.confirmed',
    color: 'confirmed',
  },
  {
    id: 4,
    text: 'purchasedOrderStatus.toDelivery',
    color: 'inProgress',
  },
  {
    id: 5,
    text: 'purchasedOrderStatus.inProgress',
    color: 'inProgress',
  },
  {
    id: 6,
    text: 'purchasedOrderStatus.completed',
    color: 'completed',
  },
  {
    id: 7,
    text: 'purchasedOrderStatus.cancel',
    color: 'cancel',
  },
]
export const TYPE_ITEM_EXPORT = {
  ITEM_GROUP: 1,
  ITEM_TYPE: 2,
  ITEM_UNIT: 3,
}
export const TYPE_SALE_EXPORT = {
  CUSTOMER: 1,
  SALE_ORDER: 2,
}

export const ERROR_TYPE_PRIORITY = {
  LOW: 0,
  MEDIUM: 1,
  HIGH: 2,
}

export const ERROR_TYPE_PRIORITY_MAP = {
  [ERROR_TYPE_PRIORITY.LOW]: 'errorType.low',
  [ERROR_TYPE_PRIORITY.MEDIUM]: 'errorType.medium',
  [ERROR_TYPE_PRIORITY.HIGH]: 'errorType.high',
}

export const ERROR_TYPE_PRIORITY_OPTION = [
  {
    id: 0,
    text: 'errorType.low',
    color: 'confirmed',
  },
  {
    id: 1,
    text: 'errorType.medium',
    color: 'inProgress',
  },
  {
    id: 2,
    text: 'errorType.high',
    color: 'rejected',
  },
]

export const OBLIGATORY_ENUM = {
  NO: 0,
  YES: 1,
}

export const MAINTENANCE_PERIOD_UNIT = {
  DAY: 0,
  MONTH: 1,
  YEAR: 2,
}

export const REPORT_TYPE = {
  DAY: 0,
  WEEK: 1,
  MONTH: 2,
  QUARTER: 3,
  YEAR: 4,
}

export const OPERATION_VALUE_TIME_OPTIONS = [
  {
    id: REPORT_TYPE.DAY,
    text: 'general:days',
  },
  {
    id: REPORT_TYPE.MONTH,
    text: 'general:months',
  },
  {
    id: REPORT_TYPE.QUARTER,
    text: 'general:quarters',
  },
]

export const OPERATION_VALUE_MONTH_OPTION = [
  {
    id: 0,
    text: 'general:month.jan',
  },
  {
    id: 1,
    text: 'general:month.feb',
  },
  {
    id: 2,
    text: 'general:month.mar',
  },
  {
    id: 3,
    text: 'general:month.apr',
  },
  {
    id: 4,
    text: 'general:month.may',
  },
  {
    id: 5,
    text: 'general:month.jun',
  },
  {
    id: 6,
    text: 'general:month.jul',
  },
  {
    id: 7,
    text: 'general:month.aug',
  },
  {
    id: 8,
    text: 'general:month.sep',
  },
  {
    id: 9,
    text: 'general:month.oct',
  },
  {
    id: 10,
    text: 'general:month.nov',
  },
  {
    id: 11,
    text: 'general:month.dec',
  },
]

export const OPERATION_VALUE_QUARTER_OPTIONS = [
  {
    id: 1,
    text: 'general:quarter.one',
  },
  {
    id: 2,
    text: 'general:quarter.two',
  },
  {
    id: 3,
    text: 'general:quarter.three',
  },
  {
    id: 4,
    text: 'general:quarter.four',
  },
]

export const MAINTENANCE_PERIOD_UNIT_OPTIONS = [
  {
    id: MAINTENANCE_PERIOD_UNIT.DAY,
    text: 'general:days',
  },
  {
    id: MAINTENANCE_PERIOD_UNIT.MONTH,
    text: 'general:months',
  },
  {
    id: MAINTENANCE_PERIOD_UNIT.YEAR,
    text: 'general:years',
  },
]

export const MAINTENANCE_PERIOD_UNIT_MAP = {
  [MAINTENANCE_PERIOD_UNIT.DAY]: 'general:days',
  [MAINTENANCE_PERIOD_UNIT.MONTH]: 'general:months',
  [MAINTENANCE_PERIOD_UNIT.YEAR]: 'general:years',
}

export const MAINTENANCE_JOB_TYPE = {
  CHECK: 0,
  MAINTENANCE: 1,
}

export const MAINTENANCE_JOB_TYPE_OPTIONS = [
  {
    id: MAINTENANCE_JOB_TYPE.CHECK,
    text: 'common.check',
  },
  {
    id: MAINTENANCE_JOB_TYPE.MAINTENANCE,
    text: 'common.maintenance',
  },
]

export const MAINTENANCE_JOB_TYPE_MAP = {
  [MAINTENANCE_JOB_TYPE.CHECK]: 'common.check',
  [MAINTENANCE_JOB_TYPE.MAINTENANCE]: 'common.maintenance',
}

export const IMPORT_TYPE = {
  DEVICE_GROUP: 0,
  CHECKLIST_TEMPLATE: 1,
  INSTALLATION_TEMPLATE: 2,
  ATTRIBUTE_TYPE: 3,
  MAINTENANCE_ATTRIBUTE: 4,
  SUPPLY_GROUP: 5,
  SUPPLY: 6,
  DEVICE: 7,
  UNIT: 8,
  MAINTENANCE_TEAM: 11,
  DEVICE_REQUEST: 12,
  AREA: 13,
  ERROR_TYPE: 14,
  VENDOR: 15,
  DEVICE_TYPE: 16,
  DEVICE_ASSIGNMENT: 17,
  ARTICLE_DEVICE_GROUP: 18,
  MAINTENANCE_TEMPLATE: 19,
  ACCREDITATION_TEMPLATE: 20,
  JOB: 21,
  WAREHOUSE: 22,
  INVENTORY_DEVICE_GROUP: 23,
  INVENTORY_SUPPLY: 24,
  DEVICE_INVENTORY: 25,
  DEVICE_NAME: 26,
}

export const SOURCE_MANAGE_ENUM = {
  MMSX: 0,
  WFX: 1,
}

export const PURCHASED_ORDER_ACTION_TYPE = {
  REQUEST_CONFIRM: 1,
  ORDER: 5,
  COMPLETE: 6,
  CANCEL: 8,
}

export const PURCHASED_ORDER_TYPE = {
  INLAND: 0,
  IMPORT: 1,
}

export const PURCHASED_ORDER_TYPE_MAP = {
  [PURCHASED_ORDER_TYPE.INLAND]: 'purchasedOrder.inlandType',
  [PURCHASED_ORDER_TYPE.IMPORT]: 'purchasedOrder.importType',
}

export const PURCHASED_ORDER_TYPE_OPTIONS = [
  {
    id: 0,
    text: 'purchasedOrder.inlandType',
  },
  {
    id: 1,
    text: 'purchasedOrder.importType',
  },
]

export const PAY_STATUS = {
  UNPAID: 0,
  PARTIAL: 1,
  FULL: 2,
}

export const PAY_STATUS_MAP = {
  [PAY_STATUS.UNPAID]: 'purchasedOrder.unpaid',
  [PAY_STATUS.PARTIAL]: 'purchasedOrder.partial',
  [PAY_STATUS.FULL]: 'purchasedOrder.full',
}

export const PAY_STATUS_OPTIONS = [
  {
    id: 0,
    text: 'purchasedOrder.unpaid',
  },
  {
    id: 1,
    text: 'purchasedOrder.partial',
  },
  {
    id: 2,
    text: 'purchasedOrder.full',
  },
]

export const DELIVERY_STATUS = {
  TO_DELIVERY: 0,
  DELIVERING: 1,
  DELIVERED: 2,
}

export const DELIVERY_STATUS_MAP = {
  [DELIVERY_STATUS.TO_DELIVERY]: 'purchasedOrder.toDelivery',
  [DELIVERY_STATUS.DELIVERING]: 'purchasedOrder.delivering',
  [DELIVERY_STATUS.DELIVERED]: 'purchasedOrder.delivered',
}

export const DELIVERY_STATUS_OPTIONS = [
  {
    id: 0,
    text: 'purchasedOrder.toDelivery',
  },
  {
    id: 1,
    text: 'purchasedOrder.delivering',
  },
  {
    id: 2,
    text: 'purchasedOrder.delivered',
  },
]

export const VENDOR_GROUP = {
  MATERIAL: 0,
  ITEM_SERVICE: 1,
  OUTSOURCING: 2,
}

export const VENDOR_GROUP_MAP = {
  [VENDOR_GROUP.MATERIAL]: 'defineVendor.material',
  [VENDOR_GROUP.ITEM_SERVICE]: 'defineVendor.itemService',
  [VENDOR_GROUP.OUTSOURCING]: 'defineVendor.outSourcing',
}

export const VENDOR_GROUP_OPTIONS = [
  {
    id: 0,
    text: 'defineVendor.material',
  },
  {
    id: 1,
    text: 'defineVendor.itemService',
  },
  {
    id: 2,
    text: 'defineVendor.outSourcing',
  },
]

export const VENDOR_TYPE = {
  ENTERPRISE: 0,
  HOUSEHOLD_BUSINESS: 1,
}

export const VENDOR_TYPE_MAP = {
  [VENDOR_TYPE.ENTERPRISE]: 'defineVendor.enterprise',
  [VENDOR_TYPE.HOUSEHOLD_BUSINESS]: 'defineVendor.householdBusiness',
}

export const VENDOR_TYPE_OPTIONS = [
  {
    id: 0,
    text: 'defineVendor.enterprise',
  },
  {
    id: 1,
    text: 'defineVendor.householdBusiness',
  },
]

export const VENDOR_CRITERIA_SCORE = {
  LOW: {
    score: 1,
    text: 'defineVendor.low',
  },
  MEDIUM: {
    score: 2,
    text: 'defineVendor.medium',
  },
  HIGH: {
    score: 3,
    text: 'defineVendor.high',
  },
}
