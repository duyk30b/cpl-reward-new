import React from 'react'

import { IconButton } from '@mui/material'
import Box from '@mui/material/Box'
import { isEmpty } from 'lodash'
import { useTranslation } from 'react-i18next'

import {
  ASYNC_SEARCH_LIMIT,
  MODAL_MODE,
  TEXTFIELD_REQUIRED_LENGTH,
} from '~/common/constants'
import { useApp } from '~/common/hooks/useApp'
import Button from '~/components/Button'
import DataTable from '~/components/DataTable'
import { Field } from '~/components/Formik'
import Icon from '~/components/Icon'
import { searchItemUnitsApi } from '~/modules/database/redux/sagas/item-unit-setting/search-item-units'

function ItemsConvertUnit(props) {
  const { t } = useTranslation(['database'])
  const { items, mode, arrayHelpers, setFieldValue, values } = props
  const { scrollToBottom } = useApp()

  const isView = mode === MODAL_MODE.DETAIL
  const columns = [
    {
      field: 'name',
      headerName: t('defineItem.convertUnit.unitLevel'),
      renderCell: (params, index) => {
        return isView ? (
          <>{params.row?.name}</>
        ) : (
          <Field.TextField
            name={`convertUnitItem[${index}].name`}
            value={items[index]?.name || ''}
            disabled={index === 0 && !isEmpty(values?.itemUnit)}
            inputProps={{
              maxLength: TEXTFIELD_REQUIRED_LENGTH.CODE_50.MAX,
            }}
          />
        )
      },
    },
    {
      field: 'unitName',
      headerName: t('defineItem.convertUnit.unitName'),
      width: 180,
      renderCell: (params, index) => {
        return isView ? (
          <>{params.row?.itemUnit?.name}</>
        ) : (
          <Field.Autocomplete
            name={`convertUnitItem[${index}].itemUnit`}
            asyncRequest={(s) =>
              searchItemUnitsApi({
                keyword: s,
                limit: ASYNC_SEARCH_LIMIT,
              })
            }
            asyncRequestHelper={(res) => res?.data?.items}
            getOptionLabel={(opt) => opt?.name}
            isOptionEqualToValue={(opt, val) => opt?.id === val?.id}
            onChange={() => {
              setFieldValue(`convertUnitItem[${index}]['itemUnit']`, false)
            }}
            disabled={index === 0 && !isEmpty(values?.itemUnit)}
          />
        )
      },
    },
    {
      field: 'quantity',
      headerName: t('defineItem.convertUnit.quantity'),
      width: 180,
      renderCell: (params, index) => {
        return isView ? (
          <>{params.row?.quantity}</>
        ) : (
          <Field.TextField
            name={`convertUnitItem[${index}].quantity`}
            value={items[index]?.quantity || ''}
            numberProps={{
              decimalScale: 3,
            }}
          />
        )
      },
    },

    {
      field: 'remove',
      headerName: t('defineItem.action'),
      width: 50,
      hide: isView,
      sticky: 'right',
      renderCell: (params, index) => {
        const idx = items.findIndex((item) => item.id === params.row.id)
        return isView || index === 0 ? null : (
          <IconButton
            size="small"
            onClick={() => arrayHelpers.remove(idx)}
            disabled={items?.length === 1}
          >
            <Icon name="remove" />
          </IconButton>
        )
      },
    },
  ]

  return (
    <>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 1,
        }}
      >
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'flex-end',
            width: '100%',
          }}
        >
          {!isView && (
            <Button
              variant="outlined"
              onClick={() => {
                arrayHelpers.push({
                  itemUnit: null,
                  name: '',
                  quantity: 1,
                  id: new Date().getTime(),
                })
                scrollToBottom()
              }}
            >
              {t('defineItem.convertUnit.addItem')}
            </Button>
          )}
        </Box>
      </Box>
      <DataTable
        rows={items}
        columns={columns}
        total={100}
        hideSetting
        hideFooter
        striped={false}
        tableSettingKey="define-item-table"
      />
    </>
  )
}

export default ItemsConvertUnit
