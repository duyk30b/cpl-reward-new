import * as Yup from 'yup'

import {
  NUMBER_FIELD_REQUIRED_SIZE,
  TEXTFIELD_REQUIRED_LENGTH,
} from '~/common/constants'

export const validationSchema = (t) => {
  return Yup.object().shape({
    code: Yup.string().required(t('general:form.required')),
    name: Yup.string()
      .required(t('general:form.required'))
      .min(
        TEXTFIELD_REQUIRED_LENGTH.CODE_3.MAX,
        t('general:form.minLength', {
          min: TEXTFIELD_REQUIRED_LENGTH.CODE_3.MAX,
        }),
      ),
    orderedAt: Yup.date().nullable().required(t('general:form.required')),
    vendor: Yup.object().nullable().required(t('general:form.required')),
    currencyUnit: Yup.object().nullable().required(t('general:form.required')),
    purchasedByUser: Yup.object()
      .nullable()
      .required(t('general:form.required')),
    receiveDate: Yup.date().nullable().required(t('general:form.required')),
    items: Yup.array().of(
      Yup.object().shape({
        itemId: Yup.object().nullable().required(t('general:form.required')),
        price: Yup.number()
          .required(t('general:form.required'))
          .min(
            NUMBER_FIELD_REQUIRED_SIZE.PO_PRICE.MIN,
            t('general:form.minNumber', {
              min: NUMBER_FIELD_REQUIRED_SIZE.PO_PRICE.MIN,
            }),
          )
          .max(
            NUMBER_FIELD_REQUIRED_SIZE.PO_PRICE.MAX,
            t('general:form.maxNumber', {
              max: NUMBER_FIELD_REQUIRED_SIZE.PO_PRICE.MAX,
            }),
          ),
        deliveryPlan: Yup.date().nullable(),
        // .test(_, (_, context) => {
        //   if (true) {
        //     return context.createError({
        //       path: context.path,
        //       message: t('general:form.required'),
        //     })
        //   }
        // }),
        quantity: Yup.number()
          .required(t('general:form.required'))
          .min(
            NUMBER_FIELD_REQUIRED_SIZE.PO_QUANTITY.MIN,
            t('general:form.minNumber', {
              min: NUMBER_FIELD_REQUIRED_SIZE.PO_QUANTITY.MIN,
            }),
          )
          .max(
            NUMBER_FIELD_REQUIRED_SIZE.PO_QUANTITY.MAX,
            t('general:form.maxNumber', {
              max: NUMBER_FIELD_REQUIRED_SIZE.PO_QUANTITY.MAX,
            }),
          ),
        discount: Yup.number()
          .nullable()
          .required(t('general:form.required'))
          .min(
            NUMBER_FIELD_REQUIRED_SIZE.DISCOUNT.MIN,
            t('general:form.minNumber', {
              min: NUMBER_FIELD_REQUIRED_SIZE.DISCOUNT.MIN,
            }),
          )
          .max(
            NUMBER_FIELD_REQUIRED_SIZE.DISCOUNT.MAX,
            t('general:form.maxNumber', {
              max: NUMBER_FIELD_REQUIRED_SIZE.DISCOUNT.MAX,
            }),
          ),
      }),
    ),
    invoiceInfo: Yup.array().of(
      Yup.object().shape({
        invoiceCode: Yup.string().min(
          TEXTFIELD_REQUIRED_LENGTH.CODE_5.MAX,
          t('general:form.minLength', {
            min: TEXTFIELD_REQUIRED_LENGTH.CODE_5.MAX,
          }),
        ),
      }),
    ),
  })
}
