import React from 'react'

import { IconButton } from '@mui/material'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import { useTheme } from '@mui/styles'
import { sumBy } from 'lodash'
import { PropTypes } from 'prop-types'
import { useTranslation } from 'react-i18next'

import { MODAL_MODE } from '~/common/constants'
import { useApp } from '~/common/hooks/useApp'
import Button from '~/components/Button'
import DataTable from '~/components/DataTable'
import { Field } from '~/components/Formik'
import Icon from '~/components/Icon'
import NumberFormatText from '~/components/NumberFormat'

function ItemSettingTable({ items, mode, arrayHelpers, itemList, isDisable }) {
  const { t } = useTranslation(['mesx'])
  const theme = useTheme()
  const { scrollToBottom } = useApp()

  const isView = mode === MODAL_MODE.DETAIL

  const getColumns = () => {
    return [
      {
        field: 'id',
        headerName: '#',
        width: 50,
        renderCell: (_, index) => {
          return index + 1
        },
      },
      {
        field: 'itemCode',
        headerName: t('purchasedOrder.item.code'),
        width: 150,
        renderCell: (params, index) => {
          const itemIdCodeList = items.map((item) => item.itemId)
          return isView ? (
            <>{params.row?.item?.code}</>
          ) : (
            <Field.Autocomplete
              name={`items[${index}].itemId`}
              options={itemList}
              getOptionLabel={(opt) => opt?.code}
              getOptionSubLabel={(opt) => opt?.name}
              getOptionDisabled={(opt) =>
                itemIdCodeList.some(
                  (id) =>
                    id === (opt?.id || opt?.itemId) &&
                    (opt?.id || opt?.itemId) !== items[index]?.itemId,
                )
              }
              disabled={isDisable}
            />
          )
        },
      },
      {
        field: 'itemName',
        headerName: t('purchasedOrder.item.name'),
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <>{params.row?.item?.name}</>
          ) : (
            <Field.TextField name={`items[${index}].itemId.name`} disabled />
          )
        },
      },
      {
        field: 'itemUnit',
        headerName: t('purchasedOrder.item.unit'),
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <>{params.row?.item?.itemUnit?.name}</>
          ) : (
            <Field.TextField
              name={`items[${index}].itemId.itemUnit.name`}
              disabled
            />
          )
        },
      },
      {
        field: 'price',
        headerName: t('purchasedOrder.item.price'),
        align: 'right',
        headerAlign: 'left',
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <NumberFormatText value={params.row?.price} />
          ) : (
            <Field.TextField
              name={`items[${index}].price`}
              numberProps={{
                decimalScale: 2,
                thousandSeparator: true,
              }}
              disabled={isDisable}
            />
          )
        },
      },
      {
        field: 'quantity',
        headerName: t('purchasedOrder.item.quantity'),
        align: 'right',
        headerAlign: 'left',
        width: 100,
        renderCell: (params, index) => {
          const { quantity } = params.row
          return isView ? (
            <>{+quantity}</>
          ) : (
            <Field.TextField
              name={`items[${index}].quantity`}
              numberProps={{
                decimalScale: 3,
                thousandSeparator: true,
              }}
              disabled={isDisable}
            />
          )
        },
      },
      {
        field: 'discount',
        headerName: t('purchasedOrder.item.discount'),
        align: 'right',
        headerAlign: 'left',
        width: 100,
        renderCell: (params, index) => {
          const { discount } = params.row
          return isView ? (
            <>{discount}</>
          ) : (
            <Field.TextField
              name={`items[${index}].discount`}
              numberProps={{
                decimalScale: 3,
              }}
              disabled={isDisable}
            />
          )
        },
      },
      {
        field: 'totalPrice',
        headerName: t('purchasedOrder.item.totalPrice'),
        align: 'right',
        headerAlign: 'left',
        width: 100,
        renderCell: (params, index) => {
          const { price, quantity, discount } = params.row
          const totalPrice = (price * quantity * (100 - discount)) / 100
          return isView ? (
            <NumberFormatText value={totalPrice} />
          ) : (
            <Field.TextField
              name={`items[${index}].totalPrice`}
              value={totalPrice}
              numberProps={{
                decimalScale: 3,
                thousandSeparator: true,
              }}
              disabled
            />
          )
        },
      },
      {
        field: 'remove',
        headerName: '',
        width: 60,
        align: 'center',
        hide: isView,
        sticky: 'right',
        renderCell: (params, index) => {
          return (
            <IconButton
              onClick={() => arrayHelpers.remove(index)}
              disabled={items?.length === 1 || isDisable}
              size="large"
            >
              <Icon name="remove" />
            </IconButton>
          )
        },
      },
    ]
  }

  return (
    <>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'flex-end',
          alignItems: 'center',
          mb: 2,
        }}
      >
        {!isView && (
          // <ButtonInput arrayHelpers={arrayHelpers} defaultItems={defaultItems} />
          <Button
            variant="outlined"
            onClick={() => {
              arrayHelpers.push({
                id: new Date().getTime(),
                itemId: null,
                quantity: 0,
                price: 0,
                discount: 0,
                totalPrice: 0,
                deliveryPlan: null,
              })
              scrollToBottom()
            }}
            disabled={isDisable}
          >
            {t('purchasedOrder.item.addItem')}
          </Button>
        )}
      </Box>
      <DataTable
        rows={items}
        columns={getColumns()}
        total={items?.length}
        hideSetting
        hideFooter
        striped={false}
      />
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'flex-end',
          alignItems: 'center',
          mt: 2,
          py: 1,
          pr: 2,
          backgroundColor: theme.palette.primary.a1,
          borderRadius: 1,
        }}
      >
        <Typography variant="h4">{t('purchasedOrder.item.total')}</Typography>
        <Typography variant="h4" ml={2}>
          {
            <NumberFormatText
              value={sumBy(items, 'totalPrice')}
              formatter="price"
            />
          }
        </Typography>
      </Box>
    </>
  )
}

ItemSettingTable.defaultProps = {
  items: [],
  mode: '',
  arrayHelpers: {},
}

ItemSettingTable.propTypes = {
  arrayHelpers: PropTypes.shape(),
  items: PropTypes.array,
  mode: PropTypes.string,
}

export default ItemSettingTable
