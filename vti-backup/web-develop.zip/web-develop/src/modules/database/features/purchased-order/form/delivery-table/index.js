import React from 'react'

import { Box, FormControlLabel, Grid } from '@mui/material'
import { useTranslation } from 'react-i18next'

import {
  ASYNC_SEARCH_LIMIT,
  MODAL_MODE,
  TEXTFIELD_REQUIRED_LENGTH,
} from '~/common/constants'
import Checkbox from '~/components/Checkbox'
import DataTable from '~/components/DataTable'
import { Field } from '~/components/Formik'
import LV from '~/components/LabelValue'
import { searchDeliveryMethodApi } from '~/modules/database/redux/sagas/delivery-method/search-delivery-method'
import { convertUtcDateToLocalTz } from '~/utils'

function DeliveryTable({
  values,
  items,
  mode,
  purchasedOrderDetails,
  isDisable,
}) {
  const { t } = useTranslation(['mesx'])
  const isView = mode === MODAL_MODE.DETAIL

  const getColumns = () => {
    return [
      {
        field: 'id',
        headerName: '#',
        width: 50,
        renderCell: (_, index) => {
          return index + 1
        },
      },
      {
        field: 'itemCode',
        headerName: t('purchasedOrder.item.code'),
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <>{params.row?.item?.code}</>
          ) : (
            <Field.TextField name={`items[${index}].itemId.code`} disabled />
          )
        },
      },
      {
        field: 'itemName',
        headerName: t('purchasedOrder.item.name'),
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <>{params.row?.item?.name}</>
          ) : (
            <Field.TextField name={`items[${index}].itemId.name`} disabled />
          )
        },
      },
      {
        field: 'deliveryPlan',
        headerName: t('purchasedOrder.deliveryPlan'),
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <>{convertUtcDateToLocalTz(params.row?.planDeliveryAt)}</>
          ) : (
            <Field.DatePicker
              name={`items[${index}].deliveryPlan`}
              {...(values?.oneTimeDelivery
                ? { value: values?.receiveDate }
                : {})}
              disabled={values?.oneTimeDelivery || isDisable}
            />
          )
        },
      },
      {
        field: 'description',
        headerName: t('purchasedOrder.description'),
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <>{params.row?.description}</>
          ) : (
            <Field.TextField
              name={`items[${index}].description`}
              disabled={isDisable}
            />
          )
        },
      },
    ]
  }

  return (
    <>
      <Grid container columnSpacing={{ xl: 3, xs: 2 }} rowSpacing={4 / 3}>
        {isView ? (
          <>
            <Grid item xs={12} lg={2}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={purchasedOrderDetails?.oneTimeDelivery}
                    name="oneTimeDelivery"
                    disabled
                  />
                }
                label={t('purchasedOrder.oneTimeDelivery')}
                sx={{ my: -1 }}
              />
            </Grid>
            <Grid item xs={12} lg={3}>
              <LV
                label={t('purchasedOrder.receiveDate')}
                value={convertUtcDateToLocalTz(
                  purchasedOrderDetails?.deliverAt,
                )}
              />
            </Grid>
            <Grid item xs={12} lg={4}>
              <LV
                label={t('purchasedOrder.receiveByUser')}
                value={purchasedOrderDetails?.receiver}
              />
            </Grid>
            <Grid item xs={12} lg={3}>
              <LV
                label={t('purchasedOrder.phone')}
                value={purchasedOrderDetails?.receiverPhoneNumber}
              />
            </Grid>
            <Grid item xs={12} lg={5}>
              <LV
                label={t('purchasedOrder.deliveryMethod')}
                value={purchasedOrderDetails?.shippingMethod?.name}
              />
            </Grid>
            <Grid item xs={12} lg={7}>
              <LV
                label={t('purchasedOrder.address')}
                value={purchasedOrderDetails?.address}
              />
            </Grid>
          </>
        ) : (
          <>
            <Grid item xs={12} lg={2}>
              <FormControlLabel
                control={<Field.Checkbox name="oneTimeDelivery" />}
                label={t('purchasedOrder.oneTimeDelivery')}
                disabled={isDisable}
              />
            </Grid>
            <Grid item xs={12} lg={3}>
              <Field.DatePicker
                name="receiveDate"
                label={t('purchasedOrder.receiveDate')}
                placeholder={t('purchasedOrder.receiveDate')}
                labelWidth={120}
                required
                disabled={isDisable}
              />
            </Grid>
            <Grid item xs={12} lg={4}>
              <Field.TextField
                name="receiveByUser"
                label={t('purchasedOrder.receiveByUser')}
                placeholder={t('purchasedOrder.receiveByUser')}
                inputProps={{
                  maxLength: TEXTFIELD_REQUIRED_LENGTH.COMMON.MAX,
                }}
                labelWidth={120}
                disabled={isDisable}
              />
            </Grid>
            <Grid item xs={12} lg={3}>
              <Field.TextField
                name="phoneReceiver"
                label={t('purchasedOrder.phone')}
                placeholder={t('purchasedOrder.phone')}
                inputProps={{
                  maxLength: TEXTFIELD_REQUIRED_LENGTH.COMMON.MAX,
                }}
                labelWidth={120}
                disabled={isDisable}
              />
            </Grid>
            <Grid item xs={12} lg={5}>
              <Field.Autocomplete
                name="deliveryMethod"
                label={t('purchasedOrder.deliveryMethod')}
                placeholder={t('purchasedOrder.deliveryMethod')}
                asyncRequest={(s) =>
                  searchDeliveryMethodApi({
                    keyword: s,
                    limit: ASYNC_SEARCH_LIMIT,
                  })
                }
                asyncRequestHelper={(res) => res?.data?.items}
                getOptionLabel={(opt) => opt?.code}
                getOptionSubLabel={(opt) => opt?.name}
                isOptionEqualToValue={(opt, val) => opt?.id === val?.id}
                labelWidth={120}
                disabled={isDisable}
              />
            </Grid>
            <Grid item xs={12} lg={7}>
              <Field.TextField
                name="address"
                label={t('purchasedOrder.address')}
                placeholder={t('purchasedOrder.address')}
                inputProps={{
                  maxLength: TEXTFIELD_REQUIRED_LENGTH.COMMON.MAX,
                }}
                labelWidth={120}
                disabled={isDisable}
              />
            </Grid>
          </>
        )}
      </Grid>
      <Box mt={2}>
        <DataTable
          rows={items}
          columns={getColumns()}
          total={items?.length}
          hideSetting
          hideFooter
          striped={false}
        />
      </Box>
    </>
  )
}

export default DeliveryTable
