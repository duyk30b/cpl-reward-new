import React, { useState, useEffect } from 'react'

import IconButton from '@mui/material/IconButton'
import { Box } from '@mui/system'
import { useTranslation } from 'react-i18next'
import { useHistory } from 'react-router-dom'
import * as Yup from 'yup'

import { BULK_ACTION } from '~/common/constants'
import { API_URL } from '~/common/constants/apiUrl'
import { useQueryState } from '~/common/hooks'
import Button from '~/components/Button'
import DataTable from '~/components/DataTable'
import Dialog from '~/components/Dialog'
import { Field } from '~/components/Formik'
import Icon from '~/components/Icon'
import LV from '~/components/LabelValue'
import NumberFormatText from '~/components/NumberFormat'
import Page from '~/components/Page'
import Status from '~/components/Status'
import {
  DELIVERY_STATUS_OPTIONS,
  PAY_STATUS_OPTIONS,
  PURCHASED_ORDER_ACTION_TYPE,
  PURCHASED_ORDER_STATUS,
  PURCHASED_ORDER_STATUS_OPTIONS,
} from '~/modules/database/constants'
import usePurchasedOrder from '~/modules/database/redux/hooks/usePurchasedOrder'
import { ROUTE } from '~/modules/database/routes/config'
import {
  convertFilterParams,
  convertSortParams,
  convertUtcDateToLocalTz,
} from '~/utils'

import QuickFilter from './quick-filter'

const breadcrumbs = [
  // {
  //   title: 'database',
  // },
  {
    route: ROUTE.PURCHASED_ORDER.LIST.PATH,
    title: ROUTE.PURCHASED_ORDER.LIST.TITLE,
  },
]

function PurchasedOrder() {
  const { t } = useTranslation('mesx')
  const history = useHistory()

  const [tempItem, setTempItem] = useState(null)
  const [isOpenDeleteModal, setIsOpenDeleteModal] = useState(false)
  const [isOpenConfirmModal, setIsOpenConfirmModal] = useState(false)
  const [isOpenRejectModal, setIsOpenRejectModal] = useState(false)
  const [isOpenCancelModal, setIsOpenCancelModal] = useState(false)
  const [isOpenAssignModal, setIsOpenAssignModal] = useState(false)
  const [isOpenChangeStatusModal, setIsOpenChangeStatusModal] = useState(false)
  const [selectedRows, setSelectedRows] = useState([])

  const DEFAULT_QUICK_FILTERS = {}

  const {
    page,
    pageSize,
    sort,
    quickFilters,
    keyword,
    setPage,
    setPageSize,
    setSort,
    setQuickFilters,
    setKeyword,
    withSearch,
    selectedRowsDeps,
  } = useQueryState()

  const {
    data: { purchasedOrderList, total, isLoading },
    actions,
  } = usePurchasedOrder()

  const columns = [
    {
      field: 'code',
      headerName: t('purchasedOrder.code'),
      width: 100,
      sortable: true,
      visible: 'always',
    },
    {
      field: 'name',
      headerName: t('purchasedOrder.name'),
      width: 180,
      sortable: true,
      visible: 'always',
    },
    {
      field: 'vendor',
      headerName: t('purchasedOrder.vendor.code'),
      width: 150,
      sortable: true,
      renderCell: (params) => params.row?.vendor?.name,
    },
    {
      field: 'orderedAt',
      headerName: t('purchasedOrder.purchasedAt'),
      width: 150,
      sortable: true,
      filterFormat: 'date',
      renderCell: (params) => {
        const { orderedAt } = params.row
        return convertUtcDateToLocalTz(orderedAt)
      },
    },
    {
      field: 'deadline',
      headerName: t('purchasedOrder.deadline'),
      width: 150,
      sortable: true,
      filterFormat: 'date',
      renderCell: (params) => {
        const { deadline } = params.row
        return convertUtcDateToLocalTz(deadline)
      },
    },
    {
      field: 'purchasedByUser',
      headerName: t('purchasedOrder.purchasedByUser'),
      width: 150,
      sortable: true,
      renderCell: (params) => params.row?.purchaseStaff?.fullName,
    },
    {
      field: 'totalAmount',
      headerName: t('purchasedOrder.totalPrice'),
      width: 150,
      sortable: true,
      align: 'right',
      headerAlign: 'left',
      renderCell: (params) => {
        return <NumberFormatText value={params.row?.totalAmount} />
      },
    },
    {
      field: 'status',
      headerName: t('purchasedOrder.orderStatus'),
      width: 100,
      sortable: true,
      renderCell: (params) => {
        const { status } = params.row
        return (
          <Status
            options={PURCHASED_ORDER_STATUS_OPTIONS}
            value={status}
            variant="text"
          />
        )
      },
    },
    {
      field: 'deliveryStatus',
      headerName: t('purchasedOrder.deliveryStatus'),
      width: 100,
      sortable: true,
      renderCell: (params) => {
        const { status } = params.row
        return (
          <Status
            options={DELIVERY_STATUS_OPTIONS}
            value={status}
            variant="text"
          />
        )
      },
    },
    {
      field: 'payStatus',
      headerName: t('purchasedOrder.payStatus'),
      width: 100,
      sortable: true,
      renderCell: (params) => {
        const { status } = params.row
        return (
          <Status options={PAY_STATUS_OPTIONS} value={status} variant="text" />
        )
      },
    },
    {
      field: 'action',
      headerName: t('general:common.action'),
      width: 200,
      align: 'center',
      visible: 'always',
      sticky: 'right',
      renderCell: (params) => {
        const { id, status } = params.row
        const {
          DRAFT,
          PENDING,
          CONFIRMED,
          REJECTED,
          TO_DELIVERY,
          DELIVERING,
          COMPLETED,
        } = PURCHASED_ORDER_STATUS
        const isDraft = status === DRAFT
        const isPending = status === PENDING
        const isConfirmed = status === CONFIRMED
        const canEdit = status !== COMPLETED
        const canDelete = [DRAFT, PENDING, REJECTED].includes(status)
        const canCancel = [
          REJECTED,
          CONFIRMED,
          TO_DELIVERY,
          DELIVERING,
        ].includes(status)
        return (
          <Box>
            <IconButton
              onClick={() =>
                history.push(
                  withSearch(
                    ROUTE.PURCHASED_ORDER.DETAIL.PATH.replace(':id', `${id}`),
                  ),
                )
              }
            >
              <Icon name="show" />
            </IconButton>
            {isDraft && (
              <IconButton
                onClick={() => {
                  setTempItem(params.row)
                  setIsOpenAssignModal(true)
                }}
              >
                <Icon name="assign" />
              </IconButton>
            )}
            {isConfirmed && (
              <IconButton
                onClick={() => {
                  setTempItem(params.row)
                  setIsOpenChangeStatusModal(true)
                }}
              >
                <Icon name="order" />
              </IconButton>
            )}
            {canEdit && (
              <IconButton
                onClick={() =>
                  history.push(
                    withSearch(
                      ROUTE.PURCHASED_ORDER.EDIT.PATH.replace(':id', `${id}`),
                    ),
                  )
                }
              >
                <Icon name="edit" />
              </IconButton>
            )}
            {canCancel && (
              <IconButton
                onClick={() => {
                  setTempItem(params.row)
                  setIsOpenCancelModal(true)
                }}
              >
                <Icon name="cancel" size="small" />
              </IconButton>
            )}
            {canDelete && (
              <IconButton
                onClick={() => {
                  setTempItem(params.row)
                  setIsOpenDeleteModal(true)
                }}
              >
                <Icon name="delete" />
              </IconButton>
            )}
            {isPending && (
              <>
                <IconButton
                  onClick={() => {
                    setTempItem(params.row)
                    setIsOpenConfirmModal(true)
                  }}
                >
                  <Icon name="tick" />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setTempItem(params.row)
                    setIsOpenRejectModal(true)
                  }}
                >
                  <Icon name="remove" />
                </IconButton>
              </>
            )}
            <IconButton
              onClick={() =>
                history.push(
                  withSearch(
                    `${ROUTE.PURCHASED_ORDER.CREATE.PATH}?cloneId=${id}`,
                  ),
                )
              }
            >
              <Icon name="clone" />
            </IconButton>
          </Box>
        )
      },
    },
  ]

  const refreshData = () => {
    const params = {
      keyword: keyword.trim(),
      page,
      limit: pageSize,
      filter: convertFilterParams(
        { ...quickFilters, vendorName: quickFilters?.vendorName?.name },
        columns,
      ),
      sort: convertSortParams(sort),
    }

    actions.searchPurchasedOrders(params)
  }

  useEffect(() => {
    refreshData()
  }, [page, pageSize, quickFilters, sort, keyword])

  useEffect(() => {
    setSelectedRows([])
  }, [selectedRowsDeps])

  const onSubmitDelete = () => {
    actions.deletePurchasedOrder(tempItem?.id, () => {
      refreshData()
    })
    setIsOpenDeleteModal(false)
    setTempItem(null)
  }

  const onSubmitConfirm = () => {
    actions.confirmPurchasedOrderById(tempItem?.id, () => {
      refreshData()
    })
    setIsOpenConfirmModal(false)
    setTempItem(null)
  }

  const onSubmitReject = (values) => {
    const params = {
      id: tempItem?.id,
      note: values?.note,
    }
    actions.rejectPurchasedOrderById(params, refreshData)
    setIsOpenRejectModal(false)
    setTempItem(null)
  }

  const onSubmitAssign = () => {
    const params = {
      id: tempItem?.id,
      type: PURCHASED_ORDER_ACTION_TYPE.REQUEST_CONFIRM,
    }
    actions.changeStatusPurchasedOrder(params, () => {
      refreshData()
    })
    setIsOpenAssignModal(false)
    setTempItem(null)
  }

  const onSubmitChangeStatus = () => {
    const params = {
      id: tempItem?.id,
      type: PURCHASED_ORDER_ACTION_TYPE.ORDER,
    }
    actions.changeStatusPurchasedOrder(params, () => {
      refreshData()
    })
    setIsOpenChangeStatusModal(false)
    setTempItem(null)
  }

  const onSubmitCancel = (values) => {
    const params = {
      id: tempItem?.id,
      type: PURCHASED_ORDER_ACTION_TYPE.CANCEL,
      note: values?.note,
    }
    actions.changeStatusPurchasedOrder(params, () => {
      refreshData()
    })
    setIsOpenCancelModal(false)
    setTempItem(null)
  }

  const renderHeaderRight = () => {
    return (
      <>
        <Button variant="outlined" icon="download" disabled>
          {t('menu.importExportData')}
        </Button>
        <Button
          onClick={() =>
            history.push(withSearch(ROUTE.PURCHASED_ORDER.CREATE.PATH))
          }
          sx={{ ml: 4 / 3 }}
          icon="add"
        >
          {t('general:common.create')}
        </Button>
      </>
    )
  }

  return (
    <Page
      breadcrumbs={breadcrumbs}
      title={t('menu.purchasedOrder')}
      onSearch={setKeyword}
      keyword={keyword}
      placeholder={t('purchasedOrder.searchPlaceholder')}
      renderHeaderRight={renderHeaderRight}
      loading={isLoading}
    >
      <QuickFilter
        setQuickFilters={setQuickFilters}
        quickFilters={quickFilters}
        defaultFilter={DEFAULT_QUICK_FILTERS}
      />
      <DataTable
        title={t('purchasedOrder.title')}
        rows={purchasedOrderList}
        pageSize={pageSize}
        page={page}
        columns={columns}
        onPageChange={setPage}
        onPageSizeChange={setPageSize}
        onSortChange={setSort}
        total={total}
        sort={sort}
        onSelectionChange={setSelectedRows}
        selected={selectedRows}
        bulkActions={{
          actions: [
            BULK_ACTION.APPROVE,
            BULK_ACTION.REJECT,
            BULK_ACTION.DELETE,
          ],
          apiUrl: API_URL.PURCHASED_ORDER,
          onSuccess: () => {
            if (page === 1) {
              refreshData()
            } else {
              setPage(1)
            }
            setSelectedRows([])
          },
        }}
      />
      <Dialog
        open={isOpenDeleteModal}
        title={t('purchasedOrder.deleteModalTitle')}
        onCancel={() => setIsOpenDeleteModal(false)}
        onSubmit={onSubmitDelete}
        cancelLabel={t('general:common.no')}
        submitLabel={t('general:common.yes')}
        submitProps={{
          color: 'error',
        }}
        noBorderBottom
      >
        {t('purchasedOrder.deleteConfirm')}
        <LV
          label={t('purchasedOrder.code')}
          value={tempItem?.code}
          sx={{ mt: 4 / 3 }}
        />
        <LV
          label={t('purchasedOrder.name')}
          value={tempItem?.name}
          sx={{ mt: 4 / 3 }}
        />
      </Dialog>
      <Dialog
        open={isOpenAssignModal}
        title={t('purchasedOrder.requestConfirm')}
        onCancel={() => setIsOpenAssignModal(false)}
        onSubmit={onSubmitAssign}
        cancelLabel={t('general:common.no')}
        submitLabel={t('general:common.yes')}
        noBorderBottom
      >
        {t('purchasedOrder.requestConfirmMsg')}
        <LV
          label={t('purchasedOrder.code')}
          value={tempItem?.code}
          sx={{ mt: 4 / 3 }}
        />
        <LV
          label={t('purchasedOrder.name')}
          value={tempItem?.name}
          sx={{ mt: 4 / 3 }}
        />
      </Dialog>
      <Dialog
        open={isOpenChangeStatusModal}
        title={t('purchasedOrder.confirmOrder')}
        maxWidth="sm"
        onCancel={() => setIsOpenChangeStatusModal(false)}
        onSubmit={onSubmitChangeStatus}
        cancelLabel={t('general:common.no')}
        submitLabel={t('general:common.yes')}
        noBorderBottom
      >
        {t('purchasedOrder.confirmOrderMsg')}
        <LV
          label={t('purchasedOrder.code')}
          value={tempItem?.code}
          sx={{ mt: 4 / 3 }}
        />
        <LV
          label={t('purchasedOrder.name')}
          value={tempItem?.name}
          sx={{ mt: 4 / 3 }}
        />
      </Dialog>
      <Dialog
        open={isOpenConfirmModal}
        title={t('general:common.notify')}
        maxWidth="sm"
        onCancel={() => setIsOpenConfirmModal(false)}
        onSubmit={onSubmitConfirm}
        cancelLabel={t('general:common.no')}
        submitLabel={t('general:common.yes')}
        noBorderBottom
      >
        {t('general:common.confirmMessage.confirm')}
        <LV
          label={t('purchasedOrder.code')}
          value={tempItem?.code}
          sx={{ mt: 4 / 3 }}
        />
        <LV
          label={t('purchasedOrder.name')}
          value={tempItem?.name}
          sx={{ mt: 4 / 3 }}
        />
      </Dialog>
      <Dialog
        open={isOpenRejectModal}
        title={t('general:common.notify')}
        maxWidth="sm"
        onCancel={() => setIsOpenRejectModal(false)}
        cancelLabel={t('general:common.no')}
        submitLabel={t('general:common.yes')}
        submitProps={{
          color: 'error',
        }}
        formikProps={{
          validationSchema: Yup.object().shape({
            note: Yup.string().required(t('general:form.required')),
          }),
          initialValues: { note: '' },
          onSubmit: onSubmitReject,
          enableReinitialize: true,
        }}
        noBorderBottom
      >
        {t('general:common.confirmMessage.reject')}
        <LV
          label={t('purchasedOrder.code')}
          value={tempItem?.code}
          sx={{ mt: 4 / 3 }}
        />
        <LV
          label={t('purchasedOrder.name')}
          value={tempItem?.name}
          sx={{ mt: 4 / 3 }}
        />
        <Field.TextField
          name="note"
          label={t('purchasedOrder.note')}
          placeholder={t('purchasedOrder.note')}
          multiline
          rows={3}
          required
          sx={{ mt: 4 / 3, color: 'subText' }}
        />
      </Dialog>
      <Dialog
        open={isOpenCancelModal}
        title={t('general:common.notify')}
        maxWidth="sm"
        onCancel={() => setIsOpenCancelModal(false)}
        cancelLabel={t('general:common.no')}
        submitLabel={t('general:common.yes')}
        submitProps={{
          color: 'error',
        }}
        formikProps={{
          validationSchema: Yup.object().shape({
            note: Yup.string().required(t('general:form.required')),
          }),
          initialValues: { note: '' },
          onSubmit: onSubmitCancel,
          enableReinitialize: true,
        }}
        noBorderBottom
      >
        {t('purchasedOrder.cancelMsg')}
        <LV
          label={t('purchasedOrder.code')}
          value={tempItem?.code}
          sx={{ mt: 4 / 3 }}
        />
        <LV
          label={t('purchasedOrder.name')}
          value={tempItem?.name}
          sx={{ mt: 4 / 3 }}
        />
        <Field.TextField
          name="note"
          label={t('purchasedOrder.note')}
          placeholder={t('purchasedOrder.note')}
          multiline
          rows={3}
          required
          sx={{ mt: 4 / 3, color: 'subText' }}
        />
      </Dialog>
    </Page>
  )
}

export default PurchasedOrder
