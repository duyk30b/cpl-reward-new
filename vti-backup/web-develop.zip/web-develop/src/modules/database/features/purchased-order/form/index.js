import React, { useState, useEffect, useMemo } from 'react'

import { Grid } from '@mui/material'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import { Formik, Form, FieldArray } from 'formik'
import { first } from 'lodash'
import { useTranslation } from 'react-i18next'
import {
  useHistory,
  useRouteMatch,
  useParams,
  useLocation,
} from 'react-router-dom'

import {
  MODAL_MODE,
  TEXTFIELD_REQUIRED_LENGTH,
  ASYNC_SEARCH_LIMIT,
  TEXTFIELD_ALLOW,
} from '~/common/constants'
import { useQueryState } from '~/common/hooks'
import ActionBar from '~/components/ActionBar'
import Button from '~/components/Button'
import FileUploadButton from '~/components/FileUploadButton'
import { Field } from '~/components/Formik'
import LV from '~/components/LabelValue'
import Page from '~/components/Page'
import Status from '~/components/Status'
import Tabs from '~/components/Tabs'
import useUserInfo from '~/modules/configuration/redux/hooks/useUserInfo'
import { searchUsersApi } from '~/modules/configuration/redux/sagas/user-management/search-users'
import {
  PURCHASED_ORDER_STATUS,
  PURCHASED_ORDER_STATUS_OPTIONS,
  PURCHASED_ORDER_TYPE_OPTIONS,
} from '~/modules/database/constants'
import usePurchasedOrder from '~/modules/database/redux/hooks/usePurchasedOrder'
import { searchCurrencyRateApi } from '~/modules/database/redux/sagas/currency-rate/search-currency-rate-list'
import { searchCurrencyUnitApi } from '~/modules/database/redux/sagas/currency-unit/search-currency-unit'
import { getVendorDetailsApi } from '~/modules/database/redux/sagas/define-vendor/get-vendor-details'
import { searchVendorsApi } from '~/modules/database/redux/sagas/define-vendor/search-vendors'
import { ROUTE } from '~/modules/database/routes/config'
import { TEMPLATE_CODE, TEMPLATE_TYPE_ENUM } from '~/modules/mesx/constants'
import useBusinessTypeManagement from '~/modules/wmsx/redux/hooks/useBusinessTypeManagement'
import { searchBusinessTypesApi } from '~/modules/wmsx/redux/sagas/business-type-management/search-business-types'
import { convertFilterParams } from '~/utils'
import qs from '~/utils/qs'

import DeliveryTable from './delivery-table'
import InvoiceInfoTable from './invoice-info'
import ItemsSettingTable from './items-setting-table'
import PayPlanTable from './pay-plan-table'
import { validationSchema } from './schema'

function PurchasedOrderForm() {
  const { t } = useTranslation(['mesx'])
  const history = useHistory()
  const routeMatch = useRouteMatch()
  const { withSearch } = useQueryState()

  const { id } = useParams()
  const location = useLocation()
  const { cloneId } = qs.parse(location.search)
  const [itemList, setItemList] = useState()
  const [isDraft, setIsDraft] = useState(false)
  const { CONFIRMED, TO_DELIVERY, DELIVERING } = PURCHASED_ORDER_STATUS

  const {
    data: { purchasedOrderDetails, isLoading: poLoading, genCode },
    actions,
  } = usePurchasedOrder()

  const {
    data: { businessTypeDetails, isLoading: templateLoading },
    actions: businessActs,
  } = useBusinessTypeManagement()

  const {
    data: { userInfo },
  } = useUserInfo()

  const DEFAULT_ITEM = {
    id: new Date().getTime(),
    itemId: null,
    quantity: 0,
    price: 0,
    discount: 0,
    totalPrice: 0,
    deliveryPlan: null,
  }

  const DEFAULT_PAY_PLAN = {
    id: new Date().getTime(),
    planDate: null,
    payMethod: null,
    payPercent: 0,
    payMoney: 0,
    payAccount: '',
    payDescription: '',
  }

  const DEFAULT_INVOICE = useMemo(
    () => ({
      id: new Date().getTime(),
      createdAt: null,
      updatedByUser: userInfo,
      invoiceCode: '',
      invoiceValue: 0,
      invoiceDescription: '',
    }),
    [userInfo],
  )

  const MODE_MAP = {
    [ROUTE.PURCHASED_ORDER.CREATE.PATH]: MODAL_MODE.CREATE,
    [ROUTE.PURCHASED_ORDER.EDIT.PATH]: MODAL_MODE.UPDATE,
  }

  const mode = MODE_MAP[routeMatch.path]
  const isUpdate = mode === MODAL_MODE.UPDATE
  const isCreate = mode === MODAL_MODE.CREATE

  const isDisable =
    isUpdate &&
    [TO_DELIVERY, DELIVERING].includes(purchasedOrderDetails?.status)

  useEffect(() => {
    if (isCreate) {
      actions.genCodePurchasedOrder()
    }
  }, [isCreate])

  useEffect(() => {
    const getBusinessType = async () => {
      const params = {
        filter: convertFilterParams({
          type: TEMPLATE_TYPE_ENUM.PURCHASED_ORDER,
        }),
      }
      const business = await searchBusinessTypesApi(params)
      if (business?.statusCode === 200) {
        const businessTypeId = first(business?.data?.items).id
        businessActs.getBusinessTypeDetailsById(businessTypeId)
      }
    }
    getBusinessType()
    return () => {
      businessActs.resetBusinessTypeDetailsState()
    }
  }, [])

  useEffect(() => {
    if (id) {
      actions.getPurchasedOrderDetailsById(id)
    }
    if (cloneId) {
      actions.getPurchasedOrderDetailsById(cloneId)
    }
    return () => {
      actions.resetPurchasedOrderDetailsState()
    }
  }, [id])

  const backToList = () => {
    history.push(withSearch(ROUTE.PURCHASED_ORDER.LIST.PATH))
  }

  const initialValues = useMemo(
    () => ({
      code: isUpdate ? purchasedOrderDetails?.code : genCode,
      name: purchasedOrderDetails?.name || '',
      note: purchasedOrderDetails?.note || '',
      manufacturingOrderId:
        purchasedOrderDetails?.manufacturingOrder?.code || null,
      requestBuyMaterialCode:
        purchasedOrderDetails.manufacturingOrder?.requestBuyMaterial.id || '',
      orderedAt: purchasedOrderDetails?.orderedAt || '',
      purchasedByUser: purchasedOrderDetails?.purchaseStaff || userInfo,
      type: isUpdate || cloneId ? purchasedOrderDetails?.orderType : null,
      vendor: purchasedOrderDetails?.vendor || null,
      currencyUnit: purchasedOrderDetails?.currencyUnit || null,
      exchangeRate:
        purchasedOrderDetails?.currencyUnit?.exchangeRate?.rate || null,
      deadline: purchasedOrderDetails?.deadline || null,
      receiveDate: purchasedOrderDetails?.deliverAt || null,
      items: purchasedOrderDetails?.purchasedOrderItemDetails?.map(
        (e, index) => ({
          ...e,
          itemId: e?.item,
          quantity: Number(e?.quantity),
          price: Number(e?.purchasePrice),
          totalPrice:
            (e?.purchasePrice * e?.quantity * (100 - e?.discount)) / 100,
          deliveryPlan:
            purchasedOrderDetails?.purchasedOrderDeliveryDetails?.[index]
              ?.planDeliveryAt,
          description:
            purchasedOrderDetails?.purchasedOrderDeliveryDetails?.[index]
              ?.description,
        }),
      ) || [{ ...DEFAULT_ITEM }],
      oneTimeDelivery: purchasedOrderDetails?.oneTimeDelivery || false,
      deliveryMethod: purchasedOrderDetails?.shippingMethod || null,
      address: purchasedOrderDetails?.address || '',
      receiveByUser: purchasedOrderDetails?.receiver || '',
      phoneReceiver: purchasedOrderDetails?.receiverPhoneNumber || '',
      payPlan: purchasedOrderDetails?.purchasedOrderPaymentDetails?.map(
        (p) => ({
          planDate: p?.planPayAt,
          payMethod: p?.paymentMethod,
          payPercent: p?.paymentRate,
          payMoney: p?.totalPaymentAmount,
          payAccount: p?.userAccount,
          payDescription: p?.description,
        }),
      ) || [{ ...DEFAULT_PAY_PLAN }],
      invoiceInfo: purchasedOrderDetails?.purchasedOrderInvoiceDetails?.map(
        (i) => ({
          ...i,
          updatedByUser: userInfo,
          invoiceDescription: i?.description,
        }),
      ) || [{ ...DEFAULT_INVOICE }],
      files: [],
    }),
    [purchasedOrderDetails, genCode],
  )

  useEffect(async () => {
    const vendorId = purchasedOrderDetails?.vendor?.id
    if (vendorId) {
      const response = await getVendorDetailsApi(vendorId)
      const itemsByVendor = response.data?.vendorAbilities?.map((i) => ({
        ...i?.item,
        id: i?.itemId,
      }))
      setItemList(itemsByVendor)
    }
  }, [purchasedOrderDetails])

  const convertValues = (values) => {
    const { attributeHeaders, attributeGroups } = businessTypeDetails

    const formatValues = {
      mesxOrderAt: values?.orderedAt,
      mesxOrderCode: values?.code,
      mesxOrderName: values?.name,
      mesxCurrencyUnitId: values?.currencyUnit?.id,
      mesxExchangeRate: values?.exchangeRate,
      mesxOrderType: values.type,
      mesxPurchaseStaffId: values?.purchasedByUser?.id,
      mesxFiles: values?.files,
      mesxNote: values?.note,
      mesxVendorId: values?.vendor?.id,
      mesxPhoneNumber: values?.vendor?.phone,
      mesxTaxNumber: values?.vendor?.tax,
      mesxOneTimeDelivery: values?.oneTimeDelivery,
      mesxDeliverAt: values?.receiveDate,
      mesxReceiver: values?.receiveByUser,
      mesxReceiverPhoneNumber: values?.phoneReceiver,
      mesxShippingMethodId: values?.deliveryMethod?.id,
      mesxAddress: values?.address,
    }

    const formatTableValues = values?.items?.map((item) => [
      {
        mesxItemId: item?.itemId?.id,
        mesxItemName: item?.itemId?.name,
        mesxItemUnitId: item?.itemId?.itemUnit?.id,
        mesxPurchasePrice: item?.price,
        mesxPOQuantity: item?.quantity,
        mesxDiscount: item?.discount,
        mesxTotalAmount: item?.totalPrice,
      },
      {
        mesxItemId: item?.itemId?.id,
        mesxItemName: item?.itemId?.name,
        mesxPlanDeliveryAt: values?.oneTimeDelivery
          ? values?.receiveDate
          : item?.deliveryPlan,
        mesxDescription: item?.description,
      },
    ])

    const formatPayPlanValues = values?.payPlan?.map((p) => ({
      mesxPayAt: p?.planDate,
      mesxPaymentMethodId: p?.payMethod?.id,
      mesxPaymentRate: p?.payPercent,
      mesxTotalPaymentAmount: p?.payMoney,
      mesxUserAccount: p?.payAccount,
      mesxDescription: p?.payDescription,
    }))

    const formatInvoiceInfoValues = values?.invoiceInfo?.map((i) => ({
      mesxCreatedAt: i?.createdAt,
      mesxUpdateByUserId: i?.updatedByUser?.id,
      mesxInvoiceCode: i?.invoiceCode,
      mesxInvoiceValue: i?.invoiceValue,
      mesxDescription: i?.invoiceDescription,
    }))

    const getObjectValueTable = (groupIndex, values, noIndex) => {
      return values?.map((value) => {
        const attributes = attributeGroups?.[groupIndex]?.attributes?.map(
          (attr) => ({
            id: attr?.attribute?.id,
            code: attr?.attribute?.code,
            value: noIndex
              ? value?.[attr?.attribute?.code]
              : value?.[groupIndex]?.[attr?.attribute?.code] || null,
          }),
        )
        return {
          groupId: attributeGroups?.[groupIndex]?.id,
          attributeValues: attributes,
        }
      })
    }

    const items = getObjectValueTable(0, formatTableValues)
    const delivery = getObjectValueTable(1, formatTableValues)
    const payPlan = getObjectValueTable(2, formatPayPlanValues, true)
    const invoiceInfo = getObjectValueTable(3, formatInvoiceInfoValues, true)

    const getObjectValueHeader = (attributes, values) => {
      return attributes?.map((attr) => ({
        id: attr?.attribute?.id,
        code: attr?.attribute?.code,
        value: values[attr?.attribute?.code],
      }))
    }
    const headerValues = getObjectValueHeader(attributeHeaders, formatValues)

    return {
      isDraft: isDraft,
      code: TEMPLATE_CODE.PURCHASED_ORDER,
      templateId: businessTypeDetails?.id,
      attributeValues: headerValues,
      purchasedOrderDetails: [
        ...items,
        ...delivery,
        ...payPlan,
        ...invoiceInfo,
      ],
    }
  }

  const handleSubmit = (values) => {
    const finalValues = convertValues(values)
    if (mode === MODAL_MODE.CREATE) {
      actions.createPurchasedOrder(finalValues, () =>
        history.push(ROUTE.PURCHASED_ORDER.LIST.PATH),
      )
    } else if (mode === MODAL_MODE.UPDATE) {
      actions.updatePurchasedOrder({ ...finalValues, id }, backToList)
    }
  }

  const renderActionBar = (handleReset) => {
    switch (mode) {
      case MODAL_MODE.CREATE:
        return (
          <ActionBar
            onBack={backToList}
            onCancel={handleReset}
            elAfter={
              <>
                <Button
                  type="submit"
                  icon="save"
                  onClick={() => setIsDraft(true)}
                >
                  {t('general:actionBar.draft')}
                </Button>
                <Button
                  type="submit"
                  icon="save"
                  onClick={() => setIsDraft(false)}
                >
                  {t('general:actionBar.approve')}
                </Button>
              </>
            }
          />
        )
      case MODAL_MODE.UPDATE:
        return (
          <ActionBar
            onBack={backToList}
            onCancel={handleReset}
            mode={MODAL_MODE.UPDATE}
          />
        )
      default:
    }
  }

  const getBreadcrumb = () => {
    const breadcrumb = [
      {
        route: withSearch(ROUTE.PURCHASED_ORDER.LIST.PATH),
        title: ROUTE.PURCHASED_ORDER.LIST.TITLE,
      },
    ]

    switch (mode) {
      case MODAL_MODE.CREATE:
        breadcrumb.push({
          route: ROUTE.PURCHASED_ORDER.CREATE.PATH,
          title: ROUTE.PURCHASED_ORDER.CREATE.TITLE,
        })
        break
      case MODAL_MODE.UPDATE:
        breadcrumb.push({
          route: ROUTE.PURCHASED_ORDER.EDIT.PATH,
          title: ROUTE.PURCHASED_ORDER.EDIT.TITLE,
        })
        break
      default:
        break
    }
    return breadcrumb
  }

  const getTitle = () => {
    switch (mode) {
      case MODAL_MODE.CREATE:
        return ROUTE.PURCHASED_ORDER.CREATE.TITLE
      case MODAL_MODE.UPDATE:
        return ROUTE.PURCHASED_ORDER.EDIT.TITLE
      default:
    }
  }

  const handleChangeVendorId = async (val, setFieldValue) => {
    setFieldValue('items', [{ ...DEFAULT_ITEM }])
    const response = await getVendorDetailsApi(val?.id)
    const itemsByVendor = response.data?.vendorAbilities?.map((i) => ({
      ...i?.item,
      id: i?.itemId,
    }))
    setItemList(itemsByVendor)
  }

  const handleChangeCurrencyUnit = async (val, setFieldValue) => {
    const response = await searchCurrencyRateApi()
    const list = response?.data?.items
    const isMainCurrency = list?.some((i) => i?.fromUnit?.id === val?.id)

    if (isMainCurrency) {
      setFieldValue('exchangeRate', 1)
    } else {
      setFieldValue(
        'exchangeRate',
        list?.find((i) => i?.toUnit?.id === val?.id)?.rate,
      )
    }
  }

  const getTabList = (errors, touched) => {
    let tabList = [
      {
        label: t('purchasedOrder.itemsDetails'),
        error: !!errors.items && !!touched.items,
        required: true,
      },
      {
        label: t('purchasedOrder.delivery'),
        error: !!errors.items && !!touched.items,
        required: true,
      },
      {
        label: t('purchasedOrder.payPlan'),
      },
    ]
    if (
      isUpdate &&
      [CONFIRMED, TO_DELIVERY, DELIVERING].includes(
        purchasedOrderDetails?.status,
      )
    ) {
      return (tabList = [
        ...tabList,
        {
          label: t('purchasedOrder.invoiceInfo'),
        },
      ])
    }
    return tabList
  }
  return (
    <Page
      breadcrumbs={getBreadcrumb()}
      title={t(`menu.${getTitle()}`)}
      loading={poLoading || templateLoading}
      onBack={backToList}
    >
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema(t)}
        onSubmit={handleSubmit}
        enableReinitialize
      >
        {({ handleReset, values, setFieldValue, errors, touched }) => (
          <Form>
            {isUpdate && (
              <Grid item xs={12} ml={1} mb={0.5}>
                <LV
                  label={
                    <Typography>{t('purchasedOrder.orderStatus')}</Typography>
                  }
                  value={
                    <Status
                      options={PURCHASED_ORDER_STATUS_OPTIONS}
                      value={purchasedOrderDetails?.status}
                    />
                  }
                  labelWidth={100}
                />
              </Grid>
            )}
            <Grid container>
              <Grid
                item
                xl={8}
                xs={12}
                sx={(theme) => ({
                  justifyContent: 'center',
                  bgcolor: 'grayF4.main',
                  borderRadius: 1,
                  mb: 1,
                  pt: 1,
                  pb: 1,
                  pr: 1,
                  pl: 1,

                  [theme.breakpoints.down('xl')]: {
                    px: 2,
                  },
                })}
              >
                <Grid
                  container
                  columnSpacing={{ xl: 3, xs: 2 }}
                  rowSpacing={4 / 3}
                >
                  <Grid item xs={12} lg={6}>
                    <Field.DatePicker
                      name="orderedAt"
                      label={t('purchasedOrder.purchasedAt')}
                      placeholder={t('purchasedOrder.purchasedAt')}
                      labelWidth={100}
                      required
                      disabled={isDisable}
                    />
                  </Grid>
                  <Grid item xs={12} lg={6}>
                    <Field.TextField
                      name="code"
                      label={t('purchasedOrder.code')}
                      placeholder={t('purchasedOrder.code')}
                      disabled
                      labelWidth={100}
                      required
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Field.TextField
                      name="name"
                      label={t('purchasedOrder.name')}
                      placeholder={t('purchasedOrder.name')}
                      inputProps={{
                        maxLength: TEXTFIELD_REQUIRED_LENGTH.CODE_50.MAX,
                      }}
                      allow={TEXTFIELD_ALLOW.EXCEPT_SPECIALS}
                      labelWidth={100}
                      required
                      disabled={isDisable}
                    />
                  </Grid>
                  <Grid item xs={12} lg={6}>
                    <Field.Autocomplete
                      name="currencyUnit"
                      label={t('purchasedOrder.currencyUnit')}
                      placeholder={t('purchasedOrder.currencyUnit')}
                      asyncRequest={(s) =>
                        searchCurrencyUnitApi({
                          keyword: s,
                          limit: ASYNC_SEARCH_LIMIT,
                        })
                      }
                      asyncRequestHelper={(res) => res?.data?.items}
                      getOptionLabel={(opt) => opt?.code}
                      getOptionSubLabel={(opt) => opt?.name}
                      isOptionEqualToValue={(opt, val) => opt?.id === val?.id}
                      onChange={(val) =>
                        handleChangeCurrencyUnit(val, setFieldValue)
                      }
                      labelWidth={100}
                      required
                      disabled={isDisable}
                    />
                  </Grid>
                  <Grid item xs={12} lg={6}>
                    <Field.TextField
                      name="exchangeRate"
                      label={t('purchasedOrder.exchangeRate')}
                      placeholder={t('purchasedOrder.exchangeRate')}
                      labelWidth={100}
                      disabled
                    />
                  </Grid>
                  <Grid item xs={12} lg={6}>
                    <Field.Autocomplete
                      name="type"
                      label={t('purchasedOrder.type')}
                      placeholder={t('purchasedOrder.type')}
                      options={PURCHASED_ORDER_TYPE_OPTIONS}
                      getOptionLabel={(opt) => t(opt?.text)}
                      getOptionValue={(opt) => opt?.id}
                      labelWidth={100}
                      disabled={isDisable}
                    />
                  </Grid>
                  <Grid item xs={12} lg={6}>
                    <Field.Autocomplete
                      name="purchasedByUser"
                      label={t('purchasedOrder.purchasedByUser')}
                      placeholder={t('purchasedOrder.purchasedByUser')}
                      asyncRequest={(s) =>
                        searchUsersApi({
                          keyword: s,
                          limit: ASYNC_SEARCH_LIMIT,
                        })
                      }
                      asyncRequestHelper={(res) => res?.data?.items}
                      getOptionLabel={(opt) => opt?.fullName}
                      getOptionSubLabel={(opt) => opt?.username}
                      isOptionEqualToValue={(opt, val) => opt?.id === val?.id}
                      labelWidth={100}
                      required
                      disabled={isDisable}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <LV
                      label={
                        <Typography mt={1}>
                          {t('purchasedOrder.file')}
                        </Typography>
                      }
                      value={
                        <FileUploadButton
                          maxNumberOfFiles={10}
                          onChange={(val) => setFieldValue('files', val)}
                          value={values.files}
                          disabled={isDisable}
                        />
                      }
                      labelWidth={100}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Field.TextField
                      name="note"
                      label={t('purchasedOrder.note')}
                      placeholder={t('purchasedOrder.note')}
                      inputProps={{
                        maxLength: TEXTFIELD_REQUIRED_LENGTH.COMMON.MAX,
                      }}
                      labelWidth={100}
                      disabled={isDisable}
                    />
                  </Grid>
                </Grid>
              </Grid>
              <Grid xl={0.1} xs={12}></Grid>
              <Grid
                item
                xl={3.9}
                xs={12}
                sx={(theme) => ({
                  justifyContent: 'center',
                  bgcolor: 'grayF4.main',
                  borderRadius: 1,
                  mb: 1,
                  pt: 1,
                  pb: 1,
                  pr: 1,
                  pl: 1,

                  [theme.breakpoints.down('xl')]: {
                    px: 2,
                  },
                })}
              >
                <Grid
                  container
                  columnSpacing={{ xl: 3, xs: 2 }}
                  rowSpacing={4 / 3}
                >
                  <Grid item xs={12}>
                    <Field.Autocomplete
                      name="vendor"
                      label={t('purchasedOrder.vendor.code')}
                      placeholder={t('purchasedOrder.vendor.code')}
                      asyncRequest={(s) =>
                        searchVendorsApi({
                          keyword: s,
                          limit: ASYNC_SEARCH_LIMIT,
                        })
                      }
                      asyncRequestHelper={(res) => res?.data?.items}
                      getOptionLabel={(opt) => opt?.code}
                      getOptionSubLabel={(opt) => opt?.name}
                      isOptionEqualToValue={(opt, val) => opt?.id === val?.id}
                      labelWidth={100}
                      onChange={(val) =>
                        handleChangeVendorId(val, setFieldValue)
                      }
                      required
                      disabled={isDisable}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Field.TextField
                      name="vendor.phone"
                      label={t('purchasedOrder.vendor.phone')}
                      placeholder={t('purchasedOrder.vendor.phone')}
                      labelWidth={100}
                      disabled
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Field.TextField
                      name="vendor.taxCode"
                      label={t('purchasedOrder.vendor.tax')}
                      placeholder={t('purchasedOrder.vendor.tax')}
                      labelWidth={100}
                      disabled
                    />
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
            <Tabs list={getTabList(errors, touched)} sx={{ mt: 1 }}>
              {/* Tab 1 */}
              <Box>
                <FieldArray
                  name="items"
                  render={(arrayHelpers) => (
                    <ItemsSettingTable
                      items={values?.items || []}
                      mode={mode}
                      arrayHelpers={arrayHelpers}
                      setFieldValue={setFieldValue}
                      purchasedOrderDetails={purchasedOrderDetails}
                      values={values}
                      defaultItems={DEFAULT_ITEM}
                      itemList={itemList}
                      isDisable={isDisable}
                    />
                  )}
                />
              </Box>

              {/* Tab 2 */}
              <Box>
                <FieldArray
                  name="delivery"
                  render={() => (
                    <DeliveryTable
                      items={values?.items || []}
                      mode={mode}
                      setFieldValue={setFieldValue}
                      purchasedOrderDetails={purchasedOrderDetails}
                      values={values}
                      isDisable={isDisable}
                    />
                  )}
                />
              </Box>

              {/* Tab 3 */}
              <Box>
                <FieldArray
                  name="payPlan"
                  render={(arrayHelpers) => (
                    <PayPlanTable
                      payPlan={values?.payPlan || []}
                      mode={mode}
                      setFieldValue={setFieldValue}
                      purchasedOrderDetails={purchasedOrderDetails}
                      values={values}
                      arrayHelpers={arrayHelpers}
                    />
                  )}
                />
              </Box>

              {/* Tab 4 */}
              <Box>
                <FieldArray
                  name="invoiceInfo"
                  render={(arrayHelpers) => (
                    <InvoiceInfoTable
                      invoiceInfo={values?.invoiceInfo || []}
                      mode={mode}
                      arrayHelpers={arrayHelpers}
                      defaultItems={DEFAULT_INVOICE}
                    />
                  )}
                />
              </Box>
            </Tabs>

            {renderActionBar(handleReset)}
          </Form>
        )}
      </Formik>
    </Page>
  )
}

export default PurchasedOrderForm
