import React from 'react'

import { IconButton } from '@mui/material'
import Box from '@mui/material/Box'
import { useTranslation } from 'react-i18next'

import { MODAL_MODE, TEXTFIELD_REQUIRED_LENGTH } from '~/common/constants'
import { useApp } from '~/common/hooks/useApp'
import Button from '~/components/Button'
import DataTable from '~/components/DataTable'
import { Field } from '~/components/Formik'
import Icon from '~/components/Icon'
import NumberFormatText from '~/components/NumberFormat'
import { convertUtcDateToLocalTz } from '~/utils'

function InvoiceInfoTable({ invoiceInfo, mode, arrayHelpers, defaultItems }) {
  const { t } = useTranslation(['mesx'])
  const { scrollToBottom } = useApp()
  const isView = mode === MODAL_MODE.DETAIL

  const getColumns = () => {
    return [
      {
        field: 'id',
        headerName: '#',
        width: 50,
        renderCell: (_, index) => {
          return index + 1
        },
      },
      {
        field: 'createdAt',
        headerName: t('purchasedOrder.createdAt'),
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <>{convertUtcDateToLocalTz(params.row?.createdAt)}</>
          ) : (
            <Field.DatePicker name={`invoiceInfo[${index}].createdAt`} />
          )
        },
      },
      {
        field: 'updatedByUser',
        headerName: t('purchasedOrder.updatedByUser'),
        width: 150,
        renderCell: (params, index) => {
          return isView ? (
            <>{params.row?.updatedBy?.fullName}</>
          ) : (
            <Field.TextField
              name={`invoiceInfo[${index}].updatedByUser.fullName`}
              disabled
            />
          )
        },
      },
      {
        field: 'invoiceCode',
        headerName: t('purchasedOrder.invoiceCode'),
        width: 150,
        renderCell: (params, index) => {
          return isView ? (
            <>{params.row?.invoiceCode}</>
          ) : (
            <Field.TextField
              name={`invoiceInfo[${index}].invoiceCode`}
              inputProps={{
                maxLength: TEXTFIELD_REQUIRED_LENGTH.CODE_15.MAX,
              }}
            />
          )
        },
      },
      {
        field: 'invoiceValue',
        headerName: t('purchasedOrder.invoiceValue'),
        align: 'right',
        headerAlign: 'left',
        width: 150,
        renderCell: (params, index) => {
          return isView ? (
            <NumberFormatText value={params.row?.invoiceValue} />
          ) : (
            <Field.TextField
              name={`invoiceInfo[${index}].invoiceValue`}
              numberProps={{
                decimalScale: 3,
                thousandSeparator: true,
              }}
            />
          )
        },
      },
      {
        field: 'description',
        headerName: t('purchasedOrder.description'),
        width: 150,
        renderCell: (params, index) => {
          return isView ? (
            <>{params.row?.description}</>
          ) : (
            <Field.TextField
              name={`invoiceInfo[${index}].invoiceDescription`}
              inputProps={{
                maxLength: TEXTFIELD_REQUIRED_LENGTH.CODE_50.MAX,
              }}
            />
          )
        },
      },
      {
        field: 'remove',
        headerName: '',
        width: 50,
        align: 'center',
        hide: isView,
        sticky: 'right',
        renderCell: (params, index) => {
          return (
            <IconButton
              onClick={() => arrayHelpers.remove(index)}
              disabled={invoiceInfo?.length === 1}
              size="large"
            >
              <Icon name="remove" />
            </IconButton>
          )
        },
      },
    ]
  }

  return (
    <>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'flex-end',
          alignItems: 'center',
          mb: 2,
        }}
      >
        {!isView && (
          <Button
            variant="outlined"
            onClick={() => {
              arrayHelpers.push(defaultItems)
              scrollToBottom()
            }}
          >
            {t('purchasedOrder.item.addItem')}
          </Button>
        )}
      </Box>
      <DataTable
        rows={invoiceInfo}
        columns={getColumns()}
        total={invoiceInfo?.length}
        hideSetting
        hideFooter
        striped={false}
      />
    </>
  )
}

export default InvoiceInfoTable
