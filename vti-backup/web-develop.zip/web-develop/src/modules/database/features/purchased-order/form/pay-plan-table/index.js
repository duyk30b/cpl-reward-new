import React from 'react'

import { IconButton } from '@mui/material'
import Box from '@mui/material/Box'
import { sumBy } from 'lodash'
import { useTranslation } from 'react-i18next'

import { ASYNC_SEARCH_LIMIT, MODAL_MODE } from '~/common/constants'
import { useApp } from '~/common/hooks/useApp'
import Button from '~/components/Button'
import DataTable from '~/components/DataTable'
import { Field } from '~/components/Formik'
import Icon from '~/components/Icon'
import NumberFormatText from '~/components/NumberFormat'
import { searchPaymentMethodApi } from '~/modules/database/redux/sagas/payment-method/search-payment-method'
import { convertUtcDateToLocalTz } from '~/utils'

function PayPlanTable({ payPlan, mode, arrayHelpers, values, setFieldValue }) {
  const { t } = useTranslation(['mesx'])
  const { scrollToBottom } = useApp()
  const isView = mode === MODAL_MODE.DETAIL

  const totalMoney = sumBy(values?.items, 'totalPrice')
  const getColumns = () => {
    return [
      {
        field: 'id',
        headerName: '#',
        width: 50,
        renderCell: (_, index) => {
          return index + 1
        },
      },
      {
        field: 'planDate',
        headerName: t('purchasedOrder.planDate'),
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <>{convertUtcDateToLocalTz(params.row?.planPayAt)}</>
          ) : (
            <Field.DatePicker name={`payPlan[${index}].planDate`} />
          )
        },
      },
      {
        field: 'payMethod',
        headerName: t('purchasedOrder.payMethod'),
        width: 150,
        renderCell: (params, index) => {
          return isView ? (
            <>{params.row?.paymentMethod?.name}</>
          ) : (
            <Field.Autocomplete
              name={`payPlan[${index}].payMethod`}
              asyncRequest={(s) =>
                searchPaymentMethodApi({
                  keyword: s,
                  limit: ASYNC_SEARCH_LIMIT,
                })
              }
              asyncRequestHelper={(res) => res?.data?.items}
              getOptionLabel={(opt) => opt?.code}
              getOptionSubLabel={(opt) => opt?.name}
              isOptionEqualToValue={(opt, val) => opt?.id === val?.id}
            />
          )
        },
      },
      {
        field: 'payPercent',
        headerName: t('purchasedOrder.payPercent'),
        align: 'right',
        headerAlign: 'left',
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <NumberFormatText value={params.row?.paymentRate} />
          ) : (
            <Field.TextField
              name={`payPlan[${index}].payPercent`}
              onChange={(val) => {
                setFieldValue(
                  `payPlan[${index}].payMoney`,
                  (totalMoney * val) / 100,
                )
              }}
            />
          )
        },
      },
      {
        field: 'payMoney',
        headerName: t('purchasedOrder.payMoney'),
        align: 'right',
        headerAlign: 'left',
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <NumberFormatText value={params.row?.totalPaymentAmount} />
          ) : (
            <Field.TextField
              name={`payPlan[${index}].payMoney`}
              numberProps={{
                decimalScale: 3,
                thousandSeparator: true,
              }}
              onChange={(val) => {
                setFieldValue(
                  `payPlan[${index}].payPercent`,
                  (val / totalMoney) * 100,
                )
              }}
            />
          )
        },
      },
      {
        field: 'payAccount',
        headerName: t('purchasedOrder.payAccount'),
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <>{params.row?.userAccount}</>
          ) : (
            <Field.TextField name={`payPlan[${index}].payAccount`} />
          )
        },
      },
      {
        field: 'description',
        headerName: t('purchasedOrder.description'),
        width: 100,
        renderCell: (params, index) => {
          return isView ? (
            <>{params.row?.description}</>
          ) : (
            <Field.TextField name={`payPlan[${index}].payDescription`} />
          )
        },
      },
      {
        field: 'remove',
        headerName: '',
        width: 60,
        align: 'center',
        hide: isView,
        sticky: 'right',
        renderCell: (params, index) => {
          return (
            <IconButton
              onClick={() => arrayHelpers.remove(index)}
              disabled={payPlan?.length === 1}
              size="large"
            >
              <Icon name="remove" />
            </IconButton>
          )
        },
      },
    ]
  }

  return (
    <>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'flex-end',
          alignItems: 'center',
          mb: 2,
        }}
      >
        {!isView && (
          <Button
            variant="outlined"
            onClick={() => {
              arrayHelpers.push({
                id: new Date().getTime(),
                planDate: null,
                payMethod: null,
                payPercent: null,
                payMoney: null,
                payAccount: '',
                payDescription: '',
              })
              scrollToBottom()
            }}
          >
            {t('purchasedOrder.item.addItem')}
          </Button>
        )}
      </Box>
      <DataTable
        rows={payPlan}
        columns={getColumns()}
        total={payPlan?.length}
        hideSetting
        hideFooter
        striped={false}
      />
    </>
  )
}

export default PayPlanTable
