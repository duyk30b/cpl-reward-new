import React, { useEffect, useMemo, useState } from 'react'

import { Grid } from '@mui/material'
import { Formik } from 'formik'
import { first } from 'lodash'
import { useTranslation } from 'react-i18next'
import { useParams, useHistory } from 'react-router-dom'

import { MODAL_MODE } from '~/common/constants'
import { useQueryState } from '~/common/hooks'
import ActionBar from '~/components/ActionBar'
import { Field } from '~/components/Formik'
import LV from '~/components/LabelValue'
import Page from '~/components/Page'
import Status from '~/components/Status'
import Tabs from '~/components/Tabs'
import {
  PURCHASED_ORDER_STATUS_OPTIONS,
  PURCHASED_ORDER_TYPE_MAP,
} from '~/modules/database/constants'
import usePurchasedOrder from '~/modules/database/redux/hooks/usePurchasedOrder'
import { ROUTE } from '~/modules/database/routes/config'
import Activities from '~/modules/mmsx/partials/Activities'
import { convertUtcDateTimeToLocalTz, convertUtcDateToLocalTz } from '~/utils'

import DeliveryTable from '../form/delivery-table'
import InvoiceInfoTable from '../form/invoice-info'
import ItemsSettingTable from '../form/items-setting-table'
import PayPlanTable from '../form/pay-plan-table'

const PurchasedOrderDetail = () => {
  const { t } = useTranslation(['mesx'])
  const history = useHistory()
  const { id } = useParams()
  const { withSearch } = useQueryState()
  const [versionId, setVersionId] = useState()

  const breadcrumbs = [
    {
      route: withSearch(ROUTE.PURCHASED_ORDER.LIST.PATH),
      title: ROUTE.PURCHASED_ORDER.LIST.TITLE,
    },
    {
      route: ROUTE.PURCHASED_ORDER.DETAIL.PATH,
      title: ROUTE.PURCHASED_ORDER.DETAIL.TITLE,
    },
  ]

  const {
    data: { isLoading, versionList, versionDetail },
    actions,
  } = usePurchasedOrder()

  useEffect(() => {
    actions.getPurchasedOrderDetailsById(id)
    return () => {
      actions.resetPurchasedOrderDetailsState()
    }
  }, [id])

  const backToList = () => {
    history.push(withSearch(ROUTE.PURCHASED_ORDER.LIST.PATH))
  }

  useEffect(() => {
    actions.getListVersionPO(id, (res) => setVersionId(first(res.data)?.id))
  }, [])

  useEffect(() => {
    if (versionId) {
      actions.getDetailVersionById({
        id,
        versionId,
      })
    }
  }, [versionId])

  const initialValues = useMemo(
    () => ({
      versions: first(versionList),
    }),
    [versionList],
  )

  const histories = versionDetail?.purchasedOrderHistories?.map((item) => ({
    content: item?.description,
    createdAt: item?.createdAt,
    id: item?.userId,
    username: item?.createdBy?.fullName,
    reason: item?.note,
  }))

  return (
    <Page
      breadcrumbs={breadcrumbs}
      title={t('menu.purchasedOrderDetail')}
      onBack={backToList}
      loading={isLoading}
    >
      <Grid container>
        <Grid item xs={12} lg={8} pl={1}>
          <LV
            label={t('purchasedOrder.orderStatus')}
            value={
              <Status
                options={PURCHASED_ORDER_STATUS_OPTIONS}
                value={versionDetail?.status}
              />
            }
          />
        </Grid>
        <Grid xl={0.2} xs={12}></Grid>
        <Grid item xs={12} lg={3.8} mt={-0.5} mb={1}>
          <Formik initialValues={initialValues} enableReinitialize>
            <Field.Autocomplete
              name="versions"
              label={t('purchasedOrder.versions')}
              placeholder={t('purchasedOrder.versions')}
              options={versionList}
              getOptionLabel={(opt) =>
                `${opt?.createdBy?.fullName} - ${convertUtcDateTimeToLocalTz(
                  opt?.createdAt,
                )}`
              }
              onChange={(val) => setVersionId(val?.id)}
              labelWidth={100}
            />
          </Formik>
        </Grid>
        <Grid
          item
          xl={8}
          xs={12}
          sx={(theme) => ({
            justifyContent: 'center',
            bgcolor: 'grayF4.main',
            borderRadius: 1,
            mb: 1,
            pt: 1,
            pb: 1,
            pr: 1,
            pl: 1,

            [theme.breakpoints.down('xl')]: {
              px: 2,
            },
          })}
        >
          <Grid container columnSpacing={{ xl: 3, xs: 2 }} rowSpacing={4 / 3}>
            <Grid item xs={12} lg={6}>
              <LV
                label={t('purchasedOrder.purchasedAt')}
                value={convertUtcDateToLocalTz(versionDetail?.orderedAt)}
              />
            </Grid>
            <Grid item xs={12} lg={6}>
              <LV
                label={t('purchasedOrder.code')}
                value={versionDetail?.code}
              />
            </Grid>
            <Grid item xs={12}>
              <LV
                label={t('purchasedOrder.name')}
                value={versionDetail?.name}
              />
            </Grid>
            <Grid item xs={12} lg={6}>
              <LV
                label={t('purchasedOrder.currencyUnit')}
                value={versionDetail?.currencyUnit?.name}
              />
            </Grid>
            <Grid item xs={12} lg={6}>
              <LV
                label={t('purchasedOrder.exchangeRate')}
                value={versionDetail?.currencyUnit?.exchangeRate?.rate}
              />
            </Grid>
            <Grid item xs={12} lg={6}>
              <LV
                label={t('purchasedOrder.type')}
                value={t(PURCHASED_ORDER_TYPE_MAP[versionDetail?.orderType])}
              />
            </Grid>
            <Grid item xs={12} lg={6}>
              <LV
                label={t('purchasedOrder.purchasedByUser')}
                value={versionDetail?.purchaseStaff?.fullName}
              />
            </Grid>
            <Grid item xs={12}>
              <LV label={t('purchasedOrder.file')} value={''} />
            </Grid>
            <Grid item xs={12}>
              <LV
                label={t('purchasedOrder.note')}
                value={versionDetail?.note}
              />
            </Grid>
          </Grid>
        </Grid>
        <Grid xl={0.1} xs={12}></Grid>
        <Grid
          item
          xl={3.9}
          xs={12}
          sx={(theme) => ({
            justifyContent: 'center',
            bgcolor: 'grayF4.main',
            borderRadius: 1,
            mb: 1,
            pt: 1,
            pb: 1,
            pr: 1,
            pl: 1,

            [theme.breakpoints.down('xl')]: {
              px: 2,
            },
          })}
        >
          <Grid container columnSpacing={{ xl: 3, xs: 2 }} rowSpacing={4 / 3}>
            <Grid item xs={12}>
              <LV
                label={t('purchasedOrder.vendor.code')}
                value={versionDetail?.vendor?.code}
              />
            </Grid>
            <Grid item xs={12}>
              <LV
                label={t('purchasedOrder.vendor.phone')}
                value={versionDetail?.vendor?.phone}
              />
            </Grid>
            <Grid item xs={12}>
              <LV
                label={t('purchasedOrder.vendor.tax')}
                value={versionDetail?.vendor?.taxCode}
              />
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <Tabs
        list={[
          {
            label: t('purchasedOrder.itemsDetails'),
          },
          {
            label: t('purchasedOrder.delivery'),
          },
          {
            label: t('purchasedOrder.payPlan'),
          },
          {
            label: t('purchasedOrder.invoiceInfo'),
          },
          {
            label: t('purchasedOrder.histories'),
          },
        ]}
        sx={{ mt: 1 }}
      >
        <ItemsSettingTable
          items={versionDetail?.purchasedOrderItemDetails?.map((e) => ({
            ...e,
            price: Number(e?.purchasePrice),
            totalPrice:
              (e?.purchasePrice * e?.quantity * (100 - e?.discount)) / 100,
          }))}
          mode={MODAL_MODE.DETAIL}
        />

        <DeliveryTable
          purchasedOrderDetails={versionDetail}
          items={versionDetail?.purchasedOrderDeliveryDetails}
          mode={MODAL_MODE.DETAIL}
        />

        <PayPlanTable
          payPlan={versionDetail?.purchasedOrderPaymentDetails}
          mode={MODAL_MODE.DETAIL}
        />
        <InvoiceInfoTable
          invoiceInfo={versionDetail?.purchasedOrderInvoiceDetails}
          mode={MODAL_MODE.DETAIL}
        />
        <Activities data={histories} />
      </Tabs>
      <ActionBar onBack={backToList} />
    </Page>
  )
}

export default PurchasedOrderDetail
