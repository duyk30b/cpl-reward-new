import React from 'react'

import { Box, Grid } from '@mui/material'
import { Form, Formik } from 'formik'
import { useTranslation } from 'react-i18next'

import { ASYNC_SEARCH_LIMIT } from '~/common/constants'
import Button from '~/components/Button'
import { Field } from '~/components/Formik'
import { searchUsersApi } from '~/modules/configuration/redux/sagas/user-management/search-users'
import {
  DELIVERY_STATUS_OPTIONS,
  PAY_STATUS_OPTIONS,
  PURCHASED_ORDER_STATUS_OPTIONS,
} from '~/modules/database/constants'
import { searchVendorsApi } from '~/modules/wmsx/redux/sagas/define-vendor/search-vendors'

const QuickFilter = ({ setQuickFilters, quickFilters, defaultFilter }) => {
  const { t } = useTranslation(['mesx'])
  const onSubmit = (values) => {
    setQuickFilters(values)
  }

  return (
    <Formik initialValues={quickFilters} onSubmit={onSubmit} enableReinitialize>
      {({ resetForm }) => {
        return (
          <Form>
            <Grid container justifyContent="center" sx={{ mb: 1.5 }}>
              <Grid item xl={11} xs={12}>
                <Grid container rowSpacing={1} columnSpacing={{ xl: 3, xs: 1 }}>
                  <Grid item lg={3} xs={12}>
                    <Field.DateRangePicker
                      name="purchasedAt"
                      label={t('purchasedOrder.purchasedAt')}
                      placeholder={t('purchasedOrder.purchasedAt')}
                      vertical
                      // labelWidth={100}
                    />
                  </Grid>
                  <Grid item lg={3} xs={12}>
                    <Field.DateRangePicker
                      name="deadline"
                      label={t('purchasedOrder.deadline')}
                      placeholder={t('purchasedOrder.deadline')}
                      vertical
                    />
                  </Grid>
                  <Grid item lg={3} xs={12}>
                    <Field.Autocomplete
                      name="vendorId"
                      label={t('purchasedOrder.vendor.code')}
                      placeholder={t('purchasedOrder.vendor.code')}
                      asyncRequest={(s) =>
                        searchVendorsApi({
                          keyword: s,
                          limit: ASYNC_SEARCH_LIMIT,
                        })
                      }
                      asyncRequestHelper={(res) => res?.data?.items}
                      getOptionLabel={(opt) => opt?.code}
                      getOptionSubLabel={(opt) => opt?.name}
                      vertical
                    />
                  </Grid>
                  <Grid item lg={3} xs={12}>
                    <Field.Autocomplete
                      name="purchasedByUser"
                      label={t('purchasedOrder.purchasedByUser')}
                      placeholder={t('purchasedOrder.purchasedByUser')}
                      asyncRequest={(s) =>
                        searchUsersApi({
                          keyword: s,
                          limit: ASYNC_SEARCH_LIMIT,
                        })
                      }
                      asyncRequestHelper={(res) => res?.data?.items}
                      getOptionLabel={(opt) => opt?.fullName || opt?.username}
                      vertical
                    />
                  </Grid>
                  <Grid item lg={3} xs={12}>
                    <Field.Autocomplete
                      name="deliveryStatus"
                      label={t('purchasedOrder.deliveryStatus')}
                      placeholder={t('purchasedOrder.deliveryStatus')}
                      options={DELIVERY_STATUS_OPTIONS}
                      getOptionLabel={(opt) => t(opt?.text)}
                      getOptionValue={(opt) => opt?.id}
                      vertical
                    />
                  </Grid>
                  <Grid item lg={3} xs={12}>
                    <Field.Autocomplete
                      name="payStatus"
                      label={t('purchasedOrder.payStatus')}
                      placeholder={t('purchasedOrder.payStatus')}
                      options={PAY_STATUS_OPTIONS}
                      getOptionLabel={(opt) => t(opt?.text)}
                      getOptionValue={(opt) => opt?.id}
                      vertical
                    />
                  </Grid>
                  <Grid item lg={3} xs={12}>
                    <Field.Autocomplete
                      name="status"
                      label={t('purchasedOrder.orderStatus')}
                      placeholder={t('purchasedOrder.orderStatus')}
                      options={PURCHASED_ORDER_STATUS_OPTIONS}
                      getOptionLabel={(opt) => (opt?.text ? t(opt?.text) : '')}
                      getOptionValue={(opt) => opt?.id?.toString()}
                      vertical
                    />
                  </Grid>
                  <Grid item lg={3} xs={12}>
                    <Box
                      sx={{
                        display: 'flex',
                        justifyContent: 'flex-end',
                        mt: 2,
                      }}
                    >
                      <Button
                        color="grayF4"
                        sx={{ mr: 1 }}
                        onClick={() => {
                          resetForm()
                          setQuickFilters(defaultFilter)
                        }}
                      >
                        {t('general:common.cancel')}
                      </Button>
                      <Button type="submit">
                        {t('general:common.search')}
                      </Button>
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Form>
        )
      }}
    </Formik>
  )
}

export default QuickFilter
