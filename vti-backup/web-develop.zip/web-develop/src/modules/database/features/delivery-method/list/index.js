import React, { useState, useEffect, useMemo } from 'react'

import IconButton from '@mui/material/IconButton'
import { useTranslation } from 'react-i18next'
import { useHistory } from 'react-router-dom'

import {
  ACTIVE_STATUS,
  ACTIVE_STATUS_OPTIONS,
  BULK_ACTION,
} from '~/common/constants'
import { API_URL } from '~/common/constants/apiUrl'
import { useQueryState } from '~/common/hooks'
import Button from '~/components/Button'
import DataTable from '~/components/DataTable'
import Dialog from '~/components/Dialog'
import Icon from '~/components/Icon'
import LV from '~/components/LabelValue'
import Page from '~/components/Page'
import Status from '~/components/Status'
import StatusSwitcher from '~/components/StatusSwitcher'
import useDeliveryMethod from '~/modules/database/redux/hooks/useDeliveryMethod'
import { ROUTE } from '~/modules/database/routes/config'
import { convertFilterParams, convertSortParams } from '~/utils'

import FilterForm from '../filter-form'

const breadcrumbs = [
  {
    route: ROUTE.DELIVERY_METHOD.LIST.PATH,
    title: ROUTE.DELIVERY_METHOD.LIST.TITLE,
  },
]
const DeliveryMethod = () => {
  const { t } = useTranslation(['database'])
  const history = useHistory()
  const [modal, setModal] = useState({
    tempItem: null,
    isOpenUpdateStatusModal: false,
    isOpenDeleteModal: false,
  })
  const [selectedRows, setSelectedRows] = useState([])
  const {
    data: { isLoading, deliveryMethodList, total },
    actions,
  } = useDeliveryMethod()

  const DEFAULT_FILTERS = {
    code: '',
    name: '',
  }

  const {
    page,
    pageSize,
    sort,
    filters,
    keyword,
    setPage,
    setPageSize,
    setSort,
    setFilters,
    setKeyword,
    withSearch,
    selectedRowsDeps,
  } = useQueryState({
    filters: DEFAULT_FILTERS,
  })

  const columns = useMemo(() => [
    {
      field: 'code',
      headerName: t('deliveryMethod.code'),
      width: 150,
      visible: 'always',
      sortable: true,
    },
    {
      field: 'name',
      headerName: t('deliveryMethod.name'),
      width: 200,
      visible: 'always',
      sortable: true,
    },
    {
      field: 'description',
      headerName: t('deliveryMethod.description'),
      width: 200,
    },
    {
      field: 'status',
      headerName: t('deliveryMethod.status'),
      width: 150,
      renderCell: (params) => {
        const status = Number(params?.row?.status)
        return (
          <Status
            options={ACTIVE_STATUS_OPTIONS}
            value={status}
            variant="text"
          />
        )
      },
    },
    {
      field: 'action',
      headerName: t('deliveryMethod.action'),
      width: 130,
      align: 'center',
      visible: 'always',
      sticky: 'right',
      renderCell: (params) => {
        const { id, status } = params?.row
        return (
          <>
            <IconButton
              onClick={() =>
                history.push(
                  withSearch(
                    ROUTE.DELIVERY_METHOD.DETAIL.PATH.replace(':id', `${id}`),
                  ),
                )
              }
            >
              <Icon name="show" />
            </IconButton>
            <IconButton
              onClick={() =>
                history.push(
                  withSearch(
                    ROUTE.DELIVERY_METHOD.EDIT.PATH.replace(':id', `${id}`),
                  ),
                )
              }
            >
              <Icon name="edit" />
            </IconButton>
            <IconButton onClick={() => handleActiveOpenModal(params?.row)}>
              <Icon
                name={status === ACTIVE_STATUS.ACTIVE ? 'locked' : 'unlock'}
              />
            </IconButton>
            <IconButton onClick={() => handleDeleteOpenModal(params?.row)}>
              <Icon name="delete" />
            </IconButton>
          </>
        )
      },
    },
  ])

  const refreshData = () => {
    const params = {
      keyword: keyword.trim(),
      page: page,
      limit: pageSize,
      filter: convertFilterParams(filters, columns),
      sort: convertSortParams(sort),
    }
    actions.searchDeliveryMethod(params)
  }

  useEffect(() => {
    refreshData()
  }, [page, pageSize, sort, filters, keyword])

  useEffect(() => {
    setSelectedRows([])
  }, [selectedRowsDeps])

  const handleActiveOpenModal = (tempItem) => {
    setModal({ tempItem, isOpenUpdateStatusModal: true })
  }

  const handleDeleteOpenModal = (tempItem) => {
    setModal({ tempItem, isOpenDeleteModal: true })
  }

  const onSubmitUpdateStatus = () => {
    if (modal.tempItem?.status === ACTIVE_STATUS.ACTIVE) {
      actions.inactiveDeliveryMethod(modal.tempItem?.id, () => {
        refreshData()
      })
    } else if (modal.tempItem?.status === ACTIVE_STATUS.INACTIVE) {
      actions.activeDeliveryMethod(modal.tempItem?.id, () => {
        refreshData()
      })
    }
    setModal({ isOpenUpdateStatusModal: false, tempItem: null })
  }

  const onSubmitDelete = () => {
    actions.deleteDeliveryMethod(modal.tempItem?.id, () => {
      refreshData()
    })
    setModal({ isOpenDeleteModal: false, tempItem: null })
  }

  const renderHeaderRight = () => {
    return (
      <Button
        onClick={() =>
          history.push(withSearch(ROUTE.DELIVERY_METHOD.CREATE.PATH))
        }
        icon="add"
        sx={{ ml: 4 / 3 }}
      >
        {t('general:common.create')}
      </Button>
    )
  }

  return (
    <Page
      breadcrumbs={breadcrumbs}
      title={t('menu.deliveryMethod')}
      onSearch={setKeyword}
      keyword={keyword}
      placeholder={t('deliveryMethod.searchPlaceholder')}
      renderHeaderRight={renderHeaderRight}
      loading={isLoading}
    >
      <DataTable
        title={t('deliveryMethod.titleTable')}
        rows={deliveryMethodList}
        pageSize={pageSize}
        page={page}
        columns={columns}
        onPageChange={setPage}
        onPageSizeChange={setPageSize}
        onSortChange={setSort}
        onSelectionChange={setSelectedRows}
        selected={selectedRows}
        total={total}
        filters={{
          form: <FilterForm />,
          defaultValue: DEFAULT_FILTERS,
          values: filters,
          onApply: setFilters,
        }}
        sort={sort}
        bulkActions={{
          actions: [BULK_ACTION.DELETE],
          apiUrl: API_URL.DELIVERY_METHOD,
          onSuccess: () => {
            if (page === 1) {
              refreshData()
            } else {
              setPage(1)
            }
            setSelectedRows([])
          },
        }}
      />
      <Dialog
        open={modal.isOpenUpdateStatusModal}
        title={t('general.updateStatus')}
        onCancel={() =>
          setModal({ isOpenUpdateStatusModal: false, tempItem: null })
        }
        cancelLabel={t('general:common.no')}
        onSubmit={onSubmitUpdateStatus}
        submitLabel={t('general:common.yes')}
        {...(modal?.tempItem?.status === ACTIVE_STATUS.ACTIVE
          ? {
              submitProps: {
                color: 'error',
              },
            }
          : {})}
        noBorderBottom
      >
        {t('general.confirmMessage')}
        <LV
          label={t('deliveryMethod.code')}
          value={modal?.tempItem?.code}
          sx={{ mt: 1 }}
        />
        <LV
          label={t('deliveryMethod.name')}
          value={modal?.tempItem?.name}
          sx={{ mt: 1 }}
        />
        <LV
          label={t('general.status')}
          value={
            <StatusSwitcher
              options={ACTIVE_STATUS_OPTIONS}
              value={modal?.tempItem?.status}
            />
          }
          sx={{ mt: 1 }}
        />
      </Dialog>
      <Dialog
        open={modal?.isOpenDeleteModal}
        title={t('deliveryMethod.deleteTitle')}
        onCancel={() =>
          setModal({ isOpenUpdateStatusModal: false, tempItem: null })
        }
        cancelLabel={t('general:common.no')}
        onSubmit={onSubmitDelete}
        submitLabel={t('general:common.yes')}
        submitProps={{
          color: 'error',
        }}
        noBorderBottom
      >
        {t('deliveryMethod.confirmDetele')}
        <LV
          label={t('deliveryMethod.code')}
          value={modal?.tempItem?.code}
          sx={{ mt: 4 / 3 }}
        />
        <LV
          label={t('deliveryMethod.name')}
          value={modal?.tempItem?.name}
          sx={{ mt: 4 / 3 }}
        />
      </Dialog>
    </Page>
  )
}

export default DeliveryMethod
