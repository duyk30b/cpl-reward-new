import React, { useEffect, useMemo } from 'react'

import Grid from '@mui/material/Grid'
import { Formik, Form } from 'formik'
import { useTranslation } from 'react-i18next'
import { useParams, useHistory, useRouteMatch } from 'react-router-dom'

import {
  MODAL_MODE,
  TEXTFIELD_ALLOW,
  TEXTFIELD_REQUIRED_LENGTH,
} from '~/common/constants'
import { useQueryState } from '~/common/hooks'
import ActionBar from '~/components/ActionBar'
import { Field } from '~/components/Formik'
import Page from '~/components/Page'
import useDeliveryMethod from '~/modules/database/redux/hooks/useDeliveryMethod'
import { ROUTE } from '~/modules/database/routes/config'

import { deliveryMethodSchema } from './schema'

const DeliveryMethodForm = () => {
  const { t } = useTranslation(['database'])
  const history = useHistory()
  const routeMatch = useRouteMatch()
  const { id } = useParams()
  const { withSearch } = useQueryState()

  const {
    data: { isLoading, deliveryMethodDetail },
    actions,
  } = useDeliveryMethod()

  const initialValues = useMemo(
    () => ({
      code: deliveryMethodDetail?.code || '',
      name: deliveryMethodDetail?.name || '',
      description: deliveryMethodDetail?.description || '',
    }),
    [deliveryMethodDetail],
  )

  const MODE_MAP = {
    [ROUTE.DELIVERY_METHOD.CREATE.PATH]: MODAL_MODE.CREATE,
    [ROUTE.DELIVERY_METHOD.EDIT.PATH]: MODAL_MODE.UPDATE,
  }

  const mode = MODE_MAP[routeMatch.path]
  const isUpdate = mode === MODAL_MODE.UPDATE

  const getBreadcrumb = () => {
    const breadcrumb = [
      {
        route: withSearch(ROUTE.DELIVERY_METHOD.LIST.PATH),
        title: ROUTE.DELIVERY_METHOD.LIST.TITLE,
      },
    ]
    switch (mode) {
      case MODAL_MODE.CREATE:
        breadcrumb.push({
          route: ROUTE.DELIVERY_METHOD.CREATE.PATH,
          title: ROUTE.DELIVERY_METHOD.CREATE.TITLE,
        })
        break
      case MODAL_MODE.UPDATE:
        breadcrumb.push({
          route: ROUTE.DELIVERY_METHOD.EDIT.PATH,
          title: ROUTE.DELIVERY_METHOD.EDIT.TITLE,
        })
        break
      default:
        break
    }
    return breadcrumb
  }

  const getTitle = () => {
    switch (mode) {
      case MODAL_MODE.CREATE:
        return ROUTE.DELIVERY_METHOD.CREATE.TITLE
      case MODAL_MODE.UPDATE:
        return ROUTE.DELIVERY_METHOD.EDIT.TITLE
      default:
        break
    }
  }

  const renderActionBar = (handleReset) => {
    switch (mode) {
      case MODAL_MODE.CREATE:
        return (
          <ActionBar
            onBack={backToList}
            onCancel={handleReset}
            mode={MODAL_MODE.CREATE}
          />
        )
      case MODAL_MODE.UPDATE:
        return (
          <ActionBar
            onBack={backToList}
            onCancel={handleReset}
            mode={MODAL_MODE.UPDATE}
          />
        )
      default:
    }
  }

  const backToList = () => {
    history.push(withSearch(ROUTE.DELIVERY_METHOD.LIST.PATH))
  }

  useEffect(() => {
    if (mode === MODAL_MODE.UPDATE) {
      actions.getDeliveryMethodDetailById(id)
    }

    return () => {
      if (isUpdate) actions.resetDeliveryMethodDetailState()
    }
  }, [id])

  const onSubmit = (values) => {
    if (mode === MODAL_MODE.CREATE) {
      actions.createDeliveryMethod(values, () =>
        history.push(ROUTE.DELIVERY_METHOD.LIST.PATH),
      )
    } else if (mode === MODAL_MODE.UPDATE) {
      const paramUpdate = { ...values, id }
      actions.updateDeliveryMethod(paramUpdate, () => backToList())
    }
  }

  return (
    <Page
      breadcrumbs={getBreadcrumb()}
      title={t(`menu.${getTitle()}`)}
      loading={isLoading}
      onBack={backToList}
    >
      <Grid container justifyContent="center">
        <Grid item xl={11} xs={12}>
          <Formik
            initialValues={initialValues}
            validationSchema={deliveryMethodSchema(t)}
            onSubmit={onSubmit}
            enableReinitialize
          >
            {({ handleReset }) => (
              <Form>
                <Grid
                  container
                  rowSpacing={4 / 3}
                  columnSpacing={{ xl: 8, xs: 4 }}
                >
                  <Grid item lg={6} xs={12}>
                    <Field.TextField
                      name="code"
                      label={t('deliveryMethod.code')}
                      placeholder={t('deliveryMethod.code')}
                      disabled={isUpdate}
                      inputProps={{
                        maxLength: TEXTFIELD_REQUIRED_LENGTH.CODE_50.MAX,
                      }}
                      allow={TEXTFIELD_ALLOW.ALPHANUMERIC}
                      required
                    />
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Field.TextField
                      name="name"
                      label={t('deliveryMethod.name')}
                      placeholder={t('deliveryMethod.name')}
                      inputProps={{
                        maxLength: TEXTFIELD_REQUIRED_LENGTH.CODE_50.MAX,
                      }}
                      required
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Field.TextField
                      name="description"
                      label={t('deliveryMethod.description')}
                      placeholder={t('deliveryMethod.description')}
                      inputProps={{
                        maxLength: TEXTFIELD_REQUIRED_LENGTH.COMMON.MAX,
                      }}
                      multiline
                      rows={3}
                    />
                  </Grid>
                </Grid>
                {renderActionBar(handleReset)}
              </Form>
            )}
          </Formik>
        </Grid>
      </Grid>
    </Page>
  )
}
export default DeliveryMethodForm
