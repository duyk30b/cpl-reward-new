import React from 'react'

import { Box, Grid } from '@mui/material'
import { subDays } from 'date-fns'
import { Form, Formik } from 'formik'
import { useTranslation } from 'react-i18next'

import Button from '~/components/Button'
import { Field } from '~/components/Formik'

const QuickFilter = ({ setQuickFilters, defaultFilter }) => {
  const { t } = useTranslation(['database'])
  const onSubmit = (values) => {
    setQuickFilters(values)
  }

  return (
    <Formik
      initialValues={defaultFilter}
      onSubmit={onSubmit}
      enableReinitialize
    >
      {({ resetForm }) => (
        <Form>
          <Grid container justifyContent="center" sx={{ mb: 4 }}>
            <Grid item xl={11} xs={12}>
              <Grid
                container
                rowSpacing={4 / 3}
                columnSpacing={{ xl: 8, xs: 4 }}
              >
                <Grid item lg={6} xs={12}>
                  <Field.DateRangePicker
                    name="createdAt"
                    label={t('currencyRate.updatedAt')}
                    placeholder={t('currencyRate.updatedAt')}
                    maxDate={new Date()}
                    minDate={subDays(new Date(), 30)}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <Button
                      color="grayF4"
                      sx={{ mr: 1 }}
                      onClick={() => {
                        resetForm()
                        setQuickFilters(defaultFilter)
                      }}
                    >
                      {t('general:common.cancel')}
                    </Button>
                    <Button type="submit">{t('general:common.search')}</Button>
                  </Box>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  )
}

export default QuickFilter
