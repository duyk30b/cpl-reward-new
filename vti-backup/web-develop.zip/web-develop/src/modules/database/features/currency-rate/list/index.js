import React from 'react'

import { useTranslation } from 'react-i18next'
import { useHistory, Redirect, useLocation } from 'react-router-dom'

import { useQueryState } from '~/common/hooks'
import Button from '~/components/Button'
import Page from '~/components/Page'
import Tabs from '~/components/Tabs'
import useCurrencyRate from '~/modules/database/redux/hooks/useCurrencyRate'
import { ROUTE } from '~/modules/database/routes/config'
import { TAB_QUERY_STR_KEY } from '~/modules/qmsx/constants'
import qs from '~/utils/qs'

import ChangeHistory from './change-history'
import CurrencyRateList from './currency-rate-list'

const breadcrumbs = [
  {
    route: ROUTE.CURRENCY_RATE.LIST.PATH,
    title: ROUTE.CURRENCY_RATE.LIST.TITLE,
  },
]
const CurrencyRate = () => {
  const { t } = useTranslation(['database'])
  const history = useHistory()
  const location = useLocation()
  const locationSearch = location.search
  const { [TAB_QUERY_STR_KEY]: tab } = qs.parse(locationSearch)
  const {
    data: { isLoading, total },
  } = useCurrencyRate()

  const { keyword, setKeyword, withSearch } = useQueryState()

  const [currencyRate, changeHistory] = ['currencyRate', 'changeHistory']

  const tabs = [
    {
      label: t(`currencyRate.${currencyRate}`),
      value: currencyRate,
    },
    {
      label: t(`currencyRate.${changeHistory}`),
      value: changeHistory,
    },
  ]

  const renderHeaderRight = () => {
    if (total > 0) {
      return (
        <Button
          onClick={() =>
            history.push(withSearch(ROUTE.CURRENCY_RATE.EDIT.PATH))
          }
          sx={{ ml: 4 / 3 }}
        >
          {t('currencyRate.create')}
        </Button>
      )
    } else {
      return (
        <Button
          onClick={() =>
            history.push(withSearch(ROUTE.CURRENCY_RATE.CREATE.PATH))
          }
          sx={{ ml: 4 / 3 }}
        >
          {t('currencyRate.create')}
        </Button>
      )
    }
  }

  const handleChangeTab = (newValue) => {
    const tempPath = withSearch('', {
      omitSpecificKeys: [TAB_QUERY_STR_KEY],
    })

    const path = `${tempPath}${
      tempPath.includes('?') ? '&' : '?'
    }${TAB_QUERY_STR_KEY}=${newValue}`

    history.push(path)
  }

  if (!tab) {
    return (
      <Redirect
        to={{
          pathname: location.pathname,
          search: `?${TAB_QUERY_STR_KEY}=${currencyRate}`,
        }}
      />
    )
  }

  return (
    <Page
      breadcrumbs={breadcrumbs}
      title={t('menu.currencyRate')}
      onSearch={setKeyword}
      keyword={keyword}
      placeholder={t('currencyRate.searchPlaceholder')}
      renderHeaderRight={renderHeaderRight}
      loading={isLoading}
    >
      <Tabs list={tabs} sx={{ mt: 1 }} onChange={handleChangeTab} value={tab}>
        {/* Tab 1 */}
        <CurrencyRateList keyword={keyword} />
        {/* Tab 2 */}
        <ChangeHistory keyword={keyword} />
      </Tabs>
    </Page>
  )
}

export default CurrencyRate
