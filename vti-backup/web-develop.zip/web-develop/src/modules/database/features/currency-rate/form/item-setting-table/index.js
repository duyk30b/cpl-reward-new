import { Box, Typography, IconButton } from '@mui/material'
import { useTranslation } from 'react-i18next'

import { ACTIVE_STATUS, ASYNC_SEARCH_LIMIT } from '~/common/constants'
import { useApp } from '~/common/hooks/useApp'
import Button from '~/components/Button'
import DataTable from '~/components/DataTable'
import { Field } from '~/components/Formik'
import Icon from '~/components/Icon'
import { searchCurrencyUnitApi } from '~/modules/database/redux/sagas/currency-unit/search-currency-unit'
import { convertFilterParams } from '~/utils'

const ItemSettingTable = ({ items, arrayHelpers, setFieldValue, values }) => {
  const { t } = useTranslation(['database'])
  const { scrollToBottom } = useApp()
  const columns = [
    {
      field: 'stt',
      headerName: t('currencyRate.index'),
      width: 80,
      visible: 'always',
      renderCell: (_, index) => index + 1,
    },
    {
      field: 'code',
      headerName: t('currencyRate.code'),
      width: 180,
      renderCell: (params, index) => {
        let itemIdCodeList = items.map((item) => item?.code?.id)
        itemIdCodeList.push(values?.mainCurrency?.id)
        return (
          <Field.Autocomplete
            name={`items[${index}].code`}
            placeholder={t('currencyRate.code')}
            asyncRequest={(s) =>
              searchCurrencyUnitApi({
                keyword: s,
                limit: ASYNC_SEARCH_LIMIT,
                filter: convertFilterParams({
                  status: ACTIVE_STATUS.ACTIVE,
                }),
              })
            }
            asyncRequestHelper={(res) => res?.data?.items}
            getOptionLabel={(opt) => opt?.code}
            getOptionSubLabel={(opt) => opt?.name}
            isOptionEqualToValue={(opt, val) => opt?.id === val?.id}
            onChange={(val) => {
              setFieldValue(`items[${index}].type`, val?.name)
            }}
            getOptionDisabled={(opt) =>
              itemIdCodeList.some((id) => id === opt?.id) &&
              opt?.id !== items[index]?.code?.id
            }
          />
        )
      },
    },
    {
      field: 'type',
      headerName: t('currencyRate.name'),
      width: 200,
      renderCell: (params, index) => {
        return (
          <Field.TextField
            name={`items[${index}].type`}
            placeholder={t('currencyRate.name')}
            disabled
          />
        )
      },
    },
    {
      field: 'rate',
      headerName: t('currencyRate.rate'),
      width: 200,
      renderCell: (params, index) => {
        return (
          <Field.TextField
            name={`items[${index}].rate`}
            placeholder={t('currencyRate.rate')}
            numberProps={{
              thousandSeparator: ' ',
              decimalScale: 5,
            }}
          />
        )
      },
    },
    {
      field: 'remove',
      headerName: '',
      width: 50,
      align: 'center',
      sticky: 'right',
      renderCell: (params) => {
        const idx = items.findIndex((item) => item.id === params.row.id)
        return (
          <IconButton
            size="small"
            onClick={() => arrayHelpers.remove(idx)}
            disabled={items?.length === 1}
          >
            <Icon name="remove" />
          </IconButton>
        )
      },
    },
  ]
  return (
    <>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 3 / 2,
        }}
      >
        <Typography variant="h4" component="span">
          {t('currencyRate.currencyRateList')}
        </Typography>
        <Button
          variant="outlined"
          onClick={() => {
            arrayHelpers.push({
              idx: new Date().getTime(),
              code: null,
              type: '',
              rate: 1,
            })
            scrollToBottom()
          }}
        >
          {t('currencyRate.addItem')}
        </Button>
      </Box>
      <DataTable
        rows={items}
        columns={columns}
        striped={false}
        hideSetting
        hideFooter
      />
    </>
  )
}

export default ItemSettingTable
