import * as Yup from 'yup'

import { NUMBER_FIELD_REQUIRED_SIZE } from '~/common/constants'

export const currencyRateSchema = (t) => {
  return Yup.object().shape({
    mainCurrency: Yup.object().nullable().required(t('general:form.required')),
    items: Yup.array().of(
      Yup.object().shape({
        code: Yup.object().nullable().required(t('general:form.required')),
        rate: Yup.number()
          .required(t('general:form.required'))
          .min(
            NUMBER_FIELD_REQUIRED_SIZE.EXCHANGE_RATE.MIN,
            t('currencyRate.minRateValidate', {
              min: NUMBER_FIELD_REQUIRED_SIZE.EXCHANGE_RATE.MIN,
            }),
          )
          .max(
            NUMBER_FIELD_REQUIRED_SIZE.EXCHANGE_RATE.MAX,
            t('currencyRate.maxRateValidate', {
              max: NUMBER_FIELD_REQUIRED_SIZE.EXCHANGE_RATE.MAX,
            }),
          ),
      }),
    ),
  })
}
