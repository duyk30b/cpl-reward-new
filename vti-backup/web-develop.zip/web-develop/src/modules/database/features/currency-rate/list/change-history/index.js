import { useEffect, useMemo } from 'react'

import { useTranslation } from 'react-i18next'

import { useQueryState } from '~/common/hooks'
import DataTable from '~/components/DataTable'
import Loading from '~/components/Loading'
import useCurrencyRate from '~/modules/database/redux/hooks/useCurrencyRate'
import {
  convertFilterParams,
  convertSortParams,
  convertUtcDateToLocalTz,
} from '~/utils'

import QuickFilter from './quick-filter'

const ChangeHistory = ({ keyword }) => {
  const { t } = useTranslation(['database'])
  const {
    page,
    pageSize,
    sort,
    quickFilters,
    setPage,
    setPageSize,
    setSort,
    setQuickFilters,
  } = useQueryState({}, { prefix: 'tab2_' })

  const DEFAULT_QUICK_FILTERS = {
    createdAt: [null, null],
  }

  const {
    data: { totalHistory, currencyRateHistory, isLoading },
    actions,
  } = useCurrencyRate()

  const refreshData = () => {
    const params = {
      keyword: keyword.trim(),
      page: page,
      limit: pageSize,
      filter: convertFilterParams(quickFilters, [
        { field: 'createdAt', filterFormat: 'date' },
      ]),
      sort: convertSortParams(sort),
    }
    actions.searchCurrencyRateHistory(params)
  }

  useEffect(() => {
    refreshData()
  }, [page, pageSize, sort, quickFilters, keyword])

  const columns = useMemo(() => [
    {
      field: 'mainCurrency',
      headerName: t('currencyRate.mainCurrency'),
      width: 180,
      visible: 'always',
      sortable: true,
      renderCell: (params) => params?.row?.fromUnit?.name,
    },
    {
      field: 'exchangeCurrencyCode',
      headerName: t('currencyRate.exchangeCurrencyCode'),
      width: 180,
      visible: 'always',
      sortable: true,
      renderCell: (params) => params?.row?.toUnit?.code,
    },
    {
      field: 'name',
      headerName: t('currencyRate.name'),
      width: 180,
      sortable: true,
      renderCell: (params) => params?.row?.toUnit?.name,
    },
    {
      field: 'oldRate',
      headerName: t('currencyRate.oldRate'),
      width: 180,
      align: 'right',
      headerAlign: 'left',
      visible: 'always',
      sortable: true,
      renderCell: (params) => params?.row?.rate,
    },
    {
      field: 'newRate',
      headerName: t('currencyRate.newRate'),
      width: 180,
      align: 'right',
      headerAlign: 'left',
      visible: 'always',
      sortable: true,
    },
    {
      field: 'updatedAt',
      headerName: t('currencyRate.updatedAt'),
      width: 180,
      sortable: true,
      renderCell: (params) => convertUtcDateToLocalTz(params?.row?.updatedAt),
    },
    {
      field: 'updatedBy',
      headerName: t('currencyRate.updatedBy'),
      width: 180,
      sortable: true,
      renderCell: (params) => params?.row?.createdBy?.fullName,
    },
  ])

  return (
    <>
      <Loading open={isLoading} />
      <QuickFilter
        setQuickFilters={setQuickFilters}
        defaultFilter={DEFAULT_QUICK_FILTERS}
      />
      <DataTable
        title={t('currencyRate.currencyRateList')}
        rows={currencyRateHistory}
        pageSize={pageSize}
        page={page}
        columns={columns}
        onPageChange={setPage}
        onPageSizeChange={setPageSize}
        onSortChange={setSort}
        total={totalHistory}
        sort={sort}
      />
    </>
  )
}

export default ChangeHistory
