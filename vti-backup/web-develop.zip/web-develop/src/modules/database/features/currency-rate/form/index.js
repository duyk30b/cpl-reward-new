import React, { useEffect, useMemo } from 'react'

import { Box } from '@mui/material'
import Grid from '@mui/material/Grid'
import { Formik, Form, FieldArray } from 'formik'
import { isEmpty } from 'lodash'
import { useTranslation } from 'react-i18next'
import { useHistory, useRouteMatch } from 'react-router-dom'

import {
  ACTIVE_STATUS,
  ASYNC_SEARCH_LIMIT,
  MODAL_MODE,
} from '~/common/constants'
import { useQueryState } from '~/common/hooks'
import ActionBar from '~/components/ActionBar'
import { Field } from '~/components/Formik'
import Page from '~/components/Page'
import useCurrencyRate from '~/modules/database/redux/hooks/useCurrencyRate'
import { searchCurrencyUnitApi } from '~/modules/database/redux/sagas/currency-unit/search-currency-unit'
import { ROUTE } from '~/modules/database/routes/config'
import { convertFilterParams } from '~/utils'

import ItemSettingTable from './item-setting-table'
import { currencyRateSchema } from './schema'

const CurrencyRateForm = () => {
  const { t } = useTranslation(['database'])
  const history = useHistory()
  const routeMatch = useRouteMatch()
  const { withSearch } = useQueryState()

  const {
    data: { isLoading, currencyRateList, mainCurrency },
    actions,
  } = useCurrencyRate()

  const DEFAULT_ITEM = {
    id: new Date().getTime(),
    code: null,
    type: '',
    rate: 1,
  }

  useEffect(() => {
    actions.getMainCurrency()
  }, [])

  useEffect(() => {
    if (!isEmpty(mainCurrency)) {
      actions.searchCurrencyRateList({
        filter: convertFilterParams({
          fromCurrencyUnitId: mainCurrency?.id,
        }),
      })
    }
  }, [mainCurrency])

  const initialValues = useMemo(() => {
    const initItems = currencyRateList?.map((item) => ({
      id: item?.id,
      code: item?.toUnit,
      type: item?.toUnit?.name,
      rate: item?.rate,
    }))
    return {
      mainCurrency: mainCurrency || null,
      items: !isEmpty(initItems) ? initItems : [DEFAULT_ITEM],
    }
  }, [currencyRateList])

  const MODE_MAP = {
    [ROUTE.CURRENCY_RATE.EDIT.PATH]: MODAL_MODE.UPDATE,
    [ROUTE.CURRENCY_RATE.CREATE.PATH]: MODAL_MODE.CREATE,
  }

  const mode = MODE_MAP[routeMatch.path]

  const getBreadcrumb = () => {
    const breadcrumb = [
      {
        route: withSearch(ROUTE.CURRENCY_RATE.LIST.PATH),
        title: ROUTE.CURRENCY_RATE.LIST.TITLE,
      },
    ]
    switch (mode) {
      case MODAL_MODE.UPDATE:
        breadcrumb.push({
          route: ROUTE.CURRENCY_RATE.EDIT.PATH,
          title: ROUTE.CURRENCY_RATE.EDIT.TITLE,
        })
        break
      case MODAL_MODE.CREATE:
        breadcrumb.push({
          route: ROUTE.CURRENCY_RATE.CREATE.PATH,
          title: ROUTE.CURRENCY_RATE.CREATE.TITLE,
        })
        break
      default:
        break
    }
    return breadcrumb
  }

  const getTitle = () => {
    switch (mode) {
      case MODAL_MODE.UPDATE:
        return ROUTE.CURRENCY_RATE.EDIT.TITLE
      case MODAL_MODE.CREATE:
        return ROUTE.CURRENCY_RATE.CREATE.TITLE
      default:
        break
    }
  }

  const renderActionBar = (handleReset) => {
    switch (mode) {
      case MODAL_MODE.UPDATE:
        return (
          <ActionBar
            onBack={backToList}
            onCancel={handleReset}
            mode={MODAL_MODE.UPDATE}
          />
        )
      case MODAL_MODE.CREATE:
        return (
          <ActionBar
            onBack={backToList}
            onCancel={handleReset}
            mode={MODAL_MODE.CREATE}
          />
        )
      default:
    }
  }

  const backToList = () => {
    history.push(withSearch(ROUTE.CURRENCY_RATE.LIST.PATH))
  }

  const onSubmit = (values) => {
    const toUnits = values?.items?.map((item) => ({
      toCurrencyUnitId: item?.code?.id,
      rate: item?.rate,
    }))
    const convertValues = {
      fromCurrencyUnitId: values?.mainCurrency?.id,
      toUnits: toUnits,
      description: '',
    }
    actions.createCurrencyRate(convertValues, () =>
      history.push(ROUTE.CURRENCY_RATE.LIST.PATH),
    )
  }

  return (
    <Page
      breadcrumbs={getBreadcrumb()}
      title={t(`menu.${getTitle()}`)}
      loading={isLoading}
      onBack={backToList}
    >
      <Grid container justifyContent="center">
        <Grid item xl={11} xs={12}>
          <Formik
            initialValues={initialValues}
            validationSchema={currencyRateSchema(t)}
            onSubmit={onSubmit}
            enableReinitialize
          >
            {({ handleReset, values, setFieldValue }) => (
              <Form>
                <Grid
                  container
                  rowSpacing={4 / 3}
                  columnSpacing={{ xl: 8, xs: 4 }}
                >
                  <Grid item lg={6} xs={12}>
                    <Field.Autocomplete
                      name="mainCurrency"
                      label={t('currencyRate.mainCurrency')}
                      placeholder={t('currencyRate.mainCurrency')}
                      asyncRequest={(s) =>
                        searchCurrencyUnitApi({
                          keyword: s,
                          limit: ASYNC_SEARCH_LIMIT,
                          filter: convertFilterParams({
                            status: ACTIVE_STATUS.ACTIVE,
                          }),
                        })
                      }
                      asyncRequestHelper={(res) => res?.data?.items}
                      getOptionLabel={(opt) => opt?.code}
                      getOptionSubLabel={(opt) => opt?.name}
                      isOptionEqualToValue={(opt, val) => opt?.id === val?.id}
                      onChange={() => setFieldValue(`items`, [DEFAULT_ITEM])}
                      required
                    />
                  </Grid>
                </Grid>
                <Box sx={{ mt: 2 }}>
                  <FieldArray
                    name="items"
                    render={(arrayHelpers) => (
                      <ItemSettingTable
                        items={values?.items || []}
                        arrayHelpers={arrayHelpers}
                        setFieldValue={setFieldValue}
                        values={values}
                      />
                    )}
                  />
                </Box>
                {renderActionBar(handleReset)}
              </Form>
            )}
          </Formik>
        </Grid>
      </Grid>
    </Page>
  )
}
export default CurrencyRateForm
