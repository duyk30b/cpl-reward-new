import { useEffect, useMemo } from 'react'

import { Grid } from '@mui/material'
import { isEmpty } from 'lodash'
import { useTranslation } from 'react-i18next'

import { useQueryState } from '~/common/hooks'
import DataTable from '~/components/DataTable'
import LabelValue from '~/components/LabelValue'
import Loading from '~/components/Loading'
import useCurrencyRate from '~/modules/database/redux/hooks/useCurrencyRate'
import {
  convertFilterParams,
  convertSortParams,
  convertUtcDateToLocalTz,
} from '~/utils'

const CurrencyRateList = ({ keyword }) => {
  const { t } = useTranslation(['database'])
  const { page, pageSize, sort, setPage, setPageSize, setSort } =
    useQueryState()

  const {
    data: { isLoading, currencyRateList, total, mainCurrency },
    actions,
  } = useCurrencyRate()

  const columns = useMemo(() => [
    {
      field: 'code',
      headerName: t('currencyRate.code'),
      width: 200,
      visible: 'always',
      sortable: true,
      renderCell: (params) => params?.row?.toUnit?.code,
    },
    {
      field: 'name',
      headerName: t('currencyRate.name'),
      width: 200,
      visible: 'always',
      sortable: true,
      renderCell: (params) => params?.row?.toUnit?.name,
    },
    {
      field: 'rate',
      headerName: t('currencyRate.rate'),
      width: 200,
      align: 'right',
      headerAlign: 'left',
      visible: 'always',
      sortable: true,
    },
    {
      field: 'createdAt',
      headerName: t('currencyRate.updatedAt'),
      width: 200,
      sortable: true,
      renderCell: (params) => convertUtcDateToLocalTz(params?.row?.createdAt),
    },
    {
      field: 'createdBy',
      headerName: t('currencyRate.updatedBy'),
      width: 200,
      sortable: true,
      renderCell: (params) => params?.row?.createdBy?.fullName,
    },
  ])

  useEffect(() => {
    actions.getMainCurrency()
  }, [])

  const refreshData = () => {
    const params = {
      keyword: keyword.trim(),
      page: page,
      limit: pageSize,
      filter: convertFilterParams({
        fromCurrencyUnitId: mainCurrency?.id,
      }),
      sort: convertSortParams(sort),
    }
    actions.searchCurrencyRateList(params)
  }

  useEffect(() => {
    refreshData()
  }, [page, pageSize, sort, keyword, mainCurrency])

  return (
    <>
      <Loading open={isLoading} />
      <Grid container justifyContent="center">
        <Grid item lg={12} xs={12} sx={{ mb: 2 }}>
          <LabelValue
            label={t('currencyRate.mainCurrency')}
            value={
              isEmpty(mainCurrency)
                ? ''
                : `${mainCurrency?.code} - ${mainCurrency?.name}`
            }
          />
        </Grid>
        <DataTable
          title={t('currencyRate.currencyRateList')}
          rows={currencyRateList}
          pageSize={pageSize}
          page={page}
          columns={columns}
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
          onSortChange={setSort}
          total={total}
          sort={sort}
        />
      </Grid>
    </>
  )
}

export default CurrencyRateList
