import React from 'react'

import { Stack } from '@mui/material'
import { useFormikContext } from 'formik'
import { useTranslation } from 'react-i18next'

import {
  MODAL_MODE,
  TEXTFIELD_ALLOW,
  TEXTFIELD_REQUIRED_LENGTH,
} from '~/common/constants'
import ActionBar from '~/components/ActionBar'
import Dialog from '~/components/Dialog'
import { Field } from '~/components/Formik'
import useDefineCompany from '~/modules/database/redux/hooks/useDefineCompany'
import { ROUTE } from '~/modules/database/routes/config'

import { defineCompanySchema } from './schema'

const QuickCreateCompany = ({
  open,
  onClose = () => {},
  onSuccess = () => {},
}) => {
  const { t } = useTranslation(['database'])

  const {
    data: { isLoading },
    actions,
  } = useDefineCompany()

  const initialValues = {
    code: '',
    name: '',
  }

  const onSubmit = (values) => {
    actions.createCompany(values, (res) => {
      onSuccess(res)
      onClose()
    })
  }

  const renderActionBar = () => {
    const { handleReset } = useFormikContext()

    return (
      <ActionBar
        onCancel={handleReset}
        mode={MODAL_MODE.CREATE}
        loading={isLoading}
        sx={{ p: 0, m: 0, border: 'none' }}
      />
    )
  }

  return (
    <Dialog
      open={open}
      title={t(`menu.${ROUTE.DEFINE_COMPANY.CREATE.TITLE}`)}
      renderFooter={renderActionBar}
      onCancel={onClose}
      formikProps={{
        initialValues: initialValues,
        validationSchema: defineCompanySchema(t),
        onSubmit: onSubmit,
        enableReinitialize: true,
      }}
    >
      <Stack spacing={4 / 3}>
        <Field.TextField
          label={t('defineCompany.code')}
          name="code"
          placeholder={t('defineCompany.code')}
          inputProps={{
            maxLength: TEXTFIELD_REQUIRED_LENGTH.CODE.MAX,
          }}
          allow={TEXTFIELD_ALLOW.ALPHANUMERIC}
          required
        />

        <Field.TextField
          label={t('defineCompany.name')}
          name="name"
          placeholder={t('defineCompany.name')}
          inputProps={{
            maxLength: TEXTFIELD_REQUIRED_LENGTH.COMMON.MAX,
          }}
          required
        />
      </Stack>
    </Dialog>
  )
}

export default QuickCreateCompany
