import React, { useEffect } from 'react'

import { List, ListItem, ListItemText, Paper } from '@mui/material'
import Grid from '@mui/material/Grid'
import { useTranslation } from 'react-i18next'
import { useHistory, useParams } from 'react-router-dom'

import { ACTIVE_STATUS_OPTIONS } from '~/common/constants'
import { useQueryState } from '~/common/hooks'
import ActionBar from '~/components/ActionBar'
import Button from '~/components/Button'
import LV from '~/components/LabelValue'
import Page from '~/components/Page'
import Status from '~/components/Status'
import TextField from '~/components/TextField'
import usePaymentMethod from '~/modules/database/redux/hooks/usePaymentMethod'
import { ROUTE } from '~/modules/database/routes/config'
import Activities from '~/modules/mmsx/partials/Activities'

const PaymentMethodDetail = () => {
  const history = useHistory()
  const { t } = useTranslation(['database'])
  const { withSearch } = useQueryState()

  const {
    data: { isLoading, paymentMethodDetail },
    actions,
  } = usePaymentMethod()
  const { id } = useParams()

  useEffect(() => {
    actions.getPaymentMethodDetailById(id)

    return () => {
      actions.resetPaymentMethodDetailState()
    }
  }, [id])

  const breadcrumbs = [
    {
      route: withSearch(ROUTE.PAYMENT_METHOD.LIST.PATH),
      title: ROUTE.PAYMENT_METHOD.LIST.TITLE,
    },
    {
      title: ROUTE.PAYMENT_METHOD.DETAIL.TITLE,
    },
  ]
  const backToList = () => {
    history.push(withSearch(ROUTE.PAYMENT_METHOD.LIST.PATH))
  }

  const getHistory = () => {
    const histories = paymentMethodDetail?.histories?.map((element) => ({
      createdAt: element?.createdAt,
      id: element?.id,
      username: element?.user?.username,
      content: () => {
        return (
          <List sx={{ padding: 0 }}>
            {element?.content?.map((value, index) => (
              <ListItem key={value?.valueField || index}>
                <ListItemText sx={{ margin: 0 }} primary={value} />
              </ListItem>
            ))}
          </List>
        )
      },
    }))
    return histories
  }

  return (
    <Page
      breadcrumbs={breadcrumbs}
      title={t('menu.paymentMethodDetail')}
      loading={isLoading}
      onBack={backToList}
      freeSolo
    >
      <Paper sx={{ p: 2 }}>
        <Grid container justifyContent="center">
          <Grid item xl={11} xs={12}>
            <Grid container rowSpacing={4 / 3} columnSpacing={{ xl: 8, xs: 4 }}>
              <Grid item lg={12} xs={12}>
                <LV
                  label={t('paymentMethod.status')}
                  value={
                    <Status
                      options={ACTIVE_STATUS_OPTIONS}
                      value={paymentMethodDetail?.status}
                    />
                  }
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <LV
                  label={t('paymentMethod.code')}
                  value={paymentMethodDetail?.code}
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <LV
                  label={t('paymentMethod.name')}
                  value={paymentMethodDetail?.name}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  name="description"
                  label={t('paymentMethod.description')}
                  multiline
                  rows={3}
                  value={paymentMethodDetail?.description}
                  readOnly
                  sx={{
                    'label.MuiFormLabel-root': {
                      color: (theme) => theme.palette.subText.main,
                    },
                  }}
                />
              </Grid>
            </Grid>
            <ActionBar
              onBack={backToList}
              elAfter={
                <Button
                  onClick={() =>
                    history.push(
                      withSearch(
                        ROUTE.PAYMENT_METHOD.EDIT.PATH.replace(':id', `${id}`),
                      ),
                    )
                  }
                >
                  {t('general:common.update')}
                </Button>
              }
            />
          </Grid>
        </Grid>
      </Paper>
      <Activities data={getHistory()} />
    </Page>
  )
}

export default PaymentMethodDetail
