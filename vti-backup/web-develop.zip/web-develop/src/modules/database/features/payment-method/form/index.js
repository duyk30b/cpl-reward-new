import React, { useEffect, useMemo } from 'react'

import Grid from '@mui/material/Grid'
import { Formik, Form } from 'formik'
import { useTranslation } from 'react-i18next'
import { useParams, useHistory, useRouteMatch } from 'react-router-dom'

import {
  MODAL_MODE,
  TEXTFIELD_ALLOW,
  TEXTFIELD_REQUIRED_LENGTH,
} from '~/common/constants'
import { useQueryState } from '~/common/hooks'
import ActionBar from '~/components/ActionBar'
import { Field } from '~/components/Formik'
import Page from '~/components/Page'
import usePaymentMethod from '~/modules/database/redux/hooks/usePaymentMethod'
import { ROUTE } from '~/modules/database/routes/config'

import { paymentMethodSchema } from './schema'

const PaymentMethodForm = () => {
  const { t } = useTranslation(['database'])
  const history = useHistory()
  const routeMatch = useRouteMatch()
  const { id } = useParams()
  const { withSearch } = useQueryState()

  const {
    data: { isLoading, paymentMethodDetail },
    actions,
  } = usePaymentMethod()

  const initialValues = useMemo(
    () => ({
      code: paymentMethodDetail?.code || '',
      name: paymentMethodDetail?.name || '',
      description: paymentMethodDetail?.description || '',
    }),
    [paymentMethodDetail],
  )

  const MODE_MAP = {
    [ROUTE.PAYMENT_METHOD.CREATE.PATH]: MODAL_MODE.CREATE,
    [ROUTE.PAYMENT_METHOD.EDIT.PATH]: MODAL_MODE.UPDATE,
  }

  const mode = MODE_MAP[routeMatch.path]
  const isUpdate = mode === MODAL_MODE.UPDATE

  const getBreadcrumb = () => {
    const breadcrumb = [
      {
        route: withSearch(ROUTE.PAYMENT_METHOD.LIST.PATH),
        title: ROUTE.PAYMENT_METHOD.LIST.TITLE,
      },
    ]
    switch (mode) {
      case MODAL_MODE.CREATE:
        breadcrumb.push({
          route: ROUTE.PAYMENT_METHOD.CREATE.PATH,
          title: ROUTE.PAYMENT_METHOD.CREATE.TITLE,
        })
        break
      case MODAL_MODE.UPDATE:
        breadcrumb.push({
          route: ROUTE.PAYMENT_METHOD.EDIT.PATH,
          title: ROUTE.PAYMENT_METHOD.EDIT.TITLE,
        })
        break
      default:
        break
    }
    return breadcrumb
  }

  const getTitle = () => {
    switch (mode) {
      case MODAL_MODE.CREATE:
        return ROUTE.PAYMENT_METHOD.CREATE.TITLE
      case MODAL_MODE.UPDATE:
        return ROUTE.PAYMENT_METHOD.EDIT.TITLE
      default:
        break
    }
  }

  const renderActionBar = (handleReset) => {
    switch (mode) {
      case MODAL_MODE.CREATE:
        return (
          <ActionBar
            onBack={backToList}
            onCancel={handleReset}
            mode={MODAL_MODE.CREATE}
          />
        )
      case MODAL_MODE.UPDATE:
        return (
          <ActionBar
            onBack={backToList}
            onCancel={handleReset}
            mode={MODAL_MODE.UPDATE}
          />
        )
      default:
    }
  }

  const backToList = () => {
    history.push(withSearch(ROUTE.PAYMENT_METHOD.LIST.PATH))
  }

  useEffect(() => {
    if (mode === MODAL_MODE.UPDATE) {
      actions.getPaymentMethodDetailById(id)
    }

    return () => {
      if (isUpdate) actions.resetPaymentMethodDetailState()
    }
  }, [id])

  const onSubmit = (values) => {
    if (mode === MODAL_MODE.CREATE) {
      actions.createPaymentMethod(values, () =>
        history.push(ROUTE.PAYMENT_METHOD.LIST.PATH),
      )
    } else if (mode === MODAL_MODE.UPDATE) {
      const paramUpdate = { ...values, id }
      actions.updatePaymentMethod(paramUpdate, () => backToList())
    }
  }

  return (
    <Page
      breadcrumbs={getBreadcrumb()}
      title={t(`menu.${getTitle()}`)}
      loading={isLoading}
      onBack={backToList}
    >
      <Grid container justifyContent="center">
        <Grid item xl={11} xs={12}>
          <Formik
            initialValues={initialValues}
            validationSchema={paymentMethodSchema(t)}
            onSubmit={onSubmit}
            enableReinitialize
          >
            {({ handleReset }) => (
              <Form>
                <Grid
                  container
                  rowSpacing={4 / 3}
                  columnSpacing={{ xl: 8, xs: 4 }}
                >
                  <Grid item lg={6} xs={12}>
                    <Field.TextField
                      name="code"
                      label={t('paymentMethod.code')}
                      placeholder={t('paymentMethod.code')}
                      disabled={isUpdate}
                      inputProps={{
                        maxLength: TEXTFIELD_REQUIRED_LENGTH.CODE_50.MAX,
                      }}
                      allow={TEXTFIELD_ALLOW.ALPHANUMERIC}
                      required
                    />
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Field.TextField
                      name="name"
                      label={t('paymentMethod.name')}
                      placeholder={t('paymentMethod.name')}
                      inputProps={{
                        maxLength: TEXTFIELD_REQUIRED_LENGTH.CODE_50.MAX,
                      }}
                      required
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Field.TextField
                      name="description"
                      label={t('paymentMethod.description')}
                      placeholder={t('paymentMethod.description')}
                      inputProps={{
                        maxLength: TEXTFIELD_REQUIRED_LENGTH.COMMON.MAX,
                      }}
                      multiline
                      rows={3}
                    />
                  </Grid>
                </Grid>
                {renderActionBar(handleReset)}
              </Form>
            )}
          </Formik>
        </Grid>
      </Grid>
    </Page>
  )
}
export default PaymentMethodForm
