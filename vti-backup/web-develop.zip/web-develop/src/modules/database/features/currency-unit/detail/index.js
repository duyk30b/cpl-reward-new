import React, { useEffect } from 'react'

import { List, ListItem, ListItemText, Paper } from '@mui/material'
import Grid from '@mui/material/Grid'
import { useTranslation } from 'react-i18next'
import { useHistory, useParams } from 'react-router-dom'

import { ACTIVE_STATUS_OPTIONS } from '~/common/constants'
import { useQueryState } from '~/common/hooks'
import ActionBar from '~/components/ActionBar'
import LV from '~/components/LabelValue'
import Page from '~/components/Page'
import Status from '~/components/Status'
import TextField from '~/components/TextField'
import useCurrencyUnit from '~/modules/database/redux/hooks/useCurrencyUnit'
import { ROUTE } from '~/modules/database/routes/config'
import Activities from '~/modules/mmsx/partials/Activities'

const CurrencyUnitDetail = () => {
  const history = useHistory()
  const { t } = useTranslation(['database'])
  const { withSearch } = useQueryState()

  const {
    data: { isLoading, currencyUnitDetails },
    actions,
  } = useCurrencyUnit()
  const { id } = useParams()

  useEffect(() => {
    actions.getCurrencyUnitDetailById(id)

    return () => {
      actions.resetCurrencyUnitDetailState()
    }
  }, [id])

  const breadcrumbs = [
    {
      route: withSearch(ROUTE.CURRENCY_UNIT.LIST.PATH),
      title: ROUTE.CURRENCY_UNIT.LIST.TITLE,
    },
    {
      title: ROUTE.CURRENCY_UNIT.DETAIL.TITLE,
    },
  ]
  const backToList = () => {
    history.push(withSearch(ROUTE.CURRENCY_UNIT.LIST.PATH))
  }

  const getHistory = () => {
    const histories = currencyUnitDetails?.histories?.map((element) => ({
      createdAt: element?.createdAt,
      id: element?.id,
      username: element?.user?.username,
      content: () => {
        return (
          <List sx={{ padding: 0 }}>
            {element?.content?.map((value, index) => (
              <ListItem key={value?.valueField || index}>
                <ListItemText sx={{ margin: 0 }} primary={value} />
              </ListItem>
            ))}
          </List>
        )
      },
    }))
    return histories
  }

  return (
    <Page
      breadcrumbs={breadcrumbs}
      title={t('menu.currencyUnitDetail')}
      loading={isLoading}
      onBack={backToList}
      freeSolo
    >
      <Paper sx={{ p: 2 }}>
        <Grid container justifyContent="center">
          <Grid item xl={11} xs={12}>
            <Grid container rowSpacing={4 / 3} columnSpacing={{ xl: 8, xs: 4 }}>
              <Grid item lg={12} xs={12}>
                <LV
                  label={t('currencyUnit.status')}
                  value={
                    <Status
                      options={ACTIVE_STATUS_OPTIONS}
                      value={currencyUnitDetails?.status}
                    />
                  }
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <LV
                  label={t('currencyUnit.code')}
                  value={currencyUnitDetails?.code}
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <LV
                  label={t('currencyUnit.name')}
                  value={currencyUnitDetails?.name}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  name="description"
                  label={t('currencyUnit.description')}
                  multiline
                  rows={3}
                  value={currencyUnitDetails?.description}
                  readOnly
                  sx={{
                    'label.MuiFormLabel-root': {
                      color: (theme) => theme.palette.subText.main,
                    },
                  }}
                />
              </Grid>
            </Grid>
            <ActionBar onBack={backToList} />
          </Grid>
        </Grid>
      </Paper>
      <Activities data={getHistory()} />
    </Page>
  )
}

export default CurrencyUnitDetail
