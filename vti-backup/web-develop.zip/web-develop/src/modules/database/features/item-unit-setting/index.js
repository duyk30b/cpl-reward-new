import React, { useEffect, useState, useMemo } from 'react'

import IconButton from '@mui/material/IconButton'
import { useTranslation } from 'react-i18next'
import { useHistory } from 'react-router-dom'

import { BULK_ACTION } from '~/common/constants'
import { API_URL } from '~/common/constants/apiUrl'
import { useQueryState } from '~/common/hooks'
import Button from '~/components/Button'
import DataTable from '~/components/DataTable'
import Dialog from '~/components/Dialog'
import Icon from '~/components/Icon'
import ImportExport from '~/components/ImportExport'
import LV from '~/components/LabelValue'
import Page from '~/components/Page'
import useItemUnit from '~/modules/database/redux/hooks/useItemUnit'
import { ROUTE } from '~/modules/database/routes/config'
import {
  convertUtcDateTimeToLocalTz,
  convertFilterParams,
  convertSortParams,
} from '~/utils'

import { TYPE_ITEM_EXPORT } from '../../constants'
import {
  exportItemUnitSettingApi,
  getItemUnitSettingTemplateApi,
  importItemUnitSettingApi,
} from '../../redux/sagas/item-unit-setting/import-export-item-unit'
import FilterForm from './filter-form'

const breadcrumbs = [
  // {
  //   title: 'database',
  // },
  {
    route: ROUTE.ITEM_UNIT.LIST.PATH,
    title: ROUTE.ITEM_UNIT.LIST.TITLE,
  },
]
function ItemUnitSetting() {
  const { t } = useTranslation(['database'])
  const history = useHistory()
  const {
    data: { isLoading, itemUnitList, total },
    actions,
  } = useItemUnit()

  const DEFAULT_FILTERS = {
    code: '',
    name: '',
    createdAt: '',
  }

  const [deleteModal, setDeleteModal] = useState(false)
  const [tempItem, setTempItem] = useState()
  const [columnsSettings, setColumnsSettings] = useState([])
  const [selectedRows, setSelectedRows] = useState([])

  const {
    page,
    pageSize,
    sort,
    filters,
    keyword,
    setPage,
    setPageSize,
    setSort,
    setFilters,
    setKeyword,
    withSearch,
    selectedRowsDeps,
  } = useQueryState({
    filters: DEFAULT_FILTERS,
  })

  const columns = useMemo(() => [
    // {
    //   field: 'id',
    //   headerName: '#',
    //   width: 80,
    //   sortable: false,
    //   visible: 'always',
    // },
    {
      field: 'code',
      headerName: t('itemUnitDefine.unitCode'),
      width: 100,
      sortable: true,
      visible: 'always',
    },
    {
      field: 'name',
      headerName: t('itemUnitDefine.unitName'),
      width: 200,
      sortable: true,
      visible: 'always',
    },
    {
      field: 'description',
      headerName: t('itemUnitDefine.unitNote'),
      width: 350,
      sortable: false,
    },
    {
      field: 'createdAt',
      headerName: t('itemUnitDefine.createDate'),
      width: 150,
      sortable: true,
      filterFormat: 'date',
      renderCell: (params) => {
        const createdAt = params.row.createdAt
        return convertUtcDateTimeToLocalTz(createdAt)
      },
    },
    {
      field: 'updatedAt',
      headerName: t('itemUnitDefine.updateDate'),
      width: 150,
      filterFormat: 'date',
      sortable: true,
      renderCell: (params) => {
        const updateAt = params.row.updatedAt
        return convertUtcDateTimeToLocalTz(updateAt)
      },
    },
    {
      field: 'action',
      headerName: t('itemUnitDefine.action'),
      width: 130,
      sortable: false,
      align: 'center',
      visible: 'always',

      sticky: 'right',
      renderCell: (params) => {
        const { row } = params
        const { id } = row
        return (
          <>
            <IconButton
              onClick={() =>
                history.push(
                  withSearch(
                    ROUTE.ITEM_UNIT.DETAIL.PATH.replace(':id', `${id}`),
                  ),
                )
              }
            >
              <Icon name="show" />
            </IconButton>
            <IconButton
              onClick={() =>
                history.push(
                  withSearch(ROUTE.ITEM_UNIT.EDIT.PATH.replace(':id', `${id}`)),
                )
              }
            >
              <Icon name="edit" />
            </IconButton>
            <IconButton onClick={() => handleDeleteOpenModal(row)}>
              <Icon name="delete" />
            </IconButton>
          </>
        )
      },
    },
  ])

  const refreshData = () => {
    const params = {
      keyword: keyword.trim(),
      page: page,
      limit: pageSize,
      filter: convertFilterParams(filters, columns),
      sort: convertSortParams(sort),
    }
    actions.searchItemUnits(params)
  }

  useEffect(() => {
    refreshData()
  }, [page, pageSize, sort, filters, keyword])

  useEffect(() => {
    setSelectedRows([])
  }, [selectedRowsDeps])

  const handleDeleteOpenModal = (tempItem) => {
    setTempItem(tempItem)
    setDeleteModal(true)
  }

  const onSubmitDelete = () => {
    actions.deleteItemUnit(tempItem?.id)
    setDeleteModal(false)
  }

  const renderHeaderRight = () => {
    return (
      <>
        <ImportExport
          name={t('itemUnitDefine.export')}
          onImport={(params) => {
            importItemUnitSettingApi(params)
          }}
          onExport={() =>
            exportItemUnitSettingApi({
              columnSettings: JSON.stringify(columnsSettings),
              queryIds: JSON.stringify(
                selectedRows?.map((x) => ({ id: x?.id })),
              ),
              keyword: keyword.trim(),
              filter: convertFilterParams(filters, [
                { field: 'createdAt', filterFormat: 'date' },
              ]),
              sort: convertSortParams(sort),
              type: TYPE_ITEM_EXPORT.ITEM_UNIT,
            })
          }
          onDownloadTemplate={getItemUnitSettingTemplateApi}
          onRefresh={refreshData}
        />
        <Button
          onClick={() => history.push(withSearch(ROUTE.ITEM_UNIT.CREATE.PATH))}
          icon="add"
          sx={{ ml: 4 / 3 }}
        >
          {t('general:common.create')}
        </Button>
      </>
    )
  }

  return (
    <>
      <Page
        breadcrumbs={breadcrumbs}
        title={t('menu.itemUnitDefine')}
        onSearch={setKeyword}
        keyword={keyword}
        placeholder={t('itemUnitDefine.searchPlaceholder')}
        renderHeaderRight={renderHeaderRight}
        loading={isLoading}
      >
        <DataTable
          title={t('itemUnitDefine.title')}
          rows={itemUnitList}
          pageSize={pageSize}
          page={page}
          columns={columns}
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
          onSortChange={setSort}
          onSettingChange={setColumnsSettings}
          onSelectionChange={setSelectedRows}
          selected={selectedRows}
          total={total}
          filters={{
            form: <FilterForm />,
            values: filters,
            defaultValue: DEFAULT_FILTERS,
            onApply: setFilters,
          }}
          sort={sort}
          bulkActions={{
            actions: [BULK_ACTION.DELETE],
            apiUrl: API_URL.ITEM_UNIT,
            onSuccess: () => {
              if (page === 1) {
                refreshData()
              } else {
                setPage(1)
              }
              setSelectedRows([])
            },
          }}
        />
        <Dialog
          open={deleteModal}
          title={t('itemUnitDefine.deleteTitle')}
          onCancel={() => setDeleteModal(false)}
          cancelLabel={t('general:common.no')}
          onSubmit={onSubmitDelete}
          submitLabel={t('general:common.yes')}
          submitProps={{
            color: 'error',
          }}
          noBorderBottom
        >
          {t('itemUnitDefine.confirmDelete')}
          <LV
            label={t('itemUnitDefine.unitCode')}
            value={tempItem?.code}
            sx={{ mt: 4 / 3 }}
          />
          <LV
            label={t('itemUnitDefine.unitName')}
            value={tempItem?.name}
            sx={{ mt: 4 / 3 }}
          />
        </Dialog>
      </Page>
    </>
  )
}

export default ItemUnitSetting
