import { Stack } from '@mui/material'
import { useFormikContext } from 'formik'
import { useTranslation } from 'react-i18next'

import { MODAL_MODE, TEXTFIELD_REQUIRED_LENGTH } from '~/common/constants'
import ActionBar from '~/components/ActionBar'
import Dialog from '~/components/Dialog'
import { Field } from '~/components/Formik'
import useItemUnit from '~/modules/database/redux/hooks/useItemUnit'
import { ROUTE } from '~/modules/database/routes/config'

import { itemUnitSchema } from './schema'

function QuickCreateUnit({ open, onClose = () => {}, onSuccess = () => {} }) {
  const { t } = useTranslation(['database'])
  const {
    data: { isLoading },
    actions,
  } = useItemUnit()

  const initialValues = {
    name: '',
  }

  const onSubmit = (values) => {
    actions.createItemUnit(values, (res) => {
      onSuccess(res)
      onClose()
    })
  }

  const renderActionBar = () => {
    const { handleReset } = useFormikContext()

    return (
      <ActionBar
        onCancel={handleReset}
        mode={MODAL_MODE.CREATE}
        loading={isLoading}
        sx={{ p: 0, m: 0, border: 'none' }}
      />
    )
  }

  return (
    <Dialog
      open={open}
      title={t(`menu.${ROUTE.ITEM_UNIT.CREATE.TITLE}`)}
      renderFooter={renderActionBar}
      onCancel={onClose}
      formikProps={{
        initialValues: initialValues,
        validationSchema: itemUnitSchema(t),
        onSubmit: onSubmit,
        enableReinitialize: true,
      }}
    >
      <Stack spacing={4 / 3}>
        <Field.TextField
          name="name"
          label={t('itemUnitDefine.name')}
          placeholder={t('itemUnitDefine.name')}
          inputProps={{
            maxLength: TEXTFIELD_REQUIRED_LENGTH.NAME.MAX,
          }}
          required
        />
      </Stack>
      <Stack spacing={4 / 3} mt={1}>
        <Field.TextField
          name="code"
          label={t('itemUnitDefine.code')}
          placeholder={t('itemUnitDefine.code')}
          inputProps={{
            maxLength: TEXTFIELD_REQUIRED_LENGTH.CODE.MAX,
            minLength: TEXTFIELD_REQUIRED_LENGTH.CODE.MIN,
          }}
          required
        />
      </Stack>
    </Dialog>
  )
}

export default QuickCreateUnit
