import { useTranslation } from 'react-i18next'

import Dialog from '~/components/Dialog'
import LV from '~/components/LabelValue'

const DeleteDialog = ({ modal, setModal, onSubmitDelete }) => {
  const { t } = useTranslation(['database'])
  return (
    <Dialog
      open={modal?.isOpenDeleteModal}
      title={t('vendorCriteria.deleteTitle')}
      onCancel={() =>
        setModal({ isOpenUpdateStatusModal: false, tempItem: null })
      }
      cancelLabel={t('general:common.no')}
      onSubmit={onSubmitDelete}
      submitLabel={t('general:common.yes')}
      submitProps={{
        color: 'error',
      }}
      noBorderBottom
    >
      {t('vendorCriteria.confirmDetele')}
      <LV
        label={t('vendorCriteria.code')}
        value={modal?.tempItem?.code}
        sx={{ mt: 4 / 3 }}
      />
      <LV
        label={t('vendorCriteria.name')}
        value={modal?.tempItem?.name}
        sx={{ mt: 4 / 3 }}
      />
    </Dialog>
  )
}

export default DeleteDialog
