import React, { useEffect, useState } from 'react'

import { List, ListItem, ListItemText, Paper } from '@mui/material'
import Grid from '@mui/material/Grid'
import { useTranslation } from 'react-i18next'
import { useHistory, useParams } from 'react-router-dom'

import { ACTIVE_STATUS, ACTIVE_STATUS_OPTIONS } from '~/common/constants'
import { useQueryState } from '~/common/hooks'
import ActionBar from '~/components/ActionBar'
import Icon from '~/components/Icon'
import IconButton from '~/components/IconButton'
import LV from '~/components/LabelValue'
import Page from '~/components/Page'
import Status from '~/components/Status'
import TextField from '~/components/TextField'
import useVendorCriteria from '~/modules/database/redux/hooks/useVendorCriteria'
import { ROUTE } from '~/modules/database/routes/config'
import Activities from '~/modules/mmsx/partials/Activities'

import ChangeStatusDialog from '../list/dialog/change-status-dialog'
import DeleteDialog from '../list/dialog/delete-dialog'

const VendorCriteriaDetail = () => {
  const history = useHistory()
  const { t } = useTranslation(['database'])
  const { withSearch } = useQueryState()
  const [modal, setModal] = useState({
    tempItem: null,
    isOpenUpdateStatusModal: false,
    isOpenDeleteModal: false,
  })

  const {
    data: { isLoading, vendorCriteriaDetail },
    actions,
  } = useVendorCriteria()
  const { id } = useParams()

  useEffect(() => {
    actions.getVendorCriteriaDetailById(id)

    return () => {
      actions.resetVendorCriteriaDetailState()
    }
  }, [id])

  const breadcrumbs = [
    {
      route: withSearch(ROUTE.VENDOR_CRITERIA.LIST.PATH),
      title: ROUTE.VENDOR_CRITERIA.LIST.TITLE,
    },
    {
      title: ROUTE.VENDOR_CRITERIA.DETAIL.TITLE,
    },
  ]

  const refreshData = () => {
    actions.getVendorCriteriaDetailById(id)
  }

  const handleActiveOpenModal = (tempItem) => {
    setModal({ tempItem, isOpenUpdateStatusModal: true })
  }

  const handleDeleteOpenModal = (tempItem) => {
    setModal({ tempItem, isOpenDeleteModal: true })
  }

  const onSubmitUpdateStatus = () => {
    if (modal.tempItem?.status === ACTIVE_STATUS.ACTIVE) {
      actions.inactiveVendorCriteria(modal.tempItem?.id, () => {
        refreshData()
      })
    } else if (modal.tempItem?.status === ACTIVE_STATUS.INACTIVE) {
      actions.activeVendorCriteria(modal.tempItem?.id, () => {
        refreshData()
      })
    }
    setModal({ isOpenUpdateStatusModal: false, tempItem: null })
  }

  const onSubmitDelete = () => {
    actions.deleteVendorCriteriaById(modal.tempItem?.id, () => {
      refreshData()
      backToList()
    })
    setModal({ isOpenDeleteModal: false, tempItem: null })
  }

  const backToList = () => {
    history.push(withSearch(ROUTE.VENDOR_CRITERIA.LIST.PATH))
  }

  const renderHeaderRight = () => {
    return (
      <>
        <IconButton
          type="squareIcon"
          title={t('general:common.update')}
          onClick={() =>
            history.push(
              withSearch(
                ROUTE.VENDOR_CRITERIA.EDIT.PATH.replace(':id', `${id}`),
              ),
            )
          }
        >
          <Icon name={'edit'} />
        </IconButton>
        <IconButton
          type="squareIcon"
          title={
            vendorCriteriaDetail?.status === ACTIVE_STATUS.ACTIVE
              ? t('general:common.active')
              : t('general:common.inActive')
          }
          onClick={() => handleActiveOpenModal(vendorCriteriaDetail)}
        >
          <Icon
            name={
              vendorCriteriaDetail?.status === ACTIVE_STATUS.ACTIVE
                ? 'locked'
                : 'unlock'
            }
          />
        </IconButton>
        <IconButton
          type="squareIcon"
          title={t('general:common.delete')}
          onClick={() => handleDeleteOpenModal(vendorCriteriaDetail)}
        >
          <Icon name={'delete'} />
        </IconButton>
      </>
    )
  }

  const getHistory = () => {
    const histories = vendorCriteriaDetail?.histories?.map((element) => ({
      createdAt: element?.createdAt,
      id: element?.id,
      username: element?.user?.username,
      content: () => {
        return (
          <List sx={{ padding: 0 }}>
            {element?.content?.map((value, index) => (
              <ListItem key={value?.valueField || index}>
                <ListItemText sx={{ margin: 0 }} primary={value} />
              </ListItem>
            ))}
          </List>
        )
      },
    }))
    return histories
  }

  return (
    <Page
      breadcrumbs={breadcrumbs}
      title={t('menu.vendorCriteriaDetail')}
      loading={isLoading}
      renderHeaderRight={renderHeaderRight}
      freeSolo
    >
      <Paper sx={{ p: 2 }}>
        <Grid container justifyContent="center">
          <Grid item xl={11} xs={12}>
            <Grid container rowSpacing={4 / 3} columnSpacing={{ xl: 8, xs: 4 }}>
              <Grid item lg={12} xs={12}>
                <LV
                  label={t('vendorCriteria.status')}
                  value={
                    <Status
                      options={ACTIVE_STATUS_OPTIONS}
                      value={vendorCriteriaDetail?.status}
                    />
                  }
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <LV
                  label={t('vendorCriteria.name')}
                  value={vendorCriteriaDetail?.name}
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <LV
                  label={t('vendorCriteria.code')}
                  value={vendorCriteriaDetail?.code}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  name="description"
                  label={t('vendorCriteria.description')}
                  multiline
                  rows={3}
                  value={vendorCriteriaDetail?.description}
                  readOnly
                  sx={{
                    'label.MuiFormLabel-root': {
                      color: (theme) => theme.palette.subText.main,
                    },
                  }}
                />
              </Grid>
            </Grid>
            <ActionBar onBack={backToList} />
          </Grid>
        </Grid>
        <ChangeStatusDialog
          modal={modal}
          setModal={setModal}
          onSubmitUpdateStatus={onSubmitUpdateStatus}
        />
        <DeleteDialog
          modal={modal}
          setModal={setModal}
          onSubmitDelete={onSubmitDelete}
        />
      </Paper>

      <Activities data={getHistory()} />
    </Page>
  )
}

export default VendorCriteriaDetail
