import { useTranslation } from 'react-i18next'

import { ACTIVE_STATUS, ACTIVE_STATUS_OPTIONS } from '~/common/constants'
import Dialog from '~/components/Dialog'
import LV from '~/components/LabelValue'
import StatusSwitcher from '~/components/StatusSwitcher'

const ChangeStatusDialog = ({ modal, setModal, onSubmitUpdateStatus }) => {
  const { t } = useTranslation(['database'])
  return (
    <Dialog
      open={modal.isOpenUpdateStatusModal}
      title={t('general.updateStatus')}
      onCancel={() =>
        setModal({ isOpenUpdateStatusModal: false, tempItem: null })
      }
      cancelLabel={t('general:common.no')}
      onSubmit={onSubmitUpdateStatus}
      submitLabel={t('general:common.yes')}
      {...(modal?.tempItem?.status === ACTIVE_STATUS.ACTIVE
        ? {
            submitProps: {
              color: 'error',
            },
          }
        : {})}
      noBorderBottom
    >
      {t('general.confirmMessage')}
      <LV
        label={t('vendorCriteria.code')}
        value={modal?.tempItem?.code}
        sx={{ mt: 1 }}
      />
      <LV
        label={t('vendorCriteria.name')}
        value={modal?.tempItem?.name}
        sx={{ mt: 1 }}
      />
      <LV
        label={t('general.status')}
        value={
          <StatusSwitcher
            options={ACTIVE_STATUS_OPTIONS}
            value={modal?.tempItem?.status}
          />
        }
        sx={{ mt: 1 }}
      />
    </Dialog>
  )
}

export default ChangeStatusDialog
