import React from 'react'

import { Box, Grid } from '@mui/material'
import { Form, Formik } from 'formik'
import { useTranslation } from 'react-i18next'

import { ACTIVE_STATUS_OPTIONS } from '~/common/constants'
import Button from '~/components/Button'
import { Field } from '~/components/Formik'

const QuickFilter = ({ setQuickFilters, defaultFilter }) => {
  const { t } = useTranslation(['database'])
  const onSubmit = (values) => {
    setQuickFilters(values)
  }

  return (
    <Formik
      initialValues={defaultFilter}
      onSubmit={onSubmit}
      enableReinitialize
    >
      {({ resetForm }) => (
        <Form>
          <Grid container justifyContent="center" sx={{ mb: 4 }}>
            <Grid item xl={11} xs={12}>
              <Grid
                container
                rowSpacing={4 / 3}
                columnSpacing={{ xl: 8, xs: 4 }}
              >
                <Grid item lg={6} xs={12}>
                  <Field.Autocomplete
                    name="status"
                    label={t('vendorCriteria.status')}
                    placeholder={t('vendorCriteria.status')}
                    options={ACTIVE_STATUS_OPTIONS}
                    getOptionLabel={(opt) => (opt?.text ? t(opt?.text) : '')}
                    getOptionValue={(opt) => opt?.id?.toString()}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <Button
                      color="grayF4"
                      sx={{ mr: 1 }}
                      onClick={() => {
                        resetForm()
                        setQuickFilters(defaultFilter)
                      }}
                    >
                      {t('general:common.cancel')}
                    </Button>
                    <Button type="submit">{t('general:common.search')}</Button>
                  </Box>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  )
}

export default QuickFilter
