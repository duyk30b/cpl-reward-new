import React, { useState, useEffect, useMemo } from 'react'

import IconButton from '@mui/material/IconButton'
import { useTranslation } from 'react-i18next'
import { useHistory } from 'react-router-dom'

import {
  ACTIVE_STATUS,
  ACTIVE_STATUS_OPTIONS,
  BULK_ACTION,
} from '~/common/constants'
import { API_URL } from '~/common/constants/apiUrl'
import { useQueryState } from '~/common/hooks'
import Button from '~/components/Button'
import DataTable from '~/components/DataTable'
import Icon from '~/components/Icon'
import Page from '~/components/Page'
import Status from '~/components/Status'
import useVendorCriteria from '~/modules/database/redux/hooks/useVendorCriteria'
import { ROUTE } from '~/modules/database/routes/config'
import { convertFilterParams, convertSortParams } from '~/utils'

import ChangeStatusDialog from './dialog/change-status-dialog'
import DeleteDialog from './dialog/delete-dialog'
import QuickFilter from './quick-filter'

const breadcrumbs = [
  {
    route: ROUTE.VENDOR_CRITERIA.LIST.PATH,
    title: ROUTE.VENDOR_CRITERIA.LIST.TITLE,
  },
]
const VendorCriteria = () => {
  const { t } = useTranslation(['database'])
  const history = useHistory()
  const [modal, setModal] = useState({
    tempItem: null,
    isOpenUpdateStatusModal: false,
    isOpenDeleteModal: false,
  })
  const [selectedRows, setSelectedRows] = useState([])
  const {
    data: { isLoading, vendorCriteriaList, total },
    actions,
  } = useVendorCriteria()

  const DEFAULT_QUICK_FILTERS = {
    status: null,
  }

  const {
    page,
    pageSize,
    sort,
    keyword,
    quickFilters,
    setPage,
    setPageSize,
    setSort,
    setKeyword,
    withSearch,
    selectedRowsDeps,
    setQuickFilters,
  } = useQueryState({
    quickFilters: DEFAULT_QUICK_FILTERS,
  })

  const columns = useMemo(() => [
    {
      field: 'code',
      headerName: t('vendorCriteria.code'),
      width: 150,
      visible: 'always',
      sortable: true,
      renderCell: (params) => {
        const { id } = params?.row
        return (
          <Button
            variant="text"
            bold={false}
            size="small"
            onClick={() =>
              history.push(
                withSearch(
                  ROUTE.VENDOR_CRITERIA.DETAIL.PATH.replace(':id', `${id}`),
                ),
              )
            }
          >
            {params?.row?.code}
          </Button>
        )
      },
    },
    {
      field: 'name',
      headerName: t('vendorCriteria.name'),
      width: 200,
      visible: 'always',
      sortable: true,
      renderCell: (params) => {
        const { id } = params?.row
        return (
          <Button
            variant="text"
            bold={false}
            size="small"
            onClick={() =>
              history.push(
                withSearch(
                  ROUTE.VENDOR_CRITERIA.DETAIL.PATH.replace(':id', `${id}`),
                ),
              )
            }
          >
            {params?.row?.name}
          </Button>
        )
      },
    },
    {
      field: 'description',
      headerName: t('vendorCriteria.description'),
      width: 200,
    },
    {
      field: 'status',
      headerName: t('vendorCriteria.status'),
      width: 150,
      visible: 'always',
      renderCell: (params) => {
        const status = Number(params?.row?.status)
        return (
          <Status
            options={ACTIVE_STATUS_OPTIONS}
            value={status}
            variant="text"
          />
        )
      },
    },
    {
      field: 'action',
      headerName: t('vendorCriteria.action'),
      width: 130,
      align: 'center',
      visible: 'always',
      sticky: 'right',
      renderCell: (params) => {
        const { id, status } = params?.row
        return (
          <>
            <IconButton
              onClick={() =>
                history.push(
                  withSearch(
                    ROUTE.VENDOR_CRITERIA.EDIT.PATH.replace(':id', `${id}`),
                  ),
                )
              }
            >
              <Icon name="edit" />
            </IconButton>
            <IconButton onClick={() => handleActiveOpenModal(params?.row)}>
              <Icon
                name={status === ACTIVE_STATUS.ACTIVE ? 'locked' : 'unlock'}
              />
            </IconButton>
            <IconButton onClick={() => handleDeleteOpenModal(params?.row)}>
              <Icon name="delete" />
            </IconButton>
          </>
        )
      },
    },
  ])

  const refreshData = () => {
    const params = {
      keyword: keyword.trim(),
      page: page,
      limit: pageSize,
      filter: convertFilterParams(quickFilters, columns),
      sort: convertSortParams(sort),
    }
    actions.searchVendorCriteria(params)
  }

  useEffect(() => {
    refreshData()
  }, [page, pageSize, sort, quickFilters, keyword])

  useEffect(() => {
    setSelectedRows([])
  }, [selectedRowsDeps])

  const handleActiveOpenModal = (tempItem) => {
    setModal({ tempItem, isOpenUpdateStatusModal: true })
  }

  const handleDeleteOpenModal = (tempItem) => {
    setModal({ tempItem, isOpenDeleteModal: true })
  }

  const onSubmitUpdateStatus = () => {
    if (modal.tempItem?.status === ACTIVE_STATUS.ACTIVE) {
      actions.inactiveVendorCriteria(modal.tempItem?.id, () => {
        refreshData()
      })
    } else if (modal.tempItem?.status === ACTIVE_STATUS.INACTIVE) {
      actions.activeVendorCriteria(modal.tempItem?.id, () => {
        refreshData()
      })
    }
    setModal({ isOpenUpdateStatusModal: false, tempItem: null })
  }

  const onSubmitDelete = () => {
    actions.deleteVendorCriteriaById(modal.tempItem?.id, () => {
      refreshData()
    })
    setModal({ isOpenDeleteModal: false, tempItem: null })
  }

  const renderHeaderRight = () => {
    return (
      <Button
        onClick={() =>
          history.push(withSearch(ROUTE.VENDOR_CRITERIA.CREATE.PATH))
        }
        icon="add"
        sx={{ ml: 4 / 3 }}
      >
        {t('general:common.create')}
      </Button>
    )
  }

  return (
    <Page
      breadcrumbs={breadcrumbs}
      title={t('menu.vendorCriteria')}
      onSearch={setKeyword}
      keyword={keyword}
      placeholder={t('vendorCriteria.searchPlaceholder')}
      renderHeaderRight={renderHeaderRight}
      loading={isLoading}
    >
      <QuickFilter
        setQuickFilters={setQuickFilters}
        defaultFilter={DEFAULT_QUICK_FILTERS}
      />
      <DataTable
        title={t('vendorCriteria.titleTable')}
        rows={vendorCriteriaList}
        pageSize={pageSize}
        page={page}
        columns={columns}
        onPageChange={setPage}
        onPageSizeChange={setPageSize}
        onSortChange={setSort}
        onSelectionChange={setSelectedRows}
        selected={selectedRows}
        total={total}
        sort={sort}
        bulkActions={{
          actions: [BULK_ACTION.DELETE],
          apiUrl: API_URL.VENDOR_CRITERIA,
          onSuccess: () => {
            if (page === 1) {
              refreshData()
            } else {
              setPage(1)
            }
            setSelectedRows([])
          },
        }}
      />
      <ChangeStatusDialog
        modal={modal}
        setModal={setModal}
        onSubmitUpdateStatus={onSubmitUpdateStatus}
      />
      <DeleteDialog
        modal={modal}
        setModal={setModal}
        onSubmitDelete={onSubmitDelete}
      />
    </Page>
  )
}

export default VendorCriteria
