export const SEARCH_VENDOR_CRITERIA_START =
  'DATABASE_SEARCH_VENDOR_CRITERIA_START'
export const SEARCH_VENDOR_CRITERIA_SUCCESS =
  'DATABASE_SEARCH_VENDOR_CRITERIA_SUCCESS'
export const SEARCH_VENDOR_CRITERIA_FAILED =
  'DATABASE_SEARCH_VENDOR_CRITERIA_FAILED'

export const CREATE_VENDOR_CRITERIA_START =
  'DATABASE_CREATE_VENDOR_CRITERIA_START'
export const CREATE_VENDOR_CRITERIA_SUCCESS =
  'DATABASE_CREATE_VENDOR_CRITERIA_SUCCESS'
export const CREATE_VENDOR_CRITERIA_FAILED =
  'DATABASE_CREATE_VENDOR_CRITERIA_FAILED'

export const UPDATE_VENDOR_CRITERIA_START =
  'DATABASE_UPDATE_VENDOR_CRITERIA_START'
export const UPDATE_VENDOR_CRITERIA_SUCCESS =
  'DATABASE_UPDATE_VENDOR_CRITERIA_SUCCESS'
export const UPDATE_VENDOR_CRITERIA_FAILED =
  'DATABASE_UPDATE_VENDOR_CRITERIA_FAILED'

export const GET_DETAIL_VENDOR_CRITERIA_START =
  'DATABASE_GET_DETAIL_VENDOR_CRITERIA_START'
export const GET_DETAIL_VENDOR_CRITERIA_SUCCESS =
  'DATABASE_GET_DETAIL_VENDOR_CRITERIA_SUCCESS'
export const GET_DETAIL_VENDOR_CRITERIA_FAILED =
  'DATABASE_GET_DETAIL_VENDOR_CRITERIA_FAILED'

export const ACTIVE_VENDOR_CRITERIA_START =
  'DATABASE_ACTIVE_VENDOR_CRITERIA_START'
export const ACTIVE_VENDOR_CRITERIA_SUCCESS =
  'DATABASE_ACTIVE_VENDOR_CRITERIA_SUCCESS'
export const ACTIVE_VENDOR_CRITERIA_FAILED =
  'DATABASE_ACTIVE_VENDOR_CRITERIA_FAILED'

export const INACTIVE_VENDOR_CRITERIA_START =
  'DATABASE_INACTIVE_VENDOR_CRITERIA_START'
export const INACTIVE_VENDOR_CRITERIA_SUCCESS =
  'DATABASE_INACTIVE_VENDOR_CRITERIA_SUCCESS'
export const INACTIVE_VENDOR_CRITERIA_FAILED =
  'DATABASE_INACTIVE_VENDOR_CRITERIA_FAILED'

export const DELETE_VENDOR_CRITERIA_BY_ID_START =
  'DATABASE_DELETE_VENDOR_CRITERIA_BY_ID_START'
export const DELETE_VENDOR_CRITERIA_BY_ID_SUCCESS =
  'DATABASE_DELETE_VENDOR_CRITERIA_BY_ID_SUCCESS'
export const DELETE_VENDOR_CRITERIA_BY_ID_FAILED =
  'DATABASE_DELETE_VENDOR_CRITERIA_BY_ID_FAILED'

export const GENCODE_VENDOR_CRITERIA_START =
  'DATABASE_GENCODE_VENDOR_CRITERIA_START'
export const GENCODE_VENDOR_CRITERIA_SUCCESS =
  'DATABASE_GENCODE_VENDOR_CRITERIA_SUCCESS'
export const GENCODE_VENDOR_CRITERIA_FAILED =
  'DATABASE_GENCODE_VENDOR_CRITERIA_FAILED'

export const RESET_VENDOR_CRITERIA_DETAIL_STATE =
  'DATABASE_RESET_VENDOR_CRITERIA_DETAIL_STATE'

export function getVendorCriteriaDetailById(payload, onSuccess, onError) {
  return {
    type: GET_DETAIL_VENDOR_CRITERIA_START,
    payload: payload,
    onSuccess,
    onError,
  }
}

export function getVendorCriteriaDetailByIdSuccess(payload) {
  return {
    type: GET_DETAIL_VENDOR_CRITERIA_SUCCESS,
    payload: payload,
  }
}

export function getVendorCriteriaDetailByIdFailed() {
  return {
    type: GET_DETAIL_VENDOR_CRITERIA_FAILED,
  }
}

export function searchVendorCriteria(payload, onSuccess, onError) {
  return {
    type: SEARCH_VENDOR_CRITERIA_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function searchVendorCriteriaSuccess(payload) {
  return {
    type: SEARCH_VENDOR_CRITERIA_SUCCESS,
    payload: payload,
  }
}

export function searchVendorCriteriaFailed() {
  return {
    type: SEARCH_VENDOR_CRITERIA_FAILED,
  }
}

export function createVendorCriteria(payload, onSuccess, onError) {
  return {
    type: CREATE_VENDOR_CRITERIA_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function createVendorCriteriaSuccess(payload) {
  return {
    type: CREATE_VENDOR_CRITERIA_SUCCESS,
    payload: payload,
  }
}

export function createVendorCriteriaFailed() {
  return {
    type: CREATE_VENDOR_CRITERIA_FAILED,
  }
}

export function updateVendorCriteria(payload, onSuccess, onError) {
  return {
    type: UPDATE_VENDOR_CRITERIA_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function updateVendorCriteriaSuccess(payload) {
  return {
    type: UPDATE_VENDOR_CRITERIA_SUCCESS,
    payload: payload,
  }
}

export function updateVendorCriteriaFailed() {
  return {
    type: UPDATE_VENDOR_CRITERIA_FAILED,
  }
}

export function activeVendorCriteria(payload, onSuccess, onError) {
  return {
    type: ACTIVE_VENDOR_CRITERIA_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function activeVendorCriteriaSuccess(payload) {
  return {
    type: ACTIVE_VENDOR_CRITERIA_SUCCESS,
    payload: payload,
  }
}

export function activeVendorCriteriaFailed() {
  return {
    type: ACTIVE_VENDOR_CRITERIA_FAILED,
  }
}

export function inactiveVendorCriteria(payload, onSuccess, onError) {
  return {
    type: INACTIVE_VENDOR_CRITERIA_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function inactiveVendorCriteriaSuccess(payload) {
  return {
    type: INACTIVE_VENDOR_CRITERIA_SUCCESS,
    payload: payload,
  }
}

export function inactiveVendorCriteriaFailed() {
  return {
    type: INACTIVE_VENDOR_CRITERIA_FAILED,
  }
}

export function deleteVendorCriteriaById(payload, onSuccess, onError) {
  return {
    type: DELETE_VENDOR_CRITERIA_BY_ID_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function deleteVendorCriteriaByIdSuccess(payload) {
  return {
    type: DELETE_VENDOR_CRITERIA_BY_ID_SUCCESS,
    payload: payload,
  }
}

export function deleteVendorCriteriaByIdFailed() {
  return {
    type: DELETE_VENDOR_CRITERIA_BY_ID_FAILED,
  }
}

export function gencodeVendorCriteria(payload, onSuccess, onError) {
  return {
    type: GENCODE_VENDOR_CRITERIA_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function gencodeVendorCriteriaSuccess(payload) {
  return {
    type: GENCODE_VENDOR_CRITERIA_SUCCESS,
    payload: payload,
  }
}

export function gencodeVendorCriteriaFailed() {
  return {
    type: GENCODE_VENDOR_CRITERIA_FAILED,
  }
}

export function resetVendorCriteriaDetailState() {
  return {
    type: RESET_VENDOR_CRITERIA_DETAIL_STATE,
  }
}

export default {
  getVendorCriteriaDetailById,
  getVendorCriteriaDetailByIdSuccess,
  getVendorCriteriaDetailByIdFailed,
  searchVendorCriteria,
  searchVendorCriteriaSuccess,
  searchVendorCriteriaFailed,
  createVendorCriteria,
  createVendorCriteriaSuccess,
  createVendorCriteriaFailed,
  updateVendorCriteria,
  updateVendorCriteriaSuccess,
  updateVendorCriteriaFailed,
  activeVendorCriteria,
  activeVendorCriteriaSuccess,
  activeVendorCriteriaFailed,
  inactiveVendorCriteria,
  inactiveVendorCriteriaSuccess,
  inactiveVendorCriteriaFailed,
  deleteVendorCriteriaById,
  deleteVendorCriteriaByIdSuccess,
  deleteVendorCriteriaByIdFailed,
  gencodeVendorCriteria,
  gencodeVendorCriteriaSuccess,
  gencodeVendorCriteriaFailed,
  resetVendorCriteriaDetailState,
}
