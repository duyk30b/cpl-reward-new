export const SEARCH_PAYMENT_METHOD_START =
  'DATABASE_SEARCH_PAYMENT_METHOD_START'
export const SEARCH_PAYMENT_METHOD_SUCCESS =
  'DATABASE_SEARCH_PAYMENT_METHOD_SUCCESS'
export const SEARCH_PAYMENT_METHOD_FAILED =
  'DATABASE_SEARCH_PAYMENT_METHOD_FAILED'

export const CREATE_PAYMENT_METHOD_START =
  'DATABASE_CREATE_PAYMENT_METHOD_START'
export const CREATE_PAYMENT_METHOD_SUCCESS =
  'DATABASE_CREATE_PAYMENT_METHOD_SUCCESS'
export const CREATE_PAYMENT_METHOD_FAILED =
  'DATABASE_CREATE_PAYMENT_METHOD_FAILED'

export const UPDATE_PAYMENT_METHOD_START =
  'DATABASE_UPDATE_PAYMENT_METHOD_START'
export const UPDATE_PAYMENT_METHOD_SUCCESS =
  'DATABASE_UPDATE_PAYMENT_METHOD_SUCCESS'
export const UPDATE_PAYMENT_METHOD_FAILED =
  'DATABASE_UPDATE_PAYMENT_METHOD_FAILED'

export const GET_DETAIL_PAYMENT_METHOD_START =
  'DATABASE_GET_DETAIL_PAYMENT_METHOD_START'
export const GET_DETAIL_PAYMENT_METHOD_SUCCESS =
  'DATABASE_GET_DETAIL_PAYMENT_METHOD_SUCCESS'
export const GET_DETAIL_PAYMENT_METHOD_FAILED =
  'DATABASE_GET_DETAIL_PAYMENT_METHOD_FAILED'

export const ACTIVE_PAYMENT_METHOD_START =
  'DATABASE_ACTIVE_PAYMENT_METHOD_START'
export const ACTIVE_PAYMENT_METHOD_SUCCESS =
  'DATABASE_ACTIVE_PAYMENT_METHOD_SUCCESS'
export const ACTIVE_PAYMENT_METHOD_FAILED =
  'DATABASE_ACTIVE_PAYMENT_METHOD_FAILED'

export const INACTIVE_PAYMENT_METHOD_START =
  'DATABASE_INACTIVE_PAYMENT_METHOD_START'
export const INACTIVE_PAYMENT_METHOD_SUCCESS =
  'DATABASE_INACTIVE_PAYMENT_METHOD_SUCCESS'
export const INACTIVE_PAYMENT_METHOD_FAILED =
  'DATABASE_INACTIVE_PAYMENT_METHOD_FAILED'

export const DELETE_PAYMENT_METHOD_START =
  'DATABASE_DELETE_PAYMENT_METHOD_START'
export const DELETE_PAYMENT_METHOD_SUCCESS =
  'DATABASE_DELETE_PAYMENT_METHOD_SUCCESS'
export const DELETE_PAYMENT_METHOD_FAILED =
  'DATABASE_DELETE_PAYMENT_METHOD_FAILED'

export const RESET_PAYMENT_METHOD_DETAIL_STATE =
  'DATABASE_RESET_PAYMENT_METHOD_DETAIL_STATE'

export function getPaymentMethodDetailById(payload, onSuccess, onError) {
  return {
    type: GET_DETAIL_PAYMENT_METHOD_START,
    payload: payload,
    onSuccess,
    onError,
  }
}

export function getPaymentMethodDetailByIdSuccess(payload) {
  return {
    type: GET_DETAIL_PAYMENT_METHOD_SUCCESS,
    payload: payload,
  }
}

export function getPaymentMethodDetailByIdFailed() {
  return {
    type: GET_DETAIL_PAYMENT_METHOD_FAILED,
  }
}

export function searchPaymentMethod(payload, onSuccess, onError) {
  return {
    type: SEARCH_PAYMENT_METHOD_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function searchPaymentMethodSuccess(payload) {
  return {
    type: SEARCH_PAYMENT_METHOD_SUCCESS,
    payload: payload,
  }
}

export function searchPaymentMethodFailed() {
  return {
    type: SEARCH_PAYMENT_METHOD_FAILED,
  }
}

export function createPaymentMethod(payload, onSuccess, onError) {
  return {
    type: CREATE_PAYMENT_METHOD_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function createPaymentMethodSuccess(payload) {
  return {
    type: CREATE_PAYMENT_METHOD_SUCCESS,
    payload: payload,
  }
}

export function createPaymentMethodFailed() {
  return {
    type: CREATE_PAYMENT_METHOD_FAILED,
  }
}

export function updatePaymentMethod(payload, onSuccess, onError) {
  return {
    type: UPDATE_PAYMENT_METHOD_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function updatePaymentMethodSuccess(payload) {
  return {
    type: UPDATE_PAYMENT_METHOD_SUCCESS,
    payload: payload,
  }
}

export function updatePaymentMethodFailed() {
  return {
    type: UPDATE_PAYMENT_METHOD_FAILED,
  }
}

export function activePaymentMethod(payload, onSuccess, onError) {
  return {
    type: ACTIVE_PAYMENT_METHOD_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function activePaymentMethodSuccess(payload) {
  return {
    type: ACTIVE_PAYMENT_METHOD_SUCCESS,
    payload: payload,
  }
}

export function activePaymentMethodFailed() {
  return {
    type: ACTIVE_PAYMENT_METHOD_FAILED,
  }
}

export function inactivePaymentMethod(payload, onSuccess, onError) {
  return {
    type: INACTIVE_PAYMENT_METHOD_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function inactivePaymentMethodSuccess(payload) {
  return {
    type: INACTIVE_PAYMENT_METHOD_SUCCESS,
    payload: payload,
  }
}

export function inactivePaymentMethodFailed() {
  return {
    type: INACTIVE_PAYMENT_METHOD_FAILED,
  }
}

export function deletePaymentMethod(payload, onSuccess, onError) {
  return {
    type: DELETE_PAYMENT_METHOD_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function deletePaymentMethodSuccess(payload) {
  return {
    type: DELETE_PAYMENT_METHOD_SUCCESS,
    payload: payload,
  }
}

export function deletePaymentMethodFailed() {
  return {
    type: DELETE_PAYMENT_METHOD_FAILED,
  }
}

export function resetPaymentMethodDetailState() {
  return {
    type: RESET_PAYMENT_METHOD_DETAIL_STATE,
  }
}

export default {
  getPaymentMethodDetailById,
  getPaymentMethodDetailByIdSuccess,
  getPaymentMethodDetailByIdFailed,
  searchPaymentMethod,
  searchPaymentMethodSuccess,
  searchPaymentMethodFailed,
  createPaymentMethod,
  createPaymentMethodSuccess,
  createPaymentMethodFailed,
  updatePaymentMethod,
  updatePaymentMethodSuccess,
  updatePaymentMethodFailed,
  activePaymentMethod,
  activePaymentMethodSuccess,
  activePaymentMethodFailed,
  inactivePaymentMethod,
  inactivePaymentMethodSuccess,
  inactivePaymentMethodFailed,
  deletePaymentMethod,
  deletePaymentMethodSuccess,
  deletePaymentMethodFailed,
  resetPaymentMethodDetailState,
}
