export const SEARCH_DELIVERY_METHOD_START =
  'DATABASE_SEARCH_DELIVERY_METHOD_START'
export const SEARCH_DELIVERY_METHOD_SUCCESS =
  'DATABASE_SEARCH_DELIVERY_METHOD_SUCCESS'
export const SEARCH_DELIVERY_METHOD_FAILED =
  'DATABASE_SEARCH_DELIVERY_METHOD_FAILED'

export const CREATE_DELIVERY_METHOD_START =
  'DATABASE_CREATE_DELIVERY_METHOD_START'
export const CREATE_DELIVERY_METHOD_SUCCESS =
  'DATABASE_CREATE_DELIVERY_METHOD_SUCCESS'
export const CREATE_DELIVERY_METHOD_FAILED =
  'DATABASE_CREATE_DELIVERY_METHOD_FAILED'

export const UPDATE_DELIVERY_METHOD_START =
  'DATABASE_UPDATE_DELIVERY_METHOD_START'
export const UPDATE_DELIVERY_METHOD_SUCCESS =
  'DATABASE_UPDATE_DELIVERY_METHOD_SUCCESS'
export const UPDATE_DELIVERY_METHOD_FAILED =
  'DATABASE_UPDATE_DELIVERY_METHOD_FAILED'

export const GET_DETAIL_DELIVERY_METHOD_START =
  'DATABASE_GET_DETAIL_DELIVERY_METHOD_START'
export const GET_DETAIL_DELIVERY_METHOD_SUCCESS =
  'DATABASE_GET_DETAIL_DELIVERY_METHOD_SUCCESS'
export const GET_DETAIL_DELIVERY_METHOD_FAILED =
  'DATABASE_GET_DETAIL_DELIVERY_METHOD_FAILED'

export const ACTIVE_DELIVERY_METHOD_START =
  'DATABASE_ACTIVE_DELIVERY_METHOD_START'
export const ACTIVE_DELIVERY_METHOD_SUCCESS =
  'DATABASE_ACTIVE_DELIVERY_METHOD_SUCCESS'
export const ACTIVE_DELIVERY_METHOD_FAILED =
  'DATABASE_ACTIVE_DELIVERY_METHOD_FAILED'

export const INACTIVE_DELIVERY_METHOD_START =
  'DATABASE_INACTIVE_DELIVERY_METHOD_START'
export const INACTIVE_DELIVERY_METHOD_SUCCESS =
  'DATABASE_INACTIVE_DELIVERY_METHOD_SUCCESS'
export const INACTIVE_DELIVERY_METHOD_FAILED =
  'DATABASE_INACTIVE_DELIVERY_METHOD_FAILED'

export const DELETE_DELIVERY_METHOD_START =
  'DATABASE_DELETE_DELIVERY_METHOD_START'
export const DELETE_DELIVERY_METHOD_SUCCESS =
  'DATABASE_DELETE_DELIVERY_METHOD_SUCCESS'
export const DELETE_DELIVERY_METHOD_FAILED =
  'DATABASE_DELETE_DELIVERY_METHOD_FAILED'

export const RESET_DELIVERY_METHOD_DETAIL_STATE =
  'DATABASE_RESET_DELIVERY_METHOD_DETAIL_STATE'

export function getDeliveryMethodDetailById(payload, onSuccess, onError) {
  return {
    type: GET_DETAIL_DELIVERY_METHOD_START,
    payload: payload,
    onSuccess,
    onError,
  }
}

export function getDeliveryMethodDetailByIdSuccess(payload) {
  return {
    type: GET_DETAIL_DELIVERY_METHOD_SUCCESS,
    payload: payload,
  }
}

export function getDeliveryMethodDetailByIdFailed() {
  return {
    type: GET_DETAIL_DELIVERY_METHOD_FAILED,
  }
}

export function searchDeliveryMethod(payload, onSuccess, onError) {
  return {
    type: SEARCH_DELIVERY_METHOD_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function searchDeliveryMethodSuccess(payload) {
  return {
    type: SEARCH_DELIVERY_METHOD_SUCCESS,
    payload: payload,
  }
}

export function searchDeliveryMethodFailed() {
  return {
    type: SEARCH_DELIVERY_METHOD_FAILED,
  }
}

export function createDeliveryMethod(payload, onSuccess, onError) {
  return {
    type: CREATE_DELIVERY_METHOD_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function createDeliveryMethodSuccess(payload) {
  return {
    type: CREATE_DELIVERY_METHOD_SUCCESS,
    payload: payload,
  }
}

export function createDeliveryMethodFailed() {
  return {
    type: CREATE_DELIVERY_METHOD_FAILED,
  }
}

export function updateDeliveryMethod(payload, onSuccess, onError) {
  return {
    type: UPDATE_DELIVERY_METHOD_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function updateDeliveryMethodSuccess(payload) {
  return {
    type: UPDATE_DELIVERY_METHOD_SUCCESS,
    payload: payload,
  }
}

export function updateDeliveryMethodFailed() {
  return {
    type: UPDATE_DELIVERY_METHOD_FAILED,
  }
}

export function activeDeliveryMethod(payload, onSuccess, onError) {
  return {
    type: ACTIVE_DELIVERY_METHOD_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function activeDeliveryMethodSuccess(payload) {
  return {
    type: ACTIVE_DELIVERY_METHOD_SUCCESS,
    payload: payload,
  }
}

export function activeDeliveryMethodFailed() {
  return {
    type: ACTIVE_DELIVERY_METHOD_FAILED,
  }
}

export function inactiveDeliveryMethod(payload, onSuccess, onError) {
  return {
    type: INACTIVE_DELIVERY_METHOD_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function inactiveDeliveryMethodSuccess(payload) {
  return {
    type: INACTIVE_DELIVERY_METHOD_SUCCESS,
    payload: payload,
  }
}

export function inactiveDeliveryMethodFailed() {
  return {
    type: INACTIVE_DELIVERY_METHOD_FAILED,
  }
}

export function deleteDeliveryMethod(payload, onSuccess, onError) {
  return {
    type: DELETE_DELIVERY_METHOD_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function deleteDeliveryMethodSuccess(payload) {
  return {
    type: DELETE_DELIVERY_METHOD_SUCCESS,
    payload: payload,
  }
}

export function deleteDeliveryMethodFailed() {
  return {
    type: DELETE_DELIVERY_METHOD_FAILED,
  }
}

export function resetDeliveryMethodDetailState() {
  return {
    type: RESET_DELIVERY_METHOD_DETAIL_STATE,
  }
}

export default {
  getDeliveryMethodDetailById,
  getDeliveryMethodDetailByIdSuccess,
  getDeliveryMethodDetailByIdFailed,
  searchDeliveryMethod,
  searchDeliveryMethodSuccess,
  searchDeliveryMethodFailed,
  createDeliveryMethod,
  createDeliveryMethodSuccess,
  createDeliveryMethodFailed,
  updateDeliveryMethod,
  updateDeliveryMethodSuccess,
  updateDeliveryMethodFailed,
  activeDeliveryMethod,
  activeDeliveryMethodSuccess,
  activeDeliveryMethodFailed,
  inactiveDeliveryMethod,
  inactiveDeliveryMethodSuccess,
  inactiveDeliveryMethodFailed,
  deleteDeliveryMethod,
  deleteDeliveryMethodSuccess,
  deleteDeliveryMethodFailed,
  resetDeliveryMethodDetailState,
}
