export const SEARCH_CURRENCY_RATE_LIST_START =
  'DATABASE_SEARCH_CURRENCY_RATE_LIST_START'
export const SEARCH_CURRENCY_RATE_LIST_SUCCESS =
  'DATABASE_SEARCH_CURRENCY_RATE_LIST_SUCCESS'
export const SEARCH_CURRENCY_RATE_LIST_FAILED =
  'DATABASE_SEARCH_CURRENCY_RATE_LIST_FAILED'

export const SEARCH_CURRENCY_RATE_HISTORY_START =
  'DATABASE_SEARCH_CURRENCY_RATE_HISTORY_START'
export const SEARCH_CURRENCY_RATE_HISTORY_SUCCESS =
  'DATABASE_SEARCH_CURRENCY_RATE_HISTORY_SUCCESS'
export const SEARCH_CURRENCY_RATE_HISTORY_FAILED =
  'DATABASE_SEARCH_CURRENCY_RATE_HISTORY_FAILED'

export const CREATE_CURRENCY_RATE_START = 'DATABASE_CREATE_CURRENCY_RATE_START'
export const CREATE_CURRENCY_RATE_SUCCESS =
  'DATABASE_CREATE_CURRENCY_RATE_SUCCESS'
export const CREATE_CURRENCY_RATE_FAILED =
  'DATABASE_CREATE_CURRENCY_RATE_FAILED'

export const UPDATE_CURRENCY_RATE_START = 'DATABASE_UPDATE_CURRENCY_RATE_START'
export const UPDATE_CURRENCY_RATE_SUCCESS =
  'DATABASE_UPDATE_CURRENCY_RATE_SUCCESS'
export const UPDATE_CURRENCY_RATE_FAILED =
  'DATABASE_UPDATE_CURRENCY_RATE_FAILED'

export const GET_MAIN_CURRENCY_START = 'DATABASE_GET_MAIN_CURRENCY_START'
export const GET_MAIN_CURRENCY_SUCCESS = 'DATABASE_GET_MAIN_CURRENCY_SUCCESS'
export const GET_MAIN_CURRENCY_FAILED = 'DATABASE_GET_MAIN_CURRENCY_FAILED'

export function searchCurrencyRateList(payload, onSuccess, onError) {
  return {
    type: SEARCH_CURRENCY_RATE_LIST_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function searchCurrencyRateListSuccess(payload) {
  return {
    type: SEARCH_CURRENCY_RATE_LIST_SUCCESS,
    payload: payload,
  }
}

export function searchCurrencyRateListFailed() {
  return {
    type: SEARCH_CURRENCY_RATE_LIST_FAILED,
  }
}

export function searchCurrencyRateHistory(payload, onSuccess, onError) {
  return {
    type: SEARCH_CURRENCY_RATE_HISTORY_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function searchCurrencyRateHistorySuccess(payload) {
  return {
    type: SEARCH_CURRENCY_RATE_HISTORY_SUCCESS,
    payload: payload,
  }
}

export function searchCurrencyRateHistoryFailed() {
  return {
    type: SEARCH_CURRENCY_RATE_HISTORY_FAILED,
  }
}

export function createCurrencyRate(payload, onSuccess, onError) {
  return {
    type: CREATE_CURRENCY_RATE_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function createCurrencyRateSuccess(payload) {
  return {
    type: CREATE_CURRENCY_RATE_SUCCESS,
    payload: payload,
  }
}

export function createCurrencyRateFailed() {
  return {
    type: CREATE_CURRENCY_RATE_FAILED,
  }
}

export function updateCurrencyRate(payload, onSuccess, onError) {
  return {
    type: UPDATE_CURRENCY_RATE_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function updateCurrencyRateSuccess(payload) {
  return {
    type: UPDATE_CURRENCY_RATE_SUCCESS,
    payload: payload,
  }
}

export function updateCurrencyRateFailed() {
  return {
    type: UPDATE_CURRENCY_RATE_FAILED,
  }
}

export function getMainCurrency(payload, onSuccess, onError) {
  return {
    type: GET_MAIN_CURRENCY_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function getMainCurrencySuccess(payload) {
  return {
    type: GET_MAIN_CURRENCY_SUCCESS,
    payload: payload,
  }
}

export function getMainCurrencyFailed() {
  return {
    type: GET_MAIN_CURRENCY_FAILED,
  }
}

export default {
  searchCurrencyRateList,
  searchCurrencyRateListSuccess,
  searchCurrencyRateListFailed,
  searchCurrencyRateHistory,
  searchCurrencyRateHistorySuccess,
  searchCurrencyRateHistoryFailed,
  createCurrencyRate,
  createCurrencyRateSuccess,
  createCurrencyRateFailed,
  updateCurrencyRate,
  updateCurrencyRateSuccess,
  updateCurrencyRateFailed,
  getMainCurrency,
  getMainCurrencySuccess,
  getMainCurrencyFailed,
}
