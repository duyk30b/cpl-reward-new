export const SEARCH_CURRENCY_UNIT_START = 'DATABASE_SEARCH_CURRENCY_UNIT_START'
export const SEARCH_CURRENCY_UNIT_SUCCESS =
  'DATABASE_SEARCH_CURRENCY_UNIT_SUCCESS'
export const SEARCH_CURRENCY_UNIT_FAILED =
  'DATABASE_SEARCH_CURRENCY_UNIT_FAILED'

export const CREATE_CURRENCY_UNIT_START = 'DATABASE_CREATE_CURRENCY_UNIT_START'
export const CREATE_CURRENCY_UNIT_SUCCESS =
  'DATABASE_CREATE_CURRENCY_UNIT_SUCCESS'
export const CREATE_CURRENCY_UNIT_FAILED =
  'DATABASE_CREATE_CURRENCY_UNIT_FAILED'

export const UPDATE_CURRENCY_UNIT_START = 'DATABASE_UPDATE_CURRENCY_UNIT_START'
export const UPDATE_CURRENCY_UNIT_SUCCESS =
  'DATABASE_UPDATE_CURRENCY_UNIT_SUCCESS'
export const UPDATE_CURRENCY_UNIT_FAILED =
  'DATABASE_UPDATE_CURRENCY_UNIT_FAILED'

export const GET_DETAIL_CURRENCY_UNIT_START =
  'DATABASE_GET_DETAIL_CURRENCY_UNIT_START'
export const GET_DETAIL_CURRENCY_UNIT_SUCCESS =
  'DATABASE_GET_DETAIL_CURRENCY_UNIT_SUCCESS'
export const GET_DETAIL_CURRENCY_UNIT_FAILED =
  'DATABASE_GET_DETAIL_CURRENCY_UNIT_FAILED'

export const ACTIVE_CURRENCY_UNIT_START = 'DATABASE_ACTIVE_CURRENCY_UNIT_START'
export const ACTIVE_CURRENCY_UNIT_SUCCESS =
  'DATABASE_ACTIVE_CURRENCY_UNIT_SUCCESS'
export const ACTIVE_CURRENCY_UNIT_FAILED =
  'DATABASE_ACTIVE_CURRENCY_UNIT_FAILED'

export const INACTIVE_CURRENCY_UNIT_START =
  'DATABASE_INACTIVE_CURRENCY_UNIT_START'
export const INACTIVE_CURRENCY_UNIT_SUCCESS =
  'DATABASE_INACTIVE_CURRENCY_UNIT_SUCCESS'
export const INACTIVE_CURRENCY_UNIT_FAILED =
  'DATABASE_INACTIVE_CURRENCY_UNIT_FAILED'

export const DELETE_CURRENCY_UNIT_START = 'DATABASE_DELETE_CURRENCY_UNIT_START'
export const DELETE_CURRENCY_UNIT_SUCCESS =
  'DATABASE_DELETE_CURRENCY_UNIT_SUCCESS'
export const DELETE_CURRENCY_UNIT_FAILED =
  'DATABASE_DELETE_CURRENCY_UNIT_FAILED'

export const RESET_CURRENCY_UNIT_DETAIL_STATE =
  'DATABASE_RESET_CURRENCY_UNIT_DETAIL_STATE'

export function getCurrencyUnitDetailById(payload, onSuccess, onError) {
  return {
    type: GET_DETAIL_CURRENCY_UNIT_START,
    payload: payload,
    onSuccess,
    onError,
  }
}

export function getCurrencyUnitDetailByIdSuccess(payload) {
  return {
    type: GET_DETAIL_CURRENCY_UNIT_SUCCESS,
    payload: payload,
  }
}

export function getCurrencyUnitDetailByIdFailed() {
  return {
    type: GET_DETAIL_CURRENCY_UNIT_FAILED,
  }
}

export function searchCurrencyUnit(payload, onSuccess, onError) {
  return {
    type: SEARCH_CURRENCY_UNIT_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function searchCurrencyUnitSuccess(payload) {
  return {
    type: SEARCH_CURRENCY_UNIT_SUCCESS,
    payload: payload,
  }
}

export function searchCurrencyUnitFailed() {
  return {
    type: SEARCH_CURRENCY_UNIT_FAILED,
  }
}

export function createCurrencyUnit(payload, onSuccess, onError) {
  return {
    type: CREATE_CURRENCY_UNIT_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function createCurrencyUnitSuccess(payload) {
  return {
    type: CREATE_CURRENCY_UNIT_SUCCESS,
    payload: payload,
  }
}

export function createCurrencyUnitFailed() {
  return {
    type: CREATE_CURRENCY_UNIT_FAILED,
  }
}

export function updateCurrencyUnit(payload, onSuccess, onError) {
  return {
    type: UPDATE_CURRENCY_UNIT_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function updateCurrencyUnitSuccess(payload) {
  return {
    type: UPDATE_CURRENCY_UNIT_SUCCESS,
    payload: payload,
  }
}

export function updateCurrencyUnitFailed() {
  return {
    type: UPDATE_CURRENCY_UNIT_FAILED,
  }
}

export function activeCurrencyUnit(payload, onSuccess, onError) {
  return {
    type: ACTIVE_CURRENCY_UNIT_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function activeCurrencyUnitSuccess(payload) {
  return {
    type: ACTIVE_CURRENCY_UNIT_SUCCESS,
    payload: payload,
  }
}

export function activeCurrencyUnitFailed() {
  return {
    type: ACTIVE_CURRENCY_UNIT_FAILED,
  }
}

export function inactiveCurrencyUnit(payload, onSuccess, onError) {
  return {
    type: INACTIVE_CURRENCY_UNIT_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function inactiveCurrencyUnitSuccess(payload) {
  return {
    type: INACTIVE_CURRENCY_UNIT_SUCCESS,
    payload: payload,
  }
}

export function inactiveCurrencyUnitFailed() {
  return {
    type: INACTIVE_CURRENCY_UNIT_FAILED,
  }
}

export function deleteCurrencyUnit(payload, onSuccess, onError) {
  return {
    type: DELETE_CURRENCY_UNIT_START,
    payload: payload,
    onSuccess: onSuccess,
    onError: onError,
  }
}

export function deleteCurrencyUnitSuccess(payload) {
  return {
    type: DELETE_CURRENCY_UNIT_SUCCESS,
    payload: payload,
  }
}

export function deleteCurrencyUnitFailed() {
  return {
    type: DELETE_CURRENCY_UNIT_FAILED,
  }
}

export function resetCurrencyUnitDetailState() {
  return {
    type: RESET_CURRENCY_UNIT_DETAIL_STATE,
  }
}

export default {
  getCurrencyUnitDetailById,
  getCurrencyUnitDetailByIdSuccess,
  getCurrencyUnitDetailByIdFailed,
  searchCurrencyUnit,
  searchCurrencyUnitSuccess,
  searchCurrencyUnitFailed,
  createCurrencyUnit,
  createCurrencyUnitSuccess,
  createCurrencyUnitFailed,
  updateCurrencyUnit,
  updateCurrencyUnitSuccess,
  updateCurrencyUnitFailed,
  activeCurrencyUnit,
  activeCurrencyUnitSuccess,
  activeCurrencyUnitFailed,
  inactiveCurrencyUnit,
  inactiveCurrencyUnitSuccess,
  inactiveCurrencyUnitFailed,
  deleteCurrencyUnit,
  deleteCurrencyUnitSuccess,
  deleteCurrencyUnitFailed,
  resetCurrencyUnitDetailState,
}
