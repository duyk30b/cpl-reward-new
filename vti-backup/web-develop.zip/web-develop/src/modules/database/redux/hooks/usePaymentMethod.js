import { useMemo } from 'react'

import { get } from 'lodash'
import { useSelector, useDispatch } from 'react-redux'
import { bindActionCreators } from 'redux'

import paymentMethodActions from '~/modules/database/redux/actions/payment-method'

const usePaymentMethod = () => {
  const data = useSelector((state) => get(state, 'database.paymentMethod'))

  const dispatch = useDispatch()
  const actions = useMemo(
    () => bindActionCreators(paymentMethodActions, dispatch),
    [dispatch],
  )
  return {
    actions,
    data,
  }
}

export default usePaymentMethod
