import { useMemo } from 'react'

import { get } from 'lodash'
import { useSelector, useDispatch } from 'react-redux'
import { bindActionCreators } from 'redux'

import deliveryMethodActions from '~/modules/database/redux/actions/delivery-method'

const useDeliveryMethod = () => {
  const data = useSelector((state) => get(state, 'database.deliveryMethod'))

  const dispatch = useDispatch()
  const actions = useMemo(
    () => bindActionCreators(deliveryMethodActions, dispatch),
    [dispatch],
  )
  return {
    actions,
    data,
  }
}

export default useDeliveryMethod
