import { useMemo } from 'react'

import { get } from 'lodash'
import { useSelector, useDispatch } from 'react-redux'
import { bindActionCreators } from 'redux'

import vendorCriteriaActions from '~/modules/database/redux/actions/vendor-criteria'

const useVendorCriteria = () => {
  const data = useSelector((state) => get(state, 'database.vendorCriteria'))

  const dispatch = useDispatch()
  const actions = useMemo(
    () => bindActionCreators(vendorCriteriaActions, dispatch),
    [dispatch],
  )
  return {
    actions,
    data,
  }
}

export default useVendorCriteria
