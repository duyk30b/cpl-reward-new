import { useMemo } from 'react'

import { get } from 'lodash'
import { useSelector, useDispatch } from 'react-redux'
import { bindActionCreators } from 'redux'

import currencyRateActions from '~/modules/database/redux/actions/currency-rate'

const useCurrencyRate = () => {
  const data = useSelector((state) => get(state, 'database.currencyRate'))

  const dispatch = useDispatch()
  const actions = useMemo(
    () => bindActionCreators(currencyRateActions, dispatch),
    [dispatch],
  )
  return {
    actions,
    data,
  }
}

export default useCurrencyRate
