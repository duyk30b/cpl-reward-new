import { call, put, takeLatest } from 'redux-saga/effects'

import {
  getCurrencyUnitDetailByIdSuccess,
  getCurrencyUnitDetailByIdFailed,
  GET_DETAIL_CURRENCY_UNIT_START,
} from '~/modules/database/redux/actions/currency-unit'
import { api } from '~/services/api'

/**
 * Search user API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
const getCurrencyUnitApi = (params) => {
  const uri = `v1/items/currency-units/${params}`
  return api.get(uri)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doGetCurrencyUnit(action) {
  try {
    const response = yield call(getCurrencyUnitApi, action?.payload)

    if (response?.statusCode === 200) {
      yield put(getCurrencyUnitDetailByIdSuccess(response.data))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess(response.data)
      }
    } else {
      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(getCurrencyUnitDetailByIdFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch search users
 */
export default function* watchGetCurrencyUnit() {
  yield takeLatest(GET_DETAIL_CURRENCY_UNIT_START, doGetCurrencyUnit)
}
