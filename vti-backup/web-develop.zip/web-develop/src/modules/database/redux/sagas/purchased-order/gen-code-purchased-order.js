import { call, put, takeLatest } from 'redux-saga/effects'

import { NOTIFICATION_TYPE } from '~/common/constants'
import {
  genCodePurchasedOrderFailed,
  genCodePurchasedOrderSuccess,
  GEN_CODE_PURCHASED_ORDER_START,
} from '~/modules/database/redux/actions/purchased-order'
import { api } from '~/services/api'
import addNotification from '~/utils/toast'

/**
 * Gen code API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
const genCodePurchasedOrderApi = () => {
  const uri = `v1/purchased-orders/generate-code`
  return api.get(uri)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doGenCodePurchasedOrder(action) {
  try {
    const response = yield call(genCodePurchasedOrderApi)
    if (response?.statusCode === 200) {
      yield put(genCodePurchasedOrderSuccess(response?.data))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess(response?.data)
      }
    } else {
      addNotification(
        response?.message || response?.statusText,
        NOTIFICATION_TYPE.ERROR,
      )

      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(genCodePurchasedOrderFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch
 */
export default function* watchGenCodePurchasedOrder() {
  yield takeLatest(GEN_CODE_PURCHASED_ORDER_START, doGenCodePurchasedOrder)
}
