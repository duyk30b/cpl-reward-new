import { call, put, takeLatest } from 'redux-saga/effects'

import { NOTIFICATION_TYPE } from '~/common/constants'
import {
  activeDeliveryMethodFailed,
  activeDeliveryMethodSuccess,
  ACTIVE_DELIVERY_METHOD_START,
} from '~/modules/database/redux/actions/delivery-method'
import { api } from '~/services/api'
import addNotification from '~/utils/toast'

const activeDeliveryMethodApi = (params) => {
  const uri = `v1/purchased-orders/shipping-types/${params}/active`
  return api.put(uri)
}

function* doActiveDeliveryMethod(action) {
  try {
    const response = yield call(activeDeliveryMethodApi, action?.payload)

    if (response?.statusCode === 200) {
      yield put(activeDeliveryMethodSuccess(response.payload))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess()
      }

      addNotification(response?.message, NOTIFICATION_TYPE.SUCCESS)
    } else {
      addNotification(
        response?.message || response?.statusText,
        NOTIFICATION_TYPE.ERROR,
      )

      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(activeDeliveryMethodFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

export default function* watchActiveDeliveryMethod() {
  yield takeLatest(ACTIVE_DELIVERY_METHOD_START, doActiveDeliveryMethod)
}
