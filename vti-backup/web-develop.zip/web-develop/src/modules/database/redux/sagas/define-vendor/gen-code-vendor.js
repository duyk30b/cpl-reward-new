import { call, put, takeLatest } from 'redux-saga/effects'

import { NOTIFICATION_TYPE } from '~/common/constants'
import {
  genCodeVendorFailed,
  genCodeVendorSuccess,
  GEN_CODE_VENDOR_START,
} from '~/modules/database/redux/actions/define-vendor'
import { api } from '~/services/api'
import addNotification from '~/utils/toast'

/**
 * Gen code API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
const genCodeVendorApi = () => {
  const uri = `v1/sales/generate-codes?type=0`
  return api.get(uri)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doGenCodeVendor(action) {
  try {
    const response = yield call(genCodeVendorApi)
    if (response?.statusCode === 200) {
      yield put(genCodeVendorSuccess(response?.data))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess(response?.data)
      }
    } else {
      addNotification(
        response?.message || response?.statusText,
        NOTIFICATION_TYPE.ERROR,
      )

      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(genCodeVendorFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch
 */
export default function* watchGenCodeVendor() {
  yield takeLatest(GEN_CODE_VENDOR_START, doGenCodeVendor)
}
