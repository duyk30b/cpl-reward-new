import { call, put, takeLatest } from 'redux-saga/effects'

import {
  getDetailVersionByIdFailed,
  getDetailVersionByIdSuccess,
  GET_DETAIL_VERSION_BY_ID_START,
} from '~/modules/database/redux/actions/purchased-order'
import { api } from '~/services/api'
/**
 * Search user API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
const getDetailVersionByIdApi = (params) => {
  const uri = `/v1/purchased-orders/${params.id}/versions/${params.versionId}`
  return api.get(uri)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doGetDetailVersionById(action) {
  try {
    const response = yield call(getDetailVersionByIdApi, action?.payload)

    if (response?.statusCode === 200) {
      yield put(getDetailVersionByIdSuccess(response?.data))

      // Call callback action if provided
      if (action.onSuccess) {
        action.onSuccess(response?.data)
      }
    } else {
      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(getDetailVersionByIdFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch search users
 */
export default function* watchGetDetailVersionById() {
  yield takeLatest(GET_DETAIL_VERSION_BY_ID_START, doGetDetailVersionById)
}
