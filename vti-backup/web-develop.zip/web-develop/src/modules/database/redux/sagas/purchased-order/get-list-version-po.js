import { call, put, takeLatest } from 'redux-saga/effects'

import {
  getListVersionPOFailed,
  getListVersionPOSuccess,
  GET_LIST_VERSION_PO_START,
} from '~/modules/database/redux/actions/purchased-order'
import { api } from '~/services/api'
/**
 * Search purchased-order API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
export const getListVersionPOApi = (params) => {
  const uri = `/v1/purchased-orders/${params}/versions`
  return api.get(uri)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doGetListVersionPO(action) {
  try {
    const response = yield call(getListVersionPOApi, action?.payload)

    if (response?.statusCode === 200) {
      yield put(getListVersionPOSuccess(response))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess(response)
      }
    } else {
      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(getListVersionPOFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch search purchased-orders
 */
export default function* watchGetListVersionPO() {
  yield takeLatest(GET_LIST_VERSION_PO_START, doGetListVersionPO)
}
