import { call, put, takeLatest } from 'redux-saga/effects'

import {
  getMainCurrencyFailed,
  getMainCurrencySuccess,
  GET_MAIN_CURRENCY_START,
} from '~/modules/database/redux/actions/currency-rate'
import { api } from '~/services/api'

/**
 * Search user API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
const getMainCurrencyApi = (params) => {
  const uri = `v1/items/currency-units/main`
  return api.get(uri, params)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doGetMainCurrency(action) {
  try {
    const response = yield call(getMainCurrencyApi, action?.payload)

    if (response?.statusCode === 200) {
      yield put(getMainCurrencySuccess(response?.data))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess()
      }
    } else {
      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(getMainCurrencyFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch search users
 */
export default function* watchGetMainCurrency() {
  yield takeLatest(GET_MAIN_CURRENCY_START, doGetMainCurrency)
}
