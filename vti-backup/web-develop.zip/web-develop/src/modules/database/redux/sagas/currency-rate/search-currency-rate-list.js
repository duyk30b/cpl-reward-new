import { call, put, takeLatest } from 'redux-saga/effects'

import {
  searchCurrencyRateListFailed,
  searchCurrencyRateListSuccess,
  SEARCH_CURRENCY_RATE_LIST_START,
} from '~/modules/database/redux/actions/currency-rate'
import { api } from '~/services/api'

/**
 * Search user API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
export const searchCurrencyRateApi = (params) => {
  const uri = `v1/items/exchange-rates/list`
  return api.get(uri, params)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doSearchCurrencyRate(action) {
  try {
    const response = yield call(searchCurrencyRateApi, action?.payload)

    if (response?.statusCode === 200) {
      const payload = {
        list: response.data.items,
        total: response.data.meta.total,
      }
      yield put(searchCurrencyRateListSuccess(payload))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess()
      }
    } else {
      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(searchCurrencyRateListFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch search users
 */
export default function* watchSearchCurrencyRate() {
  yield takeLatest(SEARCH_CURRENCY_RATE_LIST_START, doSearchCurrencyRate)
}
