import { call, put, takeLatest } from 'redux-saga/effects'

import {
  searchDeliveryMethodFailed,
  searchDeliveryMethodSuccess,
  SEARCH_DELIVERY_METHOD_START,
} from '~/modules/database/redux/actions/delivery-method'
import { api } from '~/services/api'

/**
 * Search user API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
export const searchDeliveryMethodApi = (params) => {
  const uri = `v1/purchased-orders/shipping-types`
  return api.get(uri, params)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doSearchDeliveryMethod(action) {
  try {
    const response = yield call(searchDeliveryMethodApi, action?.payload)

    if (response?.statusCode === 200) {
      const payload = {
        list: response.data.items,
        total: response.data.meta.total,
      }
      yield put(searchDeliveryMethodSuccess(payload))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess()
      }
    } else {
      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(searchDeliveryMethodFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch search users
 */
export default function* watchSearchDeliveryMethod() {
  yield takeLatest(SEARCH_DELIVERY_METHOD_START, doSearchDeliveryMethod)
}
