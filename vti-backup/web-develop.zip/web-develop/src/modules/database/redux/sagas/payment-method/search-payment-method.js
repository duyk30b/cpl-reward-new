import { call, put, takeLatest } from 'redux-saga/effects'

import {
  searchPaymentMethodFailed,
  searchPaymentMethodSuccess,
  SEARCH_PAYMENT_METHOD_START,
} from '~/modules/database/redux/actions/payment-method'
import { api } from '~/services/api'

/**
 * Search user API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
export const searchPaymentMethodApi = (params) => {
  const uri = `v1/purchased-orders/payment-types`
  return api.get(uri, params)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doSearchPaymentMethod(action) {
  try {
    const response = yield call(searchPaymentMethodApi, action?.payload)

    if (response?.statusCode === 200) {
      const payload = {
        list: response.data.items,
        total: response.data.meta.total,
      }
      yield put(searchPaymentMethodSuccess(payload))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess()
      }
    } else {
      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(searchPaymentMethodFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch search users
 */
export default function* watchSearchPaymentMethod() {
  yield takeLatest(SEARCH_PAYMENT_METHOD_START, doSearchPaymentMethod)
}
