import { call, put, takeLatest } from 'redux-saga/effects'

import {
  searchCurrencyUnitFailed,
  searchCurrencyUnitSuccess,
  SEARCH_CURRENCY_UNIT_START,
} from '~/modules/database/redux/actions/currency-unit'
import { api } from '~/services/api'

/**
 * Search user API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
export const searchCurrencyUnitApi = (params) => {
  const uri = `v1/items/currency-units/list`
  return api.get(uri, params)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doSearchCurrencyUnit(action) {
  try {
    const response = yield call(searchCurrencyUnitApi, action?.payload)

    if (response?.statusCode === 200) {
      const payload = {
        list: response.data.items,
        total: response.data.meta.total,
      }
      yield put(searchCurrencyUnitSuccess(payload))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess()
      }
    } else {
      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(searchCurrencyUnitFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch search users
 */
export default function* watchSearchCurrencyUnit() {
  yield takeLatest(SEARCH_CURRENCY_UNIT_START, doSearchCurrencyUnit)
}
