import { call, put, takeLatest } from 'redux-saga/effects'

import {
  getPaymentMethodDetailByIdSuccess,
  getPaymentMethodDetailByIdFailed,
  GET_DETAIL_PAYMENT_METHOD_START,
} from '~/modules/database/redux/actions/payment-method'
import { api } from '~/services/api'

/**
 * Search user API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
const getPaymentMethodDetailApi = (params) => {
  const uri = `v1/purchased-orders/payment-types/${params}`
  return api.get(uri)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doGetPaymentMethod(action) {
  try {
    const response = yield call(getPaymentMethodDetailApi, action?.payload)

    if (response?.statusCode === 200) {
      yield put(getPaymentMethodDetailByIdSuccess(response.data))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess(response.data)
      }
    } else {
      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(getPaymentMethodDetailByIdFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch search users
 */
export default function* watchGetPaymentMethod() {
  yield takeLatest(GET_DETAIL_PAYMENT_METHOD_START, doGetPaymentMethod)
}
