import { call, put, takeLatest } from 'redux-saga/effects'

import {
  searchCurrencyRateHistoryFailed,
  searchCurrencyRateHistorySuccess,
  SEARCH_CURRENCY_RATE_HISTORY_START,
} from '~/modules/database/redux/actions/currency-rate'
import { api } from '~/services/api'

/**
 * Search user API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
const searchCurrencyRateHistoryApi = (params) => {
  const uri = `v1/items/exchange-rates/histories/list`
  return api.get(uri, params)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doSearchCurrencyRateHistory(action) {
  try {
    const response = yield call(searchCurrencyRateHistoryApi, action?.payload)

    if (response?.statusCode === 200) {
      const payload = {
        list: response.data.items,
        total: response.data.meta.total,
      }
      yield put(searchCurrencyRateHistorySuccess(payload))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess()
      }
    } else {
      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(searchCurrencyRateHistoryFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch search users
 */
export default function* watchSearchCurrencyRateHistory() {
  yield takeLatest(
    SEARCH_CURRENCY_RATE_HISTORY_START,
    doSearchCurrencyRateHistory,
  )
}
