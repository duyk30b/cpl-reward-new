import { call, put, takeLatest } from 'redux-saga/effects'

import { NOTIFICATION_TYPE } from '~/common/constants'
import {
  activeCurrencyUnitFailed,
  activeCurrencyUnitSuccess,
  ACTIVE_CURRENCY_UNIT_START,
} from '~/modules/database/redux/actions/currency-unit'
import { api } from '~/services/api'
import addNotification from '~/utils/toast'

const activeCurrencyUnitApi = (params) => {
  const uri = `v1/items/currency-units/${params}/active`
  return api.put(uri)
}

function* doActiveCurrencyUnit(action) {
  try {
    const response = yield call(activeCurrencyUnitApi, action?.payload)

    if (response?.statusCode === 200) {
      yield put(activeCurrencyUnitSuccess(response.payload))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess()
      }

      addNotification(response?.message, NOTIFICATION_TYPE.SUCCESS)
    } else {
      addNotification(
        response?.message || response?.statusText,
        NOTIFICATION_TYPE.ERROR,
      )

      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(activeCurrencyUnitFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

export default function* watchActiveCurrencyUnit() {
  yield takeLatest(ACTIVE_CURRENCY_UNIT_START, doActiveCurrencyUnit)
}
