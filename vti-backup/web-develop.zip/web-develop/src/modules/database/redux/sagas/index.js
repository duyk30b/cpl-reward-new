import { all } from 'redux-saga/effects'

import watchCreateCurrencyRate from './currency-rate/create-currency-rate'
import watchGetMainCurrency from './currency-rate/get-main-currency'
import watchSearchCurrencyRateHistory from './currency-rate/search-currency-rate-history'
import watchSearchCurrencyRate from './currency-rate/search-currency-rate-list'
import watchActiveCurrencyUnit from './currency-unit/active-currency-unit'
import watchCreateCurrencyUnit from './currency-unit/create-currency-unit'
import watchDeleteCurrencyUnit from './currency-unit/delete-currency-unit'
import watchGetCurrencyUnit from './currency-unit/get-detail-currency-unit'
import watchInactiveCurrencyUnit from './currency-unit/inactive-currency-unit'
import watchSearchCurrencyUnit from './currency-unit/search-currency-unit'
import watchUpdateCurrencyUnit from './currency-unit/update-currency-unit'
import watchCreateCompany from './define-company/create-company'
import watchDeleteCompany from './define-company/delete-company'
import watchGetCompanyDetails from './define-company/get-company-details'
import watchSearchCompanies from './define-company/search-companies'
import watchUpdateCompany from './define-company/update-company'
import watchCreateItem from './define-item/create-item'
import watchDeleteItem from './define-item/delete-item'
import watchGetItemDetails from './define-item/get-item-details'
import watchPrintQRItems from './define-item/print-qr-items'
import watchSearchItems from './define-item/search-items'
import watchUpdateItem from './define-item/update-item'
import watchActiveVendor from './define-vendor/active'
import watchCreateVendor from './define-vendor/create-vendor'
import watchDeleteVendor from './define-vendor/delete-vendor'
import watchGenCodeVendor from './define-vendor/gen-code-vendor'
import watchGetVendorDetails from './define-vendor/get-vendor-details'
import watchImportVendor from './define-vendor/import-vendor'
import watchInActiveVendor from './define-vendor/in-active'
import watchSearchVendors from './define-vendor/search-vendors'
import watchUpdateVendor from './define-vendor/update-vendor'
import watchActiveDeliveryMethod from './delivery-method/active-delivery-method'
import watchCreateDeliveryMethod from './delivery-method/create-delivery-method'
import watchDeleteDeliveryMethod from './delivery-method/delete-delivery-method'
import watchGetDeliveryMethod from './delivery-method/get-detail-delivery-method'
import watchInactiveDeliveryMethod from './delivery-method/inactive-delivery-method'
import watchSearchDeliveryMethod from './delivery-method/search-delivery-method'
import watchUpdateDeliveryMethod from './delivery-method/update-delivery-method'
import watchCreateFactory from './factory/create-factory'
import watchDeleteFactory from './factory/delete-factory'
import watchGetFactoryDetails from './factory/get-factory-details'
import watchSearchFactories from './factory/search-factories'
import watchUpdateFactory from './factory/update-factory'
import watchCreateItemGroup from './item-group-setting/create-item-group'
import watchDeleteItemGroup from './item-group-setting/delete-item-group'
import watchGetItemGroupDetails from './item-group-setting/get-item-group-details'
import watchSearchItemGroups from './item-group-setting/search-item-groups'
import watchUpdateItemGroup from './item-group-setting/update-item-group'
import watchCreateItemType from './item-type-setting/create-item-type'
import watchDeleteItemType from './item-type-setting/delete-item-type'
import watchGetItemTypeDetails from './item-type-setting/get-item-type-details'
import watchSearchItemTypes from './item-type-setting/search-item-types'
import watchUpdateItemType from './item-type-setting/update-item-type'
import watchCreateItemUnit from './item-unit-setting/create-item-unit'
import watchDeleteItemUnit from './item-unit-setting/delete-item-unit'
import watchGetItemUnitDetails from './item-unit-setting/get-item-unit-details'
import watchSearchItemUnits from './item-unit-setting/search-item-units'
import watchUpdateItemUnit from './item-unit-setting/update-item-unit'
import watchActivePaymentMethod from './payment-method/active-payment-method'
import watchCreatePaymentMethod from './payment-method/create-payment-method'
import watchDeletePaymentMethod from './payment-method/delete-payment-method'
import watchGetPaymentMethod from './payment-method/get-detail-payment-method'
import watchInactivePaymentMethod from './payment-method/inactive-payment-method'
import watchSearchPaymentMethod from './payment-method/search-payment-method'
import watchUpdatePaymentMethod from './payment-method/update-payment-method'
import watchChangeStatusPurchasedOrder from './purchased-order/change-status-purchased-order'
import watchConfirmPurchasedOrder from './purchased-order/confirm-purchased-order'
import watchCreatePurchasedOrder from './purchased-order/create-purchased-order'
import watchDeletePurchasedOrder from './purchased-order/delete-purchased-order'
import watchGenCodePurchasedOrder from './purchased-order/gen-code-purchased-order'
import watchGetDetailVersionById from './purchased-order/get-detail-version-by-id'
import watchGetListVersionPO from './purchased-order/get-list-version-po'
import watchGetPurchasedOrderDetails from './purchased-order/get-purchased-order-details'
import watchGetPurchasedOrderNotCreatePOimp from './purchased-order/get-purchased-order-not-poimp'
import watchRejectPurchasedOrder from './purchased-order/reject-purchased-order'
import watchSearchPurchasedOrders from './purchased-order/search-purchased-order'
import watchUpdatePurchasedOrder from './purchased-order/update-purchased-order'
import watchConfirmSaleOrder from './sale-order/confirm-sale-order'
import watchCreateSaleOrder from './sale-order/create-sale-order'
import watchDeleteSaleOrder from './sale-order/delete-sale-order'
import watchSaleOrderDetailByIds from './sale-order/get-sale-order-detail_by_ids'
import watchGetSaleOrderDetails from './sale-order/get-sale-order-details'
import watchRejectSaleOrder from './sale-order/reject-sale-order'
import watchSearchSaleOrders from './sale-order/search-sale-orders'
import watchUpdateSaleOrder from './sale-order/update-sale-order'
import watchActiveVendorCriteria from './vendor-criteria/active-vendor-criteria'
import watchCreateVendorCriteria from './vendor-criteria/create-vendor-criteria'
import watchDeleteVendorCriteria from './vendor-criteria/delete-vendor-criteria'
import watchGencodeVendorCriteria from './vendor-criteria/gencode-vendor-criteria'
import watchGetVendorCriteria from './vendor-criteria/get-detail-vendor-criteria'
import watchInactiveVendorCriteria from './vendor-criteria/inactive-vendor-criteria'
import watchSearchVendorCriteria from './vendor-criteria/search-vendor-criteria'
import watchUpdateVendorCriteria from './vendor-criteria/update-vendor-criteria'

/**
 * Root saga
 */
export default function* sagas() {
  yield all([
    // item-group-setting
    watchSearchItemGroups(),
    watchCreateItemGroup(),
    watchUpdateItemGroup(),
    watchDeleteItemGroup(),
    watchGetItemGroupDetails(),

    // item-type-setting
    watchSearchItemTypes(),
    watchCreateItemType(),
    watchUpdateItemType(),
    watchDeleteItemType(),
    watchGetItemTypeDetails(),

    // item-unit-setting
    watchSearchItemUnits(),
    watchCreateItemUnit(),
    watchUpdateItemUnit(),
    watchDeleteItemUnit(),
    watchGetItemUnitDetails(),

    // define-item
    watchSearchItems(),
    watchCreateItem(),
    watchUpdateItem(),
    watchDeleteItem(),
    watchGetItemDetails(),
    watchPrintQRItems(),

    //define-company
    watchSearchCompanies(),
    watchCreateCompany(),
    watchUpdateCompany(),
    watchGetCompanyDetails(),
    watchDeleteCompany(),

    // factory
    watchSearchFactories(),
    watchCreateFactory(),
    watchUpdateFactory(),
    watchDeleteFactory(),
    watchGetFactoryDetails(),
    // sale-order
    watchSearchSaleOrders(),
    watchCreateSaleOrder(),
    watchUpdateSaleOrder(),
    watchDeleteSaleOrder(),
    watchGetSaleOrderDetails(),
    watchConfirmSaleOrder(),
    watchRejectSaleOrder(),
    watchSaleOrderDetailByIds(),

    // purchased-order
    watchSearchPurchasedOrders(),
    watchCreatePurchasedOrder(),
    watchUpdatePurchasedOrder(),
    watchDeletePurchasedOrder(),
    watchGetPurchasedOrderDetails(),
    watchConfirmPurchasedOrder(),
    watchRejectPurchasedOrder(),
    watchGetPurchasedOrderNotCreatePOimp(),
    watchGenCodePurchasedOrder(),
    watchChangeStatusPurchasedOrder(),
    watchGetListVersionPO(),
    watchGetDetailVersionById(),

    // currency-unit
    watchSearchCurrencyUnit(),
    watchGetCurrencyUnit(),
    watchCreateCurrencyUnit(),
    watchUpdateCurrencyUnit(),
    watchActiveCurrencyUnit(),
    watchInactiveCurrencyUnit(),
    watchDeleteCurrencyUnit(),

    // currency-rate
    watchSearchCurrencyRate(),
    watchSearchCurrencyRateHistory(),
    watchCreateCurrencyRate(),
    watchGetMainCurrency(),

    // delivery-method
    watchSearchDeliveryMethod(),
    watchGetDeliveryMethod(),
    watchCreateDeliveryMethod(),
    watchUpdateDeliveryMethod(),
    watchActiveDeliveryMethod(),
    watchInactiveDeliveryMethod(),
    watchDeleteDeliveryMethod(),

    // payment-method
    watchSearchPaymentMethod(),
    watchGetPaymentMethod(),
    watchCreatePaymentMethod(),
    watchUpdatePaymentMethod(),
    watchActivePaymentMethod(),
    watchInactivePaymentMethod(),
    watchDeletePaymentMethod(),

    // vendor-criteria
    watchSearchVendorCriteria(),
    watchGetVendorCriteria(),
    watchCreateVendorCriteria(),
    watchUpdateVendorCriteria(),
    watchDeleteVendorCriteria(),
    watchActiveVendorCriteria(),
    watchInactiveVendorCriteria(),
    watchGencodeVendorCriteria(),

    // vendor
    watchCreateVendor(),
    watchDeleteVendor(),
    watchGetVendorDetails(),
    watchImportVendor(),
    watchSearchVendors(),
    watchUpdateVendor(),
    watchInActiveVendor(),
    watchActiveVendor(),
    watchGenCodeVendor(),
  ])
}
