import { call, put, takeLatest } from 'redux-saga/effects'

import { NOTIFICATION_TYPE } from '~/common/constants'
import {
  createPaymentMethodFailed,
  createPaymentMethodSuccess,
  CREATE_PAYMENT_METHOD_START,
} from '~/modules/database/redux/actions/payment-method'
import { api } from '~/services/api'
import addNotification from '~/utils/toast'

/**
 * Search user API
 * @param {any} params Params will be sent to server
 * @returns {Promise}
 */
const createPaymentMethodApi = (params) => {
  const uri = `v1/purchased-orders/payment-types`
  return api.post(uri, params)
}

/**
 * Handle get data request and response
 * @param {object} action
 */
function* doCreatePaymentMethod(action) {
  try {
    const response = yield call(createPaymentMethodApi, action?.payload)

    if (response?.statusCode === 200) {
      yield put(createPaymentMethodSuccess(response.data))

      // Call callback action if provided
      if (action.onSuccess) {
        yield action.onSuccess(response.data)
      }

      addNotification(response?.message, NOTIFICATION_TYPE.SUCCESS)
    } else {
      addNotification(response?.message, NOTIFICATION_TYPE.ERROR)
      throw new Error(response?.message)
    }
  } catch (error) {
    yield put(createPaymentMethodFailed())
    // Call callback action if provided
    if (action.onError) {
      yield action.onError()
    }
  }
}

/**
 * Watch search users
 */
export default function* watchCreatePaymentMethod() {
  yield takeLatest(CREATE_PAYMENT_METHOD_START, doCreatePaymentMethod)
}
