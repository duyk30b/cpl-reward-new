import {
  ACTIVE_PAYMENT_METHOD_FAILED,
  ACTIVE_PAYMENT_METHOD_START,
  ACTIVE_PAYMENT_METHOD_SUCCESS,
  CREATE_PAYMENT_METHOD_FAILED,
  CREATE_PAYMENT_METHOD_START,
  CREATE_PAYMENT_METHOD_SUCCESS,
  DELETE_PAYMENT_METHOD_FAILED,
  DELETE_PAYMENT_METHOD_START,
  DELETE_PAYMENT_METHOD_SUCCESS,
  GET_DETAIL_PAYMENT_METHOD_FAILED,
  GET_DETAIL_PAYMENT_METHOD_START,
  GET_DETAIL_PAYMENT_METHOD_SUCCESS,
  INACTIVE_PAYMENT_METHOD_FAILED,
  INACTIVE_PAYMENT_METHOD_START,
  INACTIVE_PAYMENT_METHOD_SUCCESS,
  RESET_PAYMENT_METHOD_DETAIL_STATE,
  SEARCH_PAYMENT_METHOD_FAILED,
  SEARCH_PAYMENT_METHOD_START,
  SEARCH_PAYMENT_METHOD_SUCCESS,
  UPDATE_PAYMENT_METHOD_FAILED,
  UPDATE_PAYMENT_METHOD_START,
  UPDATE_PAYMENT_METHOD_SUCCESS,
} from '~/modules/database/redux/actions/payment-method'

const initialState = {
  isLoading: false,
  paymentMethodList: [],
  paymentMethodDetail: {},
  total: null,
}

export default function paymentMethod(state = initialState, action) {
  switch (action.type) {
    case SEARCH_PAYMENT_METHOD_START:
    case GET_DETAIL_PAYMENT_METHOD_START:
    case CREATE_PAYMENT_METHOD_START:
    case UPDATE_PAYMENT_METHOD_START:
    case ACTIVE_PAYMENT_METHOD_START:
    case INACTIVE_PAYMENT_METHOD_START:
    case DELETE_PAYMENT_METHOD_START:
      return {
        ...state,
        isLoading: true,
      }
    case SEARCH_PAYMENT_METHOD_SUCCESS:
      return {
        ...state,
        paymentMethodList: action.payload.list,
        isLoading: false,
        total: action.payload.total,
      }
    case SEARCH_PAYMENT_METHOD_FAILED:
      return {
        ...state,
        paymentMethodList: [],
        isLoading: false,
      }
    case GET_DETAIL_PAYMENT_METHOD_SUCCESS:
      return {
        ...state,
        paymentMethodDetail: action.payload,
        isLoading: false,
      }
    case GET_DETAIL_PAYMENT_METHOD_FAILED:
    case CREATE_PAYMENT_METHOD_SUCCESS:
    case CREATE_PAYMENT_METHOD_FAILED:
    case UPDATE_PAYMENT_METHOD_SUCCESS:
    case UPDATE_PAYMENT_METHOD_FAILED:
    case ACTIVE_PAYMENT_METHOD_SUCCESS:
    case ACTIVE_PAYMENT_METHOD_FAILED:
    case INACTIVE_PAYMENT_METHOD_SUCCESS:
    case INACTIVE_PAYMENT_METHOD_FAILED:
    case DELETE_PAYMENT_METHOD_SUCCESS:
    case DELETE_PAYMENT_METHOD_FAILED:
      return {
        ...state,
        isLoading: false,
      }
    case RESET_PAYMENT_METHOD_DETAIL_STATE:
      return {
        ...state,
        paymentMethodDetail: {},
      }
    default:
      return state
  }
}
