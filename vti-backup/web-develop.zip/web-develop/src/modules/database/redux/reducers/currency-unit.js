import {
  ACTIVE_CURRENCY_UNIT_FAILED,
  ACTIVE_CURRENCY_UNIT_START,
  ACTIVE_CURRENCY_UNIT_SUCCESS,
  CREATE_CURRENCY_UNIT_FAILED,
  CREATE_CURRENCY_UNIT_START,
  CREATE_CURRENCY_UNIT_SUCCESS,
  DELETE_CURRENCY_UNIT_FAILED,
  DELETE_CURRENCY_UNIT_START,
  DELETE_CURRENCY_UNIT_SUCCESS,
  GET_DETAIL_CURRENCY_UNIT_FAILED,
  GET_DETAIL_CURRENCY_UNIT_START,
  GET_DETAIL_CURRENCY_UNIT_SUCCESS,
  INACTIVE_CURRENCY_UNIT_FAILED,
  INACTIVE_CURRENCY_UNIT_START,
  INACTIVE_CURRENCY_UNIT_SUCCESS,
  RESET_CURRENCY_UNIT_DETAIL_STATE,
  SEARCH_CURRENCY_UNIT_FAILED,
  SEARCH_CURRENCY_UNIT_START,
  SEARCH_CURRENCY_UNIT_SUCCESS,
  UPDATE_CURRENCY_UNIT_FAILED,
  UPDATE_CURRENCY_UNIT_START,
  UPDATE_CURRENCY_UNIT_SUCCESS,
} from '~/modules/database/redux/actions/currency-unit'

const initialState = {
  isLoading: false,
  currencyUnitList: [],
  currencyUnitDetails: {},
  total: null,
}

export default function currencyUnit(state = initialState, action) {
  switch (action.type) {
    case SEARCH_CURRENCY_UNIT_START:
    case GET_DETAIL_CURRENCY_UNIT_START:
    case CREATE_CURRENCY_UNIT_START:
    case UPDATE_CURRENCY_UNIT_START:
    case ACTIVE_CURRENCY_UNIT_START:
    case INACTIVE_CURRENCY_UNIT_START:
    case DELETE_CURRENCY_UNIT_START:
      return {
        ...state,
        isLoading: true,
      }
    case SEARCH_CURRENCY_UNIT_SUCCESS:
      return {
        ...state,
        currencyUnitList: action.payload.list,
        isLoading: false,
        total: action.payload.total,
      }
    case SEARCH_CURRENCY_UNIT_FAILED:
      return {
        ...state,
        currencyUnitList: [],
        isLoading: false,
      }
    case GET_DETAIL_CURRENCY_UNIT_SUCCESS:
      return {
        ...state,
        currencyUnitDetails: action.payload,
        isLoading: false,
      }
    case GET_DETAIL_CURRENCY_UNIT_FAILED:
    case CREATE_CURRENCY_UNIT_SUCCESS:
    case CREATE_CURRENCY_UNIT_FAILED:
    case UPDATE_CURRENCY_UNIT_SUCCESS:
    case UPDATE_CURRENCY_UNIT_FAILED:
    case ACTIVE_CURRENCY_UNIT_SUCCESS:
    case ACTIVE_CURRENCY_UNIT_FAILED:
    case INACTIVE_CURRENCY_UNIT_SUCCESS:
    case INACTIVE_CURRENCY_UNIT_FAILED:
    case DELETE_CURRENCY_UNIT_SUCCESS:
    case DELETE_CURRENCY_UNIT_FAILED:
      return {
        ...state,
        isLoading: false,
      }
    case RESET_CURRENCY_UNIT_DETAIL_STATE:
      return {
        ...state,
        currencyUnitDetails: {},
      }
    default:
      return state
  }
}
