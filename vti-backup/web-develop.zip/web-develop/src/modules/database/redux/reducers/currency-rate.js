import {
  CREATE_CURRENCY_RATE_FAILED,
  CREATE_CURRENCY_RATE_START,
  CREATE_CURRENCY_RATE_SUCCESS,
  SEARCH_CURRENCY_RATE_HISTORY_FAILED,
  SEARCH_CURRENCY_RATE_HISTORY_START,
  SEARCH_CURRENCY_RATE_HISTORY_SUCCESS,
  SEARCH_CURRENCY_RATE_LIST_FAILED,
  SEARCH_CURRENCY_RATE_LIST_START,
  SEARCH_CURRENCY_RATE_LIST_SUCCESS,
  UPDATE_CURRENCY_RATE_FAILED,
  UPDATE_CURRENCY_RATE_START,
  UPDATE_CURRENCY_RATE_SUCCESS,
  GET_MAIN_CURRENCY_START,
  GET_MAIN_CURRENCY_SUCCESS,
  GET_MAIN_CURRENCY_FAILED,
} from '~/modules/database/redux/actions/currency-rate'

const initialState = {
  isLoading: false,
  currencyRateList: [],
  currencyRateHistory: [],
  total: null,
  totalHistory: null,
  mainCurrency: null,
}

export default function currencyRate(state = initialState, action) {
  switch (action.type) {
    case SEARCH_CURRENCY_RATE_LIST_START:
    case SEARCH_CURRENCY_RATE_HISTORY_START:
    case CREATE_CURRENCY_RATE_START:
    case UPDATE_CURRENCY_RATE_START:
    case GET_MAIN_CURRENCY_START:
      return {
        ...state,
        isLoading: true,
      }
    case GET_MAIN_CURRENCY_SUCCESS:
      return {
        ...state,
        mainCurrency: action.payload,
        isLoading: false,
      }
    case GET_MAIN_CURRENCY_FAILED:
      return {
        ...state,
        mainCurrency: null,
        isLoading: false,
      }
    case SEARCH_CURRENCY_RATE_LIST_SUCCESS:
      return {
        ...state,
        currencyRateList: action.payload.list,
        isLoading: false,
        total: action.payload.total,
      }
    case SEARCH_CURRENCY_RATE_LIST_FAILED:
      return {
        ...state,
        currencyRateList: [],
        isLoading: false,
      }
    case SEARCH_CURRENCY_RATE_HISTORY_SUCCESS:
      return {
        ...state,
        currencyRateHistory: action.payload.list,
        isLoading: false,
        totalHistory: action.payload.total,
      }
    case SEARCH_CURRENCY_RATE_HISTORY_FAILED:
      return {
        ...state,
        currencyRateHistory: [],
        isLoading: false,
      }
    case CREATE_CURRENCY_RATE_SUCCESS:
    case CREATE_CURRENCY_RATE_FAILED:
    case UPDATE_CURRENCY_RATE_SUCCESS:
    case UPDATE_CURRENCY_RATE_FAILED:
      return {
        ...state,
        isLoading: false,
      }
    default:
      return state
  }
}
