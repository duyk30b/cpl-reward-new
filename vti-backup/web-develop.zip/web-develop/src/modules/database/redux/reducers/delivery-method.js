import {
  ACTIVE_DELIVERY_METHOD_FAILED,
  ACTIVE_DELIVERY_METHOD_START,
  ACTIVE_DELIVERY_METHOD_SUCCESS,
  CREATE_DELIVERY_METHOD_FAILED,
  CREATE_DELIVERY_METHOD_START,
  CREATE_DELIVERY_METHOD_SUCCESS,
  DELETE_DELIVERY_METHOD_FAILED,
  DELETE_DELIVERY_METHOD_START,
  DELETE_DELIVERY_METHOD_SUCCESS,
  GET_DETAIL_DELIVERY_METHOD_FAILED,
  GET_DETAIL_DELIVERY_METHOD_START,
  GET_DETAIL_DELIVERY_METHOD_SUCCESS,
  INACTIVE_DELIVERY_METHOD_FAILED,
  INACTIVE_DELIVERY_METHOD_START,
  INACTIVE_DELIVERY_METHOD_SUCCESS,
  RESET_DELIVERY_METHOD_DETAIL_STATE,
  SEARCH_DELIVERY_METHOD_FAILED,
  SEARCH_DELIVERY_METHOD_START,
  SEARCH_DELIVERY_METHOD_SUCCESS,
  UPDATE_DELIVERY_METHOD_FAILED,
  UPDATE_DELIVERY_METHOD_START,
  UPDATE_DELIVERY_METHOD_SUCCESS,
} from '~/modules/database/redux/actions/delivery-method'

const initialState = {
  isLoading: false,
  deliveryMethodList: [],
  deliveryMethodDetail: {},
  total: null,
}

export default function deliveryMethod(state = initialState, action) {
  switch (action.type) {
    case SEARCH_DELIVERY_METHOD_START:
    case GET_DETAIL_DELIVERY_METHOD_START:
    case CREATE_DELIVERY_METHOD_START:
    case UPDATE_DELIVERY_METHOD_START:
    case ACTIVE_DELIVERY_METHOD_START:
    case INACTIVE_DELIVERY_METHOD_START:
    case DELETE_DELIVERY_METHOD_START:
      return {
        ...state,
        isLoading: true,
      }
    case SEARCH_DELIVERY_METHOD_SUCCESS:
      return {
        ...state,
        deliveryMethodList: action.payload.list,
        isLoading: false,
        total: action.payload.total,
      }
    case SEARCH_DELIVERY_METHOD_FAILED:
      return {
        ...state,
        deliveryMethodList: [],
        isLoading: false,
      }
    case GET_DETAIL_DELIVERY_METHOD_SUCCESS:
      return {
        ...state,
        deliveryMethodDetail: action.payload,
        isLoading: false,
      }
    case GET_DETAIL_DELIVERY_METHOD_FAILED:
    case CREATE_DELIVERY_METHOD_SUCCESS:
    case CREATE_DELIVERY_METHOD_FAILED:
    case UPDATE_DELIVERY_METHOD_SUCCESS:
    case UPDATE_DELIVERY_METHOD_FAILED:
    case ACTIVE_DELIVERY_METHOD_SUCCESS:
    case ACTIVE_DELIVERY_METHOD_FAILED:
    case INACTIVE_DELIVERY_METHOD_SUCCESS:
    case INACTIVE_DELIVERY_METHOD_FAILED:
    case DELETE_DELIVERY_METHOD_SUCCESS:
    case DELETE_DELIVERY_METHOD_FAILED:
      return {
        ...state,
        isLoading: false,
      }
    case RESET_DELIVERY_METHOD_DETAIL_STATE:
      return {
        ...state,
        deliveryMethodDetail: {},
      }
    default:
      return state
  }
}
