import {
  ACTIVE_VENDOR_CRITERIA_FAILED,
  ACTIVE_VENDOR_CRITERIA_START,
  ACTIVE_VENDOR_CRITERIA_SUCCESS,
  CREATE_VENDOR_CRITERIA_FAILED,
  CREATE_VENDOR_CRITERIA_START,
  CREATE_VENDOR_CRITERIA_SUCCESS,
  GET_DETAIL_VENDOR_CRITERIA_FAILED,
  GET_DETAIL_VENDOR_CRITERIA_START,
  GET_DETAIL_VENDOR_CRITERIA_SUCCESS,
  INACTIVE_VENDOR_CRITERIA_FAILED,
  INACTIVE_VENDOR_CRITERIA_START,
  INACTIVE_VENDOR_CRITERIA_SUCCESS,
  RESET_VENDOR_CRITERIA_DETAIL_STATE,
  SEARCH_VENDOR_CRITERIA_FAILED,
  SEARCH_VENDOR_CRITERIA_START,
  SEARCH_VENDOR_CRITERIA_SUCCESS,
  UPDATE_VENDOR_CRITERIA_FAILED,
  UPDATE_VENDOR_CRITERIA_START,
  UPDATE_VENDOR_CRITERIA_SUCCESS,
  DELETE_VENDOR_CRITERIA_BY_ID_START,
  DELETE_VENDOR_CRITERIA_BY_ID_SUCCESS,
  DELETE_VENDOR_CRITERIA_BY_ID_FAILED,
  GENCODE_VENDOR_CRITERIA_START,
  GENCODE_VENDOR_CRITERIA_SUCCESS,
  GENCODE_VENDOR_CRITERIA_FAILED,
} from '~/modules/database/redux/actions/vendor-criteria'

const initialState = {
  isLoading: false,
  vendorCriteriaList: [],
  vendorCriteriaDetail: {},
  total: null,
  genCode: '',
}

export default function vendorCriteria(state = initialState, action) {
  switch (action.type) {
    case SEARCH_VENDOR_CRITERIA_START:
    case GET_DETAIL_VENDOR_CRITERIA_START:
    case CREATE_VENDOR_CRITERIA_START:
    case UPDATE_VENDOR_CRITERIA_START:
    case ACTIVE_VENDOR_CRITERIA_START:
    case INACTIVE_VENDOR_CRITERIA_START:
    case DELETE_VENDOR_CRITERIA_BY_ID_START:
    case GENCODE_VENDOR_CRITERIA_START:
      return {
        ...state,
        isLoading: true,
      }
    case GENCODE_VENDOR_CRITERIA_SUCCESS:
      return {
        ...state,
        isLoading: false,
        genCode: action.payload?.code,
      }
    case GENCODE_VENDOR_CRITERIA_FAILED:
      return {
        ...state,
        genCode: '',
        isLoading: false,
      }
    case SEARCH_VENDOR_CRITERIA_SUCCESS:
      return {
        ...state,
        vendorCriteriaList: action.payload.list,
        isLoading: false,
        total: action.payload.total,
      }
    case SEARCH_VENDOR_CRITERIA_FAILED:
      return {
        ...state,
        vendorCriteriaList: [],
        isLoading: false,
      }
    case GET_DETAIL_VENDOR_CRITERIA_SUCCESS:
      return {
        ...state,
        vendorCriteriaDetail: action.payload,
        isLoading: false,
      }
    case GET_DETAIL_VENDOR_CRITERIA_FAILED:
      return {
        ...state,
        isLoading: false,
      }
    case CREATE_VENDOR_CRITERIA_SUCCESS:
    case CREATE_VENDOR_CRITERIA_FAILED:
    case UPDATE_VENDOR_CRITERIA_SUCCESS:
    case UPDATE_VENDOR_CRITERIA_FAILED:
    case ACTIVE_VENDOR_CRITERIA_SUCCESS:
    case ACTIVE_VENDOR_CRITERIA_FAILED:
    case INACTIVE_VENDOR_CRITERIA_SUCCESS:
    case INACTIVE_VENDOR_CRITERIA_FAILED:
    case DELETE_VENDOR_CRITERIA_BY_ID_SUCCESS:
    case DELETE_VENDOR_CRITERIA_BY_ID_FAILED:
      return {
        ...state,
        isLoading: false,
      }
    case RESET_VENDOR_CRITERIA_DETAIL_STATE:
      return {
        ...state,
        vendorCriteriaDetail: {},
      }
    default:
      return state
  }
}
