import { combineReducers } from 'redux'

import currencyRate from './currency-rate'
import currencyUnit from './currency-unit'
import defineCompany from './define-company'
import defineItem from './define-item'
import defineVendor from './define-vendor'
import deliveryMethod from './delivery-method'
import defineFactory from './factory'
import itemGroupSetting from './item-group-setting'
import itemTypeSetting from './item-type-setting'
import itemUnitSetting from './item-unit-setting'
import paymentMethod from './payment-method'
import purchasedOrder from './purchased-order'
import defineSaleOrder from './sale-order'
import vendorCriteria from './vendor-criteria'

export default combineReducers({
  itemGroupSetting,
  defineCompany,
  defineItem,
  defineFactory,
  itemTypeSetting,
  itemUnitSetting,
  defineSaleOrder,
  purchasedOrder,
  currencyUnit,
  currencyRate,
  deliveryMethod,
  paymentMethod,
  vendorCriteria,
  defineVendor,
})
