const style = (theme) => ({
  paper: {
    margin: theme.spacing(2, 0),
    padding: theme.spacing(2.5, 4, 4),
  },
})

export default style
