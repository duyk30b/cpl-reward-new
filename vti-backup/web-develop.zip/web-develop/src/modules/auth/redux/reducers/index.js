import auth from './auth'

const reducers = {
  auth,
}

export default reducers
