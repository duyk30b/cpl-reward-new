import React, { useEffect } from 'react'

import Box from '@mui/material/Box'
import PropTypes from 'prop-types'
import { useTranslation } from 'react-i18next'
import {
  Redirect,
  useHistory,
  useLocation,
  useRouteMatch,
} from 'react-router-dom'

import { useApp } from '~/common/hooks/useApp'
import HotKeys from '~/components/HotKeys'
import Sidebar from '~/components/Sidebar'
import useUserInfo from '~/modules/configuration/redux/hooks/useUserInfo'
import { useNotification } from '~/modules/shared/redux/hooks/useNotification'
import { privateRoutesFlatten } from '~/routes'
import { isAuth } from '~/utils'
import { getCurrentModule } from '~/utils/menu'

const PrivateLayout = ({ children }) => {
  const history = useHistory()
  const { pathname } = useLocation()
  const { canAccess } = useApp()
  const { path } = useRouteMatch()
  const {
    data: { userInfo },
  } = useUserInfo()
  const {
    data: { totalUnRead },
  } = useNotification()
  const currentModule = getCurrentModule(pathname) || 'general'

  const { t } = useTranslation([currentModule])

  const title = 'Smart MESx'

  if (!isAuth()) {
    return <Redirect to="/login" />
  }

  const hotKeysHandlers = {
    goToHomePage: () => {
      if (['mesx', 'wmsx', 'mmsx', 'qmsx'].includes(currentModule)) {
        history.push(`/${currentModule}`)
      } else {
        history.push('/')
      }
    },
    toggleNotification: () => {
      document.querySelector('[hotkey="global_toggleNotification"]')?.click()
    },
    toggleFilter: () => {
      document.querySelector('[hotkey="global_toggleFilter"]')?.click()
    },
  }

  const code = privateRoutesFlatten.find((r) => r?.path === path)?.code

  const name = privateRoutesFlatten.find((r) => r?.path === path)?.name

  useEffect(() => {
    if (name) {
      document.title = totalUnRead
        ? `(${totalUnRead < 0 ? 0 : totalUnRead}) ${title} - ${t(
            `menu.${name}`,
          )}`
        : `${title} - ${t(`menu.${name}`)}`
    } else {
      document.title = title
    }
    return () => {
      document.title = title
    }
  }, [path, totalUnRead])

  if (!canAccess(code) && !!userInfo?.userPermissions) {
    return <Redirect to="/" />
  }

  return (
    <Box
      sx={{
        display: 'flex',
        overflow: 'hidden',
        height: '100%',
      }}
    >
      <HotKeys handlers={hotKeysHandlers} />
      <Sidebar />
      <Box sx={{ flex: 1, overflow: 'hidden' }}>{children}</Box>
    </Box>
  )
}

PrivateLayout.defaultProps = {
  children: null,
}

PrivateLayout.propTypes = {
  children: PropTypes.node,
}

export default PrivateLayout
