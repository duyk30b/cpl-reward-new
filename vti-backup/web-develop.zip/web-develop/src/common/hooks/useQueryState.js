import { useCallback, useMemo, useRef } from 'react'

import { isArray, isEqual, isNil, isNull, mapKeys } from 'lodash'
import { useHistory, useLocation } from 'react-router-dom'

import qs from '~/utils/qs'

import { ROWS_PER_PAGE_OPTIONS } from '../constants'

export const useQueryState = (initialQuery, { prefix = '' } = {}) => {
  const history = useHistory()
  const { pathname, search } = useLocation()
  const queryObjRef = useRef()

  const pf = useMemo(
    () => (typeof prefix === 'string' ? prefix.trim() : ''),
    [prefix],
  )
  const $page = `${pf}page`
  const $pageSize = `${pf}limit`
  const $orderBy = `${pf}orderBy`
  const $order = `${pf}order`
  const $filters = `${pf}filters`
  const $quickFilters = `${pf}quickFilters`
  const $keyword = `${pf}keyword`

  const isJsonString = (str) => {
    try {
      JSON.parse(str)
    } catch (e) {
      return false
    }
    return true
  }

  const jsonParse = (str, fallbackOutput) => {
    if (isJsonString(str)) return JSON.parse(str)
    return fallbackOutput
  }

  const convertObj = useCallback(
    (obj = {}) => {
      const result = { ...obj }
      const keys = [$filters, $quickFilters, $keyword]

      keys.forEach((key) => {
        if (isNull(obj[key]) || isEqual(obj[key], {})) {
          result[key] = null
        } else if (result[key] !== undefined) {
          if (
            typeof result[key] === 'object' &&
            !Array.isArray(result[key]) &&
            Object.values(result[key]).every(
              (v) => isNil(v) || isEqual(v, {}) || isEqual(v, ''),
            )
          ) {
            result[key] = null
          } else {
            result[key] = JSON.stringify(obj[key])
          }
        }
      })

      return result
    },
    [$filters, $quickFilters, $keyword],
  )

  const queryObj = useMemo(() => {
    let result

    if (!search && !!initialQuery) {
      result = mapKeys(initialQuery, (v, k) => `${pf}${k}`)
      result = convertObj(result)
    } else {
      result = qs.parse(search)
    }

    if (!isEqual(result, queryObjRef.current)) {
      queryObjRef.current = result
    }

    return queryObjRef.current
  }, [search, initialQuery, queryObjRef.current])

  const page = useMemo(() => queryObj[$page] || 1, [queryObj, $page])
  const pageSize = useMemo(
    () =>
      ROWS_PER_PAGE_OPTIONS.includes(queryObj[$pageSize])
        ? queryObj[$pageSize]
        : ROWS_PER_PAGE_OPTIONS[0],
    [queryObj, $pageSize],
  )

  const sort = useMemo(
    () =>
      queryObj[$orderBy] && queryObj[$order]
        ? { orderBy: queryObj[$orderBy], order: queryObj[$order] }
        : null,
    [queryObj, $orderBy, $order],
  )

  const filters = useMemo(
    () => jsonParse(queryObj[$filters], {}) || {},
    [queryObj, $filters],
  )
  const quickFilters = useMemo(
    () => jsonParse(queryObj[$quickFilters], {}) || {},
    [queryObj, $quickFilters],
  )
  const keyword = useMemo(
    () => jsonParse(queryObj[$keyword], '') || '',
    [queryObj, $keyword],
  )

  const currentQuery = useMemo(
    () => ({ page, pageSize, sort, filters, quickFilters, keyword }),
    [page, pageSize, sort, filters, quickFilters, keyword],
  )

  const updateUrl = useCallback(
    (obj = {}) => {
      const combinedObj = {
        ...(!search && !!initialQuery ? initialQuery : {}),
        ...currentQuery,
        ...obj,
      }
      const convertedObj = convertObj(combinedObj)

      const newSearch = qs.add(search, convertedObj, {
        skipNull: true,
        skipEmptyString: true,
      })
      history.push(`${pathname}?${newSearch}`)
    },
    [
      pathname,
      search,
      initialQuery,
      currentQuery,
      $filters,
      $quickFilters,
      convertObj,
    ],
  )
  const setPage = useCallback(
    (payload) => updateUrl({ [$page]: payload }),
    [updateUrl, $page],
  )
  const setPageSize = useCallback(
    (payload) => updateUrl({ [$pageSize]: payload, [$page]: 1 }),
    [updateUrl, $pageSize, $page],
  )
  const setSort = useCallback(
    (payload) =>
      updateUrl({
        [$orderBy]: payload?.orderBy,
        [$order]: payload?.order,
        [$page]: 1,
      }),
    [updateUrl, $orderBy, $order, $page],
  )
  const setFilters = useCallback(
    (payload) => updateUrl({ [$filters]: payload, [$page]: 1 }),
    [updateUrl, $filters, $page],
  )
  const setQuickFilters = useCallback(
    (payload) => updateUrl({ [$quickFilters]: payload, [$page]: 1 }),
    [updateUrl, $quickFilters, $page],
  )
  const setKeyword = useCallback(
    (payload) => updateUrl({ [$keyword]: payload, [$page]: 1 }),
    [updateUrl, $keyword, $page],
  )

  const withSearch = useCallback(
    (path = '', { omitPrefixKeys = false, omitSpecificKeys = [] } = {}) => {
      let newSearch = qs.omit(search, 'cloneId')

      if (omitPrefixKeys) {
        newSearch = qs.omit(newSearch, [
          $page,
          $pageSize,
          $orderBy,
          $order,
          $filters,
          $quickFilters,
          $keyword,
        ])
      }

      if (isArray(omitSpecificKeys) && omitSpecificKeys?.length) {
        newSearch = qs.omit(newSearch, omitSpecificKeys)
      }

      const k = newSearch ? (path.includes('?') ? '&' : '?') : ''

      return `${path}${k}${newSearch}`
    },
    [
      search,
      $page,
      $pageSize,
      $orderBy,
      $order,
      $filters,
      $quickFilters,
      $keyword,
    ],
  )

  const selectedRowsDeps = JSON.stringify({
    filters,
    quickFilters,
    keyword,
  })

  return {
    page,
    pageSize,
    sort,
    filters,
    quickFilters,
    keyword,
    selectedRowsDeps,
    setPage,
    setPageSize,
    setSort,
    setFilters,
    setKeyword,
    setQuickFilters,
    withSearch,
  }
}
