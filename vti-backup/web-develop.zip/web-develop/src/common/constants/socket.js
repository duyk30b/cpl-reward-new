export const SOCKET_EVENTS = {
  PRINT_ITEM_QR_CODE: 'print_item_qr_code',
  PRINT_WORK_ORDER_QR_CODE: 'print_work_order_qr_code',

  PREFIX_CHANNEL_WEB: 'channel-notification',
}
